/* Data layer for analytics by Littledata app, version v11.0.1 */
(function() {
    if (window.LittledataLayer) return;

    window.LittledataLayer = {
        "betaTester": false,
        "productListLinksHaveImages": false,
        "productListLinksHavePrices": false,
        "debug": false,
        "hideBranding": false,
        "sendNoteAttributes": true,
        "ecommerce": {
            "impressions": []
        },
        "version": "v11.0.1",
        "transactionWatcherURL": "https://transactions.littledata.io",
        "referralExclusion": "/(paypal|visa|MasterCard|clicksafe|arcot\\.com|geschuetzteinkaufen|checkout\\.shopify\\.com|checkout\\.rechargeapps\\.com|portal\\.afterpay\\.com|payfort)/",
        "hasCustomPixel": false,
        "segment": {
            "CDNForAnalyticsJS": "https://cdn.segment.com",
            "addRevenueToOrderCompleted": false,
            "anonymizeIp": true,
            "cookiesToTrack": [],
            "disabledEvents": [],
            "disabledRecurring": false,
            "doNotTrackReplaceState": false,
            "ordersFilteredBySourceName": [],
            "productIdentifier": "PRODUCT_ID",
            "uniqueIdentifierForOrders": "orderName",
            "usePageTypeForListName": false,
            "userId": "shopifyCustomerId",
            "userIdUpdatedAt": "2024-08-30T20:19:25.279Z",
            "respectUserTrackingConsent": false
        }
    }
    console.log(`%cThis store uses Littledata 🚀 to automate its  setup and make better, data-driven decisions. Learn more at https://apps.shopify.com/littledata`, 'color: #088f87;', );

})();