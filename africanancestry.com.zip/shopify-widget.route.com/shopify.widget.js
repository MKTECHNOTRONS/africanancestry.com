(() => {
    var t = {
            13: (t, e) => {
                function r(t) {
                    void 0 === t && (t = window.localStorage), this.client = t
                }
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.CacheClient = void 0, r.prototype.get = function(t) {
                    var e, r = this.client.getItem(t);
                    return r ? (e = (r = JSON.parse(r)).value, (r = r.ttl) && Date.now() > r ? (this.client.removeItem(t), null) : e) : null
                }, r.prototype.set = function(t, e, r) {
                    r = Date.now() + r, e = JSON.stringify({
                        value: e,
                        ttl: r
                    }), this.client.setItem(t, e)
                }, r.prototype.delete = function(t) {
                    var e = this;
                    return new Promise((function(r) {
                        e.client.removeItem(t), r()
                    }))
                }, r.prototype.clear = function() {
                    var t = this;
                    return new Promise((function(e) {
                        t.client.clear(), e()
                    }))
                }, e.CacheClient = r
            },
            35: (t, e, r) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.createCacheClient = void 0;
                var n = r(13);
                e.createCacheClient = function() {
                    return new n.CacheClient(window.localStorage)
                }
            },
            46: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.findSubtotalElements = e.isNumericString = e.parseCurrencyToNumeric = e.formatMoneyWithCurrency = void 0, e.formatMoneyWithCurrency = function(t, e, r) {
                    return void 0 === r && (r = "USD"), e = e.toFixed(2), r = new Intl.NumberFormat("en-US", {
                        currency: r,
                        style: "currency"
                    }).format(e), t.replace(/[0-9.,-]+/, r.replace(r[0], ""))
                }, e.parseCurrencyToNumeric = function(t) {
                    return parseFloat(t.replace(/[^0-9.-]+/g, "").replace(",", ""))
                }, e.isNumericString = function(t) {
                    return t = t.replace(/[^0-9.]/g, ""), t = parseFloat(t), !isNaN(t) && isFinite(t)
                }, e.findSubtotalElements = function() {
                    var t = [".totals__total-value", ".Cart__Checkout span:nth-child(3)", ".upsell-cart__subtotal", ".ajaxcart__subtotal .money", "button[type='submit'] .btn__content .ml-1", ".subtotal .theme-money", ".totals .totals__subtotal-value", ".cart-subtotal .cart-subtotal__price", ".go-cart-drawer__subtotal-price", ".Cart__Total .money"],
                        e = document.querySelectorAll(".route-div");
                    if (0 < e.length)
                        for (var r = 0; r < e.length; r++) {
                            var n = e[r];
                            n.hasAttribute("data-subtotal-ref") && (n = n.getAttribute("data-subtotal-ref"), t.push(n))
                        }
                    var o = document.querySelectorAll(t.join(","));
                    return Array.from(o)
                }
            },
            71: function(t, e) {
                var r = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    n = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    o = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.SetToggleStatusUseCase = void 0, i.prototype.execute = function(t) {
                        return r(this, void 0, void 0, (function() {
                            var e;
                            return n(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return e = {
                                            attributes: {
                                                route_toggle_state: t
                                            }
                                        }, window.routeSkipInterception = !0, [4, this.shopifyRepository.updateCart(e)];
                                    case 1:
                                        return e = r.sent(), window.routeSkipInterception = !1, [2, e && e.attributes && e.attributes.route_toggle_state == t]
                                }
                            }))
                        }))
                    }, i);

                function i(t) {
                    this.shopifyRepository = t
                }
                e.SetToggleStatusUseCase = o
            },
            120: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = this && this.__importDefault || function(t) {
                        return t && t.__esModule ? t : {
                            default: t
                        }
                    },
                    a = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.fetchRequestHook = e.checkIfValidCartRequest = e.ajaxRequestHook = e.sleep = e.getShopifyDomain = e.getStoreDomain = void 0, r(727)),
                    u = i(r(671)),
                    c = (0, r(496).consoleLoggerAdapterFactory)().consoleLoggerAdapter;

                function s() {
                    return n(this, void 0, void 0, (function() {
                        var t, e, r, i, s, f, d, p, h, y, v = this;
                        return o(this, (function(b) {
                            switch (b.label) {
                                case 0:
                                    return window.routeSkipInterception ? [2] : [4, u.default.getState().getCart()];
                                case 1:
                                    if (b.sent(), c.log("Recalculate was triggered by AJAX request!", {
                                            cart: u.default.getState().cart
                                        }), (window.routeInterceptedCheckoutHooks = !1, a.addCheckoutHooks)(), window.routeInterceptedRecalculate = !0, 0 < (t = document.querySelectorAll("[data-route-ref]")).length)
                                        for (e = 0; e < t.length; e++)
                                            if (r = t[e], s = r.getAttribute("data-route-ref"), i = document.querySelector('[data-route-copy="'.concat(s, '"]')), s = document.querySelector("[button-without-protection-".concat(s, "]")), i && null !== i) {
                                                for (f = (0, a.getExpressCheckoutButtons)(), d = !0, p = 0; p < f.length; p++) h = f[p], i === h && (d = !1);
                                                s && s.remove(), d && (i.remove(), r.removeAttribute("style"), r.removeAttribute("data-route-ref"), d = !0)
                                            }
                                    return y = function() {
                                        return n(v, void 0, void 0, (function() {
                                            return o(this, (function(t) {
                                                switch (t.label) {
                                                    case 0:
                                                        return 0 !== document.querySelectorAll(".route-div").length ? [3, 2] : [4, u.default.getState().validateIfRouteProductWasRemovedManually()];
                                                    case 1:
                                                        t.sent(), t.label = 2;
                                                    case 2:
                                                        return [2]
                                                }
                                            }))
                                        }))
                                    }, l((function() {
                                        return n(v, void 0, void 0, (function() {
                                            var t, e;
                                            return o(this, (function(r) {
                                                switch (r.label) {
                                                    case 0:
                                                        t = document.querySelectorAll(".route-div"), e = 0, r.label = 1;
                                                    case 1:
                                                        return e < t.length ? [4, u.default.getState().renderUI(t[e])] : [3, 4];
                                                    case 2:
                                                        r.sent(), r.label = 3;
                                                    case 3:
                                                        return e++, [3, 1];
                                                    case 4:
                                                        return [2]
                                                }
                                            }))
                                        }))
                                    }), 1, 500), l(y, 1, 500), [2]
                            }
                        }))
                    }))
                }

                function l(t, e, r) {
                    var n = 0,
                        o = setInterval((function() {
                            n < e ? (t(), n++) : clearInterval(o)
                        }), r)
                }
                window.routeInterceptedXHR = !1, window.routeInterceptedFetch = !1, window.routeInterceptedRecalculate = !1, window.routeSkipInterception = !1, e.getStoreDomain = function() {
                    return document.location.origin.replace(/^(https?:\/\/)/i, "").split("/")[0]
                }, e.getShopifyDomain = function() {
                    var t;
                    if (window.Shopify) return window.Shopify.shop || (null == (t = window.Shopify.Checkout) ? void 0 : t.apiHost) || window.location.hostname
                }, e.sleep = function(t) {
                    return new Promise((function(e) {
                        return setTimeout(e, t)
                    }))
                }, e.ajaxRequestHook = function() {
                    if (window.routeInterceptedXHR) return c.log("Route already intercepted XHR hooks"), !1;
                    var t = new Object,
                        r = e.checkIfValidCartRequest,
                        n = s;
                    t.tempOpen = XMLHttpRequest.prototype.open, t.tempSend = XMLHttpRequest.prototype.send, t.callbackReady = function(t, e, o) {
                        void 0 === t && (t = !1), void 0 === e && (e = this.url), void 0 === o && (o = this.method), (!0 === r(e) && "post" === o.toLowerCase() || 1 == t) && n()
                    }, t.callback = function() {}, XMLHttpRequest.prototype.open = function(e, r) {
                        e = e || "", r = r || "", t.tempOpen.apply(this, arguments), t.method = e, t.url = r, "get" == e.toLowerCase() && (t.data = r.split("?"), t.data = t.data[1])
                    }, XMLHttpRequest.prototype.send = function(e) {
                        e = e || "";
                        var r = this,
                            n = t.url,
                            o = t.method;
                        r.addEventListener("readystatechange", (function() {
                            4 === r.readyState && t.callbackReady(!1, n, o)
                        })), n && -1 !== n.indexOf("/cart/change") && t.callbackReady(!0, n), t.tempSend.apply(r, arguments), "post" == t.method.toLowerCase() && (t.data = e), t.callback()
                    }, window.routeInterceptedXHR = !0
                }, e.checkIfValidCartRequest = function(t) {
                    try {
                        var e = new RegExp("/cart/:uid.js".replace(/:[^\s/]+/g, "([\\w-]+)")),
                            r = new RegExp("/cart/:uid".replace(/:[^\s/]+/g, "([\\w-]+)")),
                            n = void 0;
                        return null !== (n = null !== t.match(e) ? t.match(e) : null !== t.match(r) ? t.match(r) : null) && (-1 === n.indexOf("/cart.js") || void 0)
                    } catch (t) {
                        return !1
                    }
                }, e.fetchRequestHook = function() {
                    if (window.routeInterceptedFetch) return c.log("Route already intercepted Fetch hooks"), !1;
                    var t, r;
                    "function" == typeof(r = (t = window).fetch) && (t.fetch = function(t, n) {
                        var o = r.apply(this, arguments);
                        return o.then((function(r) {
                            return r.ok && "string" == typeof t && (0, e.checkIfValidCartRequest)(t) && s(), r
                        })), o
                    }), window.routeInterceptedFetch = !0
                }
            },
            136: function(t, e) {
                var r = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    n = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.retryUntil = void 0, e.retryUntil = function(t, e) {
                    return r(void 0, void 0, void 0, (function() {
                        var r, o, i, a, u, c;
                        return n(this, (function(n) {
                            switch (n.label) {
                                case 0:
                                    r = void 0 === (r = (a = e || {}).maxRetries) ? 3 : r, o = void 0 === (i = a.delay) ? 250 : i, i = a.onSuccess, a = a.onError, u = 0, n.label = 1;
                                case 1:
                                    if (!(u < r)) return [3, 7];
                                    n.label = 2;
                                case 2:
                                    return n.trys.push([2, 4, , 6]), [4, t()];
                                case 3:
                                    return c = n.sent(), null != i && i(c, u), [2, c];
                                case 4:
                                    return c = n.sent(), null != a && a(c, u), [4, new Promise((function(t) {
                                        return setTimeout(t, o)
                                    }))];
                                case 5:
                                    return n.sent(), [3, 6];
                                case 6:
                                    return u++, [3, 1];
                                case 7:
                                    throw new Error("Failed to retry after ".concat(r, " attempts"))
                            }
                        }))
                    }))
                }
            },
            145: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = this && this.__spreadArray || function(t, e, r) {
                        if (r || 2 === arguments.length)
                            for (var n, o = 0, i = e.length; o < i; o++) !n && o in e || ((n = n || Array.prototype.slice.call(e, 0, o))[o] = e[o]);
                        return t.concat(n || Array.prototype.slice.call(e))
                    },
                    a = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.createProductSlide = e.initialProductState = void 0, r(35)),
                    u = r(876),
                    c = r(801),
                    s = r(293),
                    l = r(835),
                    f = r(576),
                    d = r(779),
                    p = r(71),
                    h = r(496),
                    y = r(742),
                    v = (0, u.createShopifyRepositoryFactory)(),
                    b = (0, h.consoleLoggerAdapterFactory)().consoleLoggerAdapter,
                    g = 864e5;
                e.initialProductState = {
                    product: {
                        variants: []
                    },
                    featuredProduct: {
                        id: "",
                        price: 0
                    }
                }, e.createProductSlide = function(t, e) {
                    return {
                        addRouteProduct: function() {
                            return n(void 0, void 0, void 0, (function() {
                                var t;
                                return o(this, (function(r) {
                                    return t = e().featuredProduct.id, [2, new c.AddRouteVariantUseCase(v).execute({
                                        productId: t
                                    })]
                                }))
                            }))
                        },
                        removeRouteProducts: function() {
                            for (var t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                            return n(void 0, i([], t, !0), void 0, (function(t) {
                                var r, n;
                                return void 0 === t && (t = !1), o(this, (function(o) {
                                    switch (o.label) {
                                        case 0:
                                            return r = e().cart, window.routeSkipInterception ? [2] : [4, (0, y.setCacheByKey)({
                                                cacheID: y.cacheIds.routeProductRemovedByRoute,
                                                cacheData: {
                                                    routeProductRemovedByRoute: !0
                                                },
                                                cacheTTL: g
                                            })];
                                        case 1:
                                            return o.sent(), [4, new f.RemoveAllRouteVariantsUseCase(v).execute({
                                                cart: r
                                            })];
                                        case 2:
                                            return n = o.sent(), t ? [4, new p.SetToggleStatusUseCase(v).execute(0)] : [3, 5];
                                        case 3:
                                            return o.sent(), [4, (0, y.setCacheByKey)({
                                                cacheID: y.cacheIds.routeProductIsPresentInCart,
                                                cacheData: {
                                                    routeProductIsPresent: !1
                                                },
                                                cacheTTL: g
                                            })];
                                        case 4:
                                            o.sent(), o.label = 5;
                                        case 5:
                                            return n && window.location.reload(), [2]
                                    }
                                }))
                            }))
                        },
                        getClosestRouteVariant: function(r) {
                            return n(void 0, void 0, void 0, (function() {
                                var n, i;
                                return o(this, (function(o) {
                                    return n = e().product, n = (new s.GetClosestRouteVariantUseCase).execute({
                                        quote: r,
                                        variants: n.variants
                                    }), i = n.id, [2, t({
                                        featuredProduct: {
                                            id: i,
                                            price: n.price
                                        }
                                    })]
                                }))
                            }))
                        },
                        getRouteVariants: function() {
                            return n(void 0, void 0, void 0, (function() {
                                var r, n, i;
                                return o(this, (function(o) {
                                    switch (o.label) {
                                        case 0:
                                            return [4, e().getCart()];
                                        case 1:
                                            return o.sent(), n = (n = e().cart).currency, r = (0, a.createCacheClient)(), n = "".concat("route-product-info", "-").concat(n), (i = r.get(n)) && i.variants && 0 < i.variants.length ? (t({
                                                product: {
                                                    variants: i.variants
                                                }
                                            }), [2]) : [4, new l.GetRouteVariantsUseCase(v).execute({
                                                shopifyDomain: e().shopifyDomain
                                            })];
                                        case 2:
                                            return (i = o.sent()) && 0 < i.length && r.set(n, {
                                                variants: i
                                            }, 864e5), t({
                                                product: {
                                                    variants: i
                                                }
                                            }), [2]
                                    }
                                }))
                            }))
                        },
                        validateIfRouteProductWasRemovedManually: function() {
                            return n(void 0, void 0, void 0, (function() {
                                var t, r;
                                return o(this, (function(n) {
                                    switch (n.label) {
                                        case 0:
                                            return [4, (0, y.getCacheByKey)({
                                                cacheID: y.cacheIds.routeProductIsPresentInCart
                                            })];
                                        case 1:
                                            return null != (t = n.sent()) && t.routeProductIsPresent ? [4, (0, y.getCacheByKey)({
                                                cacheID: y.cacheIds.routeProductRemovedByRoute
                                            })] : [2];
                                        case 2:
                                            return (t = n.sent()) && t.routeProductRemovedByRoute ? [2] : [4, e().getCart()];
                                        case 3:
                                            if (n.sent(), r = e().cart, d.Assert.isNullOrEmpty(r)) return console.log("Cart is null or empty"), [2];
                                            if ((r = r.items).some((function(t) {
                                                    return d.Assert.isProductFromRoute(t.vendor)
                                                }))) return [3, 8];
                                            n.label = 4;
                                        case 4:
                                            return n.trys.push([4, 7, , 8]), [4, new p.SetToggleStatusUseCase(v).execute(0)];
                                        case 5:
                                            return n.sent(), [4, (0, y.setCacheByKey)({
                                                cacheID: y.cacheIds.routeProductIsPresentInCart,
                                                cacheData: {
                                                    routeProductIsPresent: !1
                                                },
                                                cacheTTL: g
                                            })];
                                        case 6:
                                            return n.sent(), [3, 8];
                                        case 7:
                                            return r = n.sent(), b.error("Shopify Widget: Error removing all Route Items from cart", r), [3, 8];
                                        case 8:
                                            return [2]
                                    }
                                }))
                            }))
                        }
                    }
                }
            },
            200: (t, e, r) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.createMerchantRepositoryFactory = void 0;
                var n = r(120),
                    o = r(977),
                    i = r(412),
                    a = r(818);
                e.createMerchantRepositoryFactory = function() {
                    var t = (0, n.getShopifyDomain)(),
                        e = (0, o.createHttpClientWithRetry)();
                    return new i.MerchantRepository({
                        httpClient: e,
                        shopifyServiceUrl: a.global.shopifyServiceURL,
                        shopifyDomain: t
                    })
                }
            },
            224: function(t, e, r) {
                var n = this && this.__assign || function() {
                        return (n = Object.assign || function(t) {
                            for (var e, r = 1, n = arguments.length; r < n; r++)
                                for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                            return t
                        }).apply(this, arguments)
                    },
                    o = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    i = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    a = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.ShopifyRepository = void 0, r(243));

                function u(t) {
                    this.httpClient = t.httpClient, this.storeDomain = t.storeDomain, this.storeProtocol = this.getProtocol()
                }
                u.prototype.getProtocol = function() {
                    return "__SHOPIFY_CLI_ENV__" in window && window.location.protocol || "https:"
                }, u.prototype.getHeaders = function() {
                    var t = this.storeDomain;
                    return n(n({}, {
                        shop: t,
                        "Content-type": "application/json;charset=UTF-8"
                    }), {
                        "X-Shopify-Domain": t
                    })
                }, u.prototype.getCart = function() {
                    return o(this, void 0, void 0, (function() {
                        var t, e;
                        return i(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    t = (new Date).getTime(), r.label = 1;
                                case 1:
                                    return r.trys.push([1, 4, , 5]), [4, this.httpClient.get("".concat(this.storeProtocol, "//").concat(this.storeDomain, "/cart.js?timestamp=").concat(t))];
                                case 2:
                                    return [4, r.sent().json()];
                                case 3:
                                    return [2, {
                                        items: (e = r.sent()).items,
                                        itemsCount: e.item_count,
                                        subtotal: e.subtotal_price,
                                        currency: e.currency,
                                        itemsSubtotalPrice: e.items_subtotal_price,
                                        requiresShipping: e.requires_shipping,
                                        token: e.token,
                                        totalDiscount: e.total_discount,
                                        totalPrice: e.total_price,
                                        originalTotalPrice: e.original_total_price,
                                        attributes: e.attributes
                                    }];
                                case 4:
                                    return e = r.sent(), console.log("Error getting cart", e), [2, void 0];
                                case 5:
                                    return [2]
                            }
                        }))
                    }))
                }, u.prototype.updateCart = function(t) {
                    return o(this, void 0, void 0, (function() {
                        var e;
                        return i(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, this.httpClient.post("".concat(this.storeProtocol, "//").concat(this.storeDomain, "/cart/update.js"), {
                                        body: JSON.stringify(t),
                                        headers: n({}, this.getHeaders())
                                    })];
                                case 1:
                                    return [2, r.sent().json()];
                                case 2:
                                    return e = r.sent(), console.log("Error updating cart", e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                }, u.prototype.addCart = function(t) {
                    return o(this, void 0, void 0, (function() {
                        var e;
                        return i(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 3, , 4]), [4, this.httpClient.post("".concat(this.storeProtocol, "//").concat(this.storeDomain, "/cart/add.js"), {
                                        body: JSON.stringify(t),
                                        headers: n({}, this.getHeaders())
                                    })];
                                case 1:
                                    return [4, r.sent().json()];
                                case 2:
                                    return [2, {
                                        items: r.sent().items
                                    }];
                                case 3:
                                    return e = r.sent(), console.log("Error adding to cart", e), [2, {
                                        items: []
                                    }];
                                case 4:
                                    return [2]
                            }
                        }))
                    }))
                }, u.prototype.getRouteVariants = function() {
                    return o(this, void 0, void 0, (function() {
                        var t, e, r, n, o, u;
                        return i(this, (function(i) {
                            switch (i.label) {
                                case 0:
                                    return i.trys.push([0, 3, , 4]), [4, this.httpClient.get("".concat(this.storeProtocol, "//").concat(this.storeDomain, "/products/routeins.js"))];
                                case 1:
                                    return [4, i.sent().json()];
                                case 2:
                                    return o = i.sent(), t = o.variants, u = o.id, e = o.title, r = o.handle, n = o.vendor, o = o.price, [2, new a.Product(u, e, r, o, n, t).getProductVariants()];
                                case 3:
                                    return u = i.sent(), console.log("Error getting route variants", u), [2, []];
                                case 4:
                                    return [2]
                            }
                        }))
                    }))
                }, e.ShopifyRepository = u
            },
            243: (t, e) => {
                function r(t, e, r, n, o, i) {
                    if (this.id = t, this.title = e, this.handle = r, this.price = n, this.quantity = o, this.variants = i, !this.id) throw new Error("Missing Product ID");
                    if (!this.title) throw new Error("Missing Product Title");
                    if (!this.handle) throw new Error("Missing Product Handle");
                    if (!this.price) throw new Error("Missing Product Price");
                    if (!this.quantity) throw new Error("Missing Product Quantity");
                    if (!this.variants) throw new Error("Missing Product Variants")
                }
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.Product = void 0, r.prototype.getProductVariants = function() {
                    return this.variants
                }, e.Product = r
            },
            293: (t, e, r) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.GetClosestRouteVariantUseCase = void 0;
                var n = r(779);

                function o() {}
                o.prototype.execute = function(t) {
                    if (n.Assert.isNullOrEmpty(t)) throw new Error("Missing Input");
                    if (n.Assert.isNullOrEmpty(t.quote)) throw new Error("Missing Quote");
                    if (n.Assert.isNullOrEmpty(t.variants)) throw new Error("Missing Variants");
                    var e = t.quote,
                        r = t.variants;
                    if (e <= r[0].price) return {
                        id: r[0].id,
                        price: r[0].price
                    };
                    if (e >= r[r.length - 1].price) return {
                        id: r[r.length - 1].id,
                        price: r[r.length - 1].price
                    };
                    for (var o = 0, i = r.length - 1; o < i;) {
                        var a = Math.floor((o + i) / 2);
                        if (r[a].price === e) return {
                            id: r[a].id,
                            price: r[a].price
                        };
                        r[a].price < e ? o = a + 1 : i = a
                    }
                    return {
                        id: (t = Math.abs(e - r[o].price) <= Math.abs(e - r[i].price) ? r[o] : r[i]).id,
                        price: t.price
                    }
                }, e.GetClosestRouteVariantUseCase = o
            },
            294: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.createMerchantSlice = void 0, r(779)),
                    a = r(35),
                    u = r(200),
                    c = r(120),
                    s = r(575),
                    l = (0, u.createMerchantRepositoryFactory)();
                e.createMerchantSlice = function(t, e) {
                    return {
                        getMerchantInfo: function() {
                            return n(void 0, void 0, void 0, (function() {
                                var e, r, n, u, f;
                                return o(this, (function(o) {
                                    switch (o.label) {
                                        case 0:
                                            return e = "route-merchant-info", r = (0, a.createCacheClient)(), n = r.get(e), i.Assert.isNotNullOrEmpty(n) && i.Assert.isNotNullOrEmpty(n.merchantId) && i.Assert.isNotNullOrEmpty(n.storeName) ? [2, t({
                                                storeName: n.storeName,
                                                merchantId: n.merchantId
                                            })] : [4, new s.GetMerchantInfoUseCase(l).execute({
                                                shopifyDomain: (0, c.getShopifyDomain)()
                                            })];
                                        case 1:
                                            return n = o.sent(), u = n.merchantId, f = n.storeName, u && f && i.Assert.isNotNullOrEmpty(u) && i.Assert.isNotNullOrEmpty(f) && r.set(e, {
                                                merchantId: u,
                                                storeName: f
                                            }, 6048e5), [2, t({
                                                storeName: f,
                                                merchantId: u
                                            })]
                                    }
                                }))
                            }))
                        }
                    }
                }
            },
            330: t => {
                t.exports = JSON.parse('{"name":"@route/shopify-cart-widget-v3","version":"1.0.0","description":"","main":"index.js","scripts":{"start":"webpack serve --mode=development --config=webpack.common.config.js","test":"jest --config jest.config.ts --detectOpenHandles","pre:build":"rimraf dist","post:build":"rm -rf dist/src","build":"npm run pre:build && webpack --mode=production --config=webpack.production.config.js && npm run post:build","build:stage":"npm run pre:build && webpack --mode=development --config=webpack.common.config.js && rm -rf dist/src && npm run post:build","cy:build":"npm run pre:build && webpack --mode=production --config=webpack.production.config.js && cp -r dist/shopify.widget.js cypress/fixtures/shopify.widget.js","cy:run":"npm run cy:build && cypress run --browser electron --headless --config defaultCommandTimeout=10000","cy:open":"cypress open","test:e2e":"npm run cy:run"},"keywords":[],"author":"","license":"ISC","engines":{"node":">=20"},"devDependencies":{"@jest/globals":"^29.6.1","@types/node":"^20.4.1","@types/webpack":"^5.28.1","@webpack-cli/generators":"^3.0.7","clean-webpack-plugin":"^4.0.0","copy-webpack-plugin":"^11.0.0","cypress":"^13.0.0","declaration-bundler-webpack-plugin":"^1.0.3","html-webpack-plugin":"^5.5.3","jest":"^29.6.1","jest-environment-jsdom":"^29.6.1","jest-fetch-mock":"^3.0.3","jsdom":"^22.1.0","rimraf":"^5.0.1","terser-webpack-plugin":"^5.3.9","ts-jest":"^29.1.1","ts-loader":"^9.4.4","ts-node":"^10.9.1","typescript":"^5.1.6","uglifyjs-webpack-plugin":"^2.2.0","webpack":"^5.88.1","webpack-dev-server":"^4.15.1","webpack-merge":"^5.9.0","wepack-cli":"^0.0.1-security"},"dependencies":{"zustand":"^4.3.9"}}')
            },
            377: function(t, e) {
                var r = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    n = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    o = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.HttpRetryStrategy = void 0, i.prototype.execute = function(t) {
                        return r(this, void 0, void 0, (function() {
                            var e, r, o, i, a, u;
                            return n(this, (function(c) {
                                switch (c.label) {
                                    case 0:
                                        e = 0, a = this.config, r = a.maxRetries, o = a.retryDelayMs, i = a.backoffFactor, a = function() {
                                            var a, u, c;
                                            return n(this, (function(n) {
                                                switch (n.label) {
                                                    case 0:
                                                        return n.trys.push([0, 2, , 4]), a = {}, [4, t()];
                                                    case 1:
                                                        return [2, (a.value = n.sent(), a)];
                                                    case 2:
                                                        if (u = n.sent(), r <= ++e) throw new Error("Function failed after ".concat(r, " retries: ").concat(u.message));
                                                        return c = Math.pow(i, e - 1) * o, [4, new Promise((function(t) {
                                                            return setTimeout(t, c)
                                                        }))];
                                                    case 3:
                                                        return n.sent(), [3, 4];
                                                    case 4:
                                                        return [2]
                                                }
                                            }))
                                        }, c.label = 1;
                                    case 1:
                                        return e <= r ? [5, a()] : [3, 3];
                                    case 2:
                                        return "object" == typeof(u = c.sent()) ? [2, u.value] : [3, 1];
                                    case 3:
                                        return [2]
                                }
                            }))
                        }))
                    }, i.prototype.getConfig = function() {
                        return this.config
                    }, i);

                function i(t) {
                    this.config = {
                        maxRetries: (null == t ? void 0 : t.maxRetries) || 3,
                        retryDelayMs: (null == t ? void 0 : t.retryDelayMs) || 1e3,
                        backoffFactor: (null == t ? void 0 : t.backoffFactor) || 2
                    }
                }
                e.HttpRetryStrategy = o
            },
            379: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.GetToggleStatusUseCase = void 0, r(779));

                function a(t) {
                    this.shopifyRepository = t
                }
                a.prototype.execute = function() {
                    return n(this, void 0, void 0, (function() {
                        var t, e;
                        return o(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return [4, this.shopifyRepository.getCart()];
                                case 1:
                                    return t = r.sent(), i.Assert.isNullOrEmpty(t) || i.Assert.isNullOrEmpty(null == (e = t.attributes) ? void 0 : e.route_toggle_state) ? [2, void 0] : [2, 1 == Number(null == (e = t.attributes) ? void 0 : e.route_toggle_state)]
                            }
                        }))
                    }))
                }, e.GetToggleStatusUseCase = a
            },
            412: function(t, e) {
                var r = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    n = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    o = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.MerchantRepository = void 0, i.prototype.getMerchantInfo = function() {
                        return r(this, void 0, void 0, (function() {
                            var t;
                            return n(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return e.trys.push([0, 3, , 4]), [4, this.httpClient.get("".concat(this.shopifyServiceUrl, "/v1/merchant-info/").concat(this.shopifyDomain))];
                                    case 1:
                                        return [4, e.sent().json()];
                                    case 2:
                                        if (!(t = e.sent()).merchantId) throw new Error("Failed to fetch Merchant ID");
                                        if (t.storeName) return [2, Promise.resolve({
                                            merchantId: t.merchantId,
                                            storeName: t.storeName
                                        })];
                                        throw new Error("Failed to fetch Store Name");
                                    case 3:
                                        return t = e.sent(), console.log("Error when fetching Merchant Info", {
                                            error: t
                                        }), [2, null];
                                    case 4:
                                        return [2]
                                }
                            }))
                        }))
                    }, i);

                function i(t) {
                    this.httpClient = t.httpClient, this.shopifyServiceUrl = t.shopifyServiceUrl, this.shopifyDomain = t.shopifyDomain
                }
                e.MerchantRepository = o
            },
            496: (t, e, r) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.consoleLoggerAdapterFactory = void 0;
                var n = r(792);
                e.consoleLoggerAdapterFactory = function() {
                    return {
                        consoleLoggerAdapter: new n.ConsoleLoggerAdapter
                    }
                }
            },
            498: function(t, e, r) {
                var n = this && this.__assign || function() {
                        return (n = Object.assign || function(t) {
                            for (var e, r = 1, n = arguments.length; r < n; r++)
                                for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                            return t
                        }).apply(this, arguments)
                    },
                    o = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    i = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    a = this && this.__importDefault || function(t) {
                        return t && t.__esModule ? t : {
                            default: t
                        }
                    },
                    u = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.convertAlignment = e.buildTheming = e.convertStatus = e.createWidgetSlice = void 0, r(876)),
                    c = r(818),
                    s = r(46),
                    l = r(727),
                    f = r(379),
                    d = r(71),
                    p = a(r(671)),
                    h = a(r(330)),
                    y = (0, u.createShopifyRepositoryFactory)();
                window.routeWidgetInitialized = !1, window.routeIdSentToCartAttributes = !1, e.createWidgetSlice = function(t, r) {
                    return {
                        renderUI: function(n) {
                            return o(void 0, void 0, void 0, (function() {
                                var a, v, b, g;
                                return i(this, (function(w) {
                                    switch (w.label) {
                                        case 0:
                                            return a = r(), v = a.storeDomain, b = a.merchantId, g = a.storeName, [4, (0, l.fetchProtectCoreScript)("".concat(c.global.protectCoreURL, "?shop=").concat(v)).then((function() {
                                                return o(void 0, void 0, void 0, (function() {
                                                    var a, w, m, S, _, C, k, P, A;
                                                    return i(this, (function(R) {
                                                        switch (R.label) {
                                                            case 0:
                                                                return [4, r().getCart()];
                                                            case 1:
                                                                return R.sent(), a = r().cart, m = r().product.variants, w = a.subtotal / 100, m.length <= 0 ? [2] : [4, new f.GetToggleStatusUseCase(y).execute()];
                                                            case 2:
                                                                return m = R.sent(), A = (0, e.convertStatus)(m), S = n.hasAttribute("desktop-align") ? n.getAttribute("desktop-align") : void 0, _ = n.hasAttribute("dark-ui"), C = n.hasAttribute("data-allow-multiple-renders"), n.hasAttribute("data-exclude-product") && 0 < (null == (P = null == a ? void 0 : a.items) ? void 0 : P.length) && (k = n.getAttribute("data-exclude-product"), null != (P = a.items.find((function(t) {
                                                                    return t.title.includes(k)
                                                                })))) && 0 < (null == P ? void 0 : P.price) && 0 < (null == P ? void 0 : P.quantity) && (w -= P.price / 100 * P.quantity), P = {
                                                                    app: {
                                                                        name: null == h.default ? void 0 : h.default.name,
                                                                        version: null == h.default ? void 0 : h.default.version,
                                                                        platformId: "shopify"
                                                                    },
                                                                    storeDomain: v,
                                                                    subtotal: w,
                                                                    currency: a.currency,
                                                                    environment: c.global.protectCoreURL.includes("stage") ? window.Route.Environment.Stage : window.Route.Environment.Production,
                                                                    merchantId: b,
                                                                    storeName: g,
                                                                    status: A,
                                                                    theming: (0, e.buildTheming)(_, S),
                                                                    allowMultipleRenders: C
                                                                }, window.Route.Protection.render(P), null != (A = r().middleware) && A.rendered || (window.Route.Protection.on("load", (function() {
                                                                    return o(this, void 0, void 0, (function() {
                                                                        var t, e;
                                                                        return i(this, (function(r) {
                                                                            return (e = null == (e = null == (e = window.Route.Protection) ? void 0 : e.options) ? void 0 : e.cartRef) && "string" == typeof e && !window.routeIdSentToCartAttributes && (t = (0, u.createShopifyRepositoryFactory)(), e = {
                                                                                attributes: {
                                                                                    __route_cart_id: e
                                                                                }
                                                                            }, t.updateCart(e), window.routeIdSentToCartAttributes = !0), [2]
                                                                        }))
                                                                    }))
                                                                })), window.Route.Protection.on("get_quote", (function(t) {
                                                                    return o(this, arguments, void 0, (function(t) {
                                                                        var e, n, o = t.quote;
                                                                        return i(this, (function(t) {
                                                                            switch (t.label) {
                                                                                case 0:
                                                                                    return e = parseFloat(o.premium.amount), [4, p.default.getState().getClosestRouteVariant(e)];
                                                                                case 1:
                                                                                    return t.sent(), window.Route.Protection.forceUpdateQuote(r().featuredProduct.price, !1), "merchant" !== o.paymentResponsible.type && "no_coverage" !== o.paymentResponsible.type ? [3, 3] : [4, p.default.getState().removeRouteProducts()];
                                                                                case 2:
                                                                                    return t.sent(), document.querySelectorAll("small").forEach((function(t) {
                                                                                        for (var e = 0; e < t.attributes.length; e++)
                                                                                            if (t.attributes[e].name.startsWith("button-without-protection-")) {
                                                                                                t.style.display = "none";
                                                                                                break
                                                                                            }
                                                                                    })), [3, 4];
                                                                                case 3:
                                                                                    document.querySelectorAll("small").forEach((function(t) {
                                                                                        for (var e = 0; e < t.attributes.length; e++)
                                                                                            if (t.attributes[e].name.startsWith("button-without-protection-")) {
                                                                                                t.style.display = "";
                                                                                                break
                                                                                            }
                                                                                    })), t.label = 4;
                                                                                case 4:
                                                                                    return "customer" == o.paymentResponsible.type && (e = p.default.getState().cart, n = "checked" == o.paymentResponsible.toggleState, e && e.attributes && e.attributes.hasOwnProperty("route_toggle_state") && (n = 1 == Number(e.attributes.route_toggle_state)), p.default.getState().renderSubtotalDinamicallyUI({
                                                                                        toggleState: n
                                                                                    })), setTimeout((function() {
                                                                                        var t, e = window.Route.Protection.getGrafanaFaroWebClientFactory(),
                                                                                            n = p.default.getState().cart;
                                                                                        0 == (0, l.getSubmitButtons)().length && n && 0 < n.itemsCount && (t = (n = r()).merchantId, e.log(["Shopify Widget: Missing Checkout Button to attach event"], {
                                                                                            context: {
                                                                                                merchantId: t,
                                                                                                storeDomain: n.storeDomain
                                                                                            }
                                                                                        }))
                                                                                    }), 4e3), [2]
                                                                            }
                                                                        }))
                                                                    }))
                                                                })), window.Route.Protection.on("status_change", (function(t) {
                                                                    return o(this, void 0, void 0, (function() {
                                                                        var e;
                                                                        return i(this, (function(r) {
                                                                            switch (r.label) {
                                                                                case 0:
                                                                                    return [4, new d.SetToggleStatusUseCase(y).execute(t.to)];
                                                                                case 1:
                                                                                    return r.sent(), (e = (0, l.getExpressCheckoutButtons)()) && 0 < e.length && 0 == t.to ? [4, p.default.getState().removeRouteProducts()] : [3, 3];
                                                                                case 2:
                                                                                    r.sent(), r.label = 3;
                                                                                case 3:
                                                                                    return 0 < (0, s.findSubtotalElements)().length ? [4, p.default.getState().getCart()] : [3, 5];
                                                                                case 4:
                                                                                    r.sent(), p.default.getState().renderSubtotalDinamicallyUI({
                                                                                        toggleState: 1 == t.to
                                                                                    }), r.label = 5;
                                                                                case 5:
                                                                                    return [2]
                                                                            }
                                                                        }))
                                                                    }))
                                                                })), window.routeWidgetInitialized = !0, t({
                                                                    middleware: {
                                                                        rendered: !0
                                                                    }
                                                                })), [2]
                                                        }
                                                    }))
                                                }))
                                            })).catch((function(t) {
                                                console.log("Error loading Route Protect Core script", t)
                                            }))];
                                        case 1:
                                            return w.sent(), [2]
                                    }
                                }))
                            }))
                        },
                        renderSubtotalDinamicallyUI: function(t) {
                            return o(void 0, void 0, void 0, (function() {
                                var e, n, o, a, u, c;
                                return i(this, (function(i) {
                                    return 0 != (e = (0, s.findSubtotalElements)()).length && window.routeWidgetInitialized && (n = r(), a = n.cart, n = n.featuredProduct, o = a.currency, a = a.totalPrice, "USD" === o) && (u = n.price, c = a / 100, e.forEach((function(e) {
                                        var r = e.innerHTML,
                                            n = t.toggleState ? c + u : c;
                                        n = (0, s.formatMoneyWithCurrency)(r, n, o);
                                        (0, s.parseCurrencyToNumeric)(n) <= c && (n = (0, s.formatMoneyWithCurrency)(r, c, o)), (0, s.isNumericString)(n) && (e.innerHTML = n)
                                    }))), [2]
                                }))
                            }))
                        }
                    }
                }, e.convertStatus = function(t) {
                    switch (t) {
                        case !0:
                            return window.Route.Coverage.ActiveByDefault;
                        case !1:
                            return window.Route.Coverage.InactiveByDefault
                    }
                }, e.buildTheming = function(t, r) {
                    return r = (0, e.convertAlignment)(r), n(n({}, t && {
                        mode: window.Route.Theme.Mode.DarkMode
                    }), r && {
                        alignment: r
                    })
                }, e.convertAlignment = function(t) {
                    switch (t) {
                        case "left":
                            return window.Route.Theme.Alignment.Left;
                        case "center":
                            return window.Route.Theme.Alignment.Center;
                        case "right":
                            return window.Route.Theme.Alignment.Right
                    }
                }
            },
            575: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.GetMerchantInfoUseCase = void 0, r(779));

                function a(t) {
                    this.merchantRepository = t
                }
                a.prototype.execute = function(t) {
                    return n(this, void 0, void 0, (function() {
                        var e;
                        return o(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    if (!t) throw new Error("Input is required");
                                    if (i.Assert.isNullOrEmpty(t.shopifyDomain)) throw new Error("Shopify domain is required");
                                    if (i.Assert.isUrl(t.shopifyDomain)) return [4, this.merchantRepository.getMerchantInfo()];
                                    throw new Error("Shopify domain is invalid");
                                case 1:
                                    return [2, {
                                        merchantId: (e = r.sent()).merchantId,
                                        storeName: e.storeName
                                    }]
                            }
                        }))
                    }))
                }, e.GetMerchantInfoUseCase = a
            },
            576: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.RemoveAllRouteVariantsUseCase = void 0, r(779));

                function a(t) {
                    this.shopifyApiRepository = t
                }
                a.prototype.execute = function(t) {
                    return n(this, void 0, void 0, (function() {
                        var e, r, n, a;
                        return o(this, (function(o) {
                            switch (o.label) {
                                case 0:
                                    if (i.Assert.isNullOrEmpty(t.cart)) throw new Error("Cart is null or empty");
                                    for (e = t.cart.items, r = {
                                            updates: {}
                                        }, n = 0; n < e.length; n++) i.Assert.isProductFromRoute(e[n].vendor) && (r.updates[e[n].variant_id] = 0);
                                    if (!i.Assert.isNotNullOrEmpty(r.updates)) return [3, 4];
                                    o.label = 1;
                                case 1:
                                    return o.trys.push([1, 3, , 4]), window.routeSkipInterception = !0, [4, this.shopifyApiRepository.updateCart(r)];
                                case 2:
                                    return o.sent(), [2, !(window.routeSkipInterception = !1)];
                                case 3:
                                    return a = o.sent(), console.log("Shopify Widget: Error removing all Route Items from cart", a), [3, 4];
                                case 4:
                                    return [2, !1]
                            }
                        }))
                    }))
                }, e.RemoveAllRouteVariantsUseCase = a
            },
            624: (t, e, r) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.getCartUseCaseFactory = void 0;
                var n = r(775),
                    o = r(876);
                e.getCartUseCaseFactory = function() {
                    var t = (0, o.createShopifyRepositoryFactory)();
                    return new n.GetCartUseCase(t)
                }
            },
            671: function(t, e, r) {
                var n = this && this.__assign || function() {
                        return (n = Object.assign || function(t) {
                            for (var e, r = 1, n = arguments.length; r < n; r++)
                                for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                            return t
                        }).apply(this, arguments)
                    },
                    o = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), r(739)),
                    i = r(120),
                    a = r(145),
                    u = r(912),
                    c = r(294),
                    s = r(498),
                    l = n({
                        shopifyDomain: (0, i.getShopifyDomain)(),
                        storeDomain: (0, i.getStoreDomain)()
                    }, a.initialProductState);
                r = (0, o.createStore)((function(t, e) {
                    return n(n(n(n(n({}, l), (0, a.createProductSlide)(t, e)), (0, u.createCartSlice)(t, e)), (0, c.createMerchantSlice)(t, e)), (0, s.createWidgetSlice)(t, e))
                }));
                e.default = r
            },
            675: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = this && this.__importDefault || function(t) {
                        return t && t.__esModule ? t : {
                            default: t
                        }
                    },
                    a = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), r(727)),
                    u = r(120),
                    c = i(r(671)),
                    s = (0, r(496).consoleLoggerAdapterFactory)().consoleLoggerAdapter,
                    l = function() {
                        return n(void 0, void 0, void 0, (function() {
                            return o(this, (function(t) {
                                return setInterval((function() {
                                    return n(void 0, void 0, void 0, (function() {
                                        var t, e, r;
                                        return o(this, (function(n) {
                                            if (0 < (t = document.querySelectorAll(".route-div")).length)
                                                for (e = 0; e < t.length; e++) 0 < (r = t[e]).childElementCount || (r.setAttribute("index", "".concat(e)), f(r, null));
                                            return [2]
                                        }))
                                    }))
                                }), 500), [2]
                            }))
                        }))
                    },
                    f = function(t, e) {
                        return n(void 0, void 0, void 0, (function() {
                            var r, n, i;
                            return o(this, (function(o) {
                                switch (o.label) {
                                    case 0:
                                        return o.trys.push([0, 4, , 5]), e && clearInterval(e), n = c.default.getState(), r = n.removeRouteProducts, n = n.renderUI, [4, (0, a.addCheckoutHooks)()];
                                    case 1:
                                        return o.sent(), [4, r()];
                                    case 2:
                                        return o.sent(), [4, n(t)];
                                    case 3:
                                        return o.sent(), s.info("Shopify Widget is rendered!", {
                                            placement: t
                                        }), [3, 5];
                                    case 4:
                                        return i = o.sent(), console.log("Error when renderWidget():", i), [3, 5];
                                    case 5:
                                        return [2]
                                }
                            }))
                        }))
                    };
                n(void 0, void 0, void 0, (function() {
                    var t, e, r;
                    return o(this, (function(n) {
                        switch (n.label) {
                            case 0:
                                return n.trys.push([0, 3, , 4]), e = c.default.getState(), r = e.getCart, t = e.getRouteVariants, e = e.getMerchantInfo, [4, Promise.all([r(), t(), e(), (0, u.ajaxRequestHook)(), (0, u.fetchRequestHook)()])];
                            case 1:
                                return n.sent(), [4, l()];
                            case 2:
                                return n.sent(), [3, 4];
                            case 3:
                                return r = n.sent(), console.log("Error when initialize():", r), [3, 4];
                            case 4:
                                return [2]
                        }
                    }))
                }))
            },
            683: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.debounce = void 0, e.debounce = function(t, e) {
                    var r;
                    return function() {
                        for (var n = [], o = 0; o < arguments.length; o++) n[o] = arguments[o];
                        clearTimeout(r), r = setTimeout((function() {
                            t.apply(void 0, n)
                        }), e)
                    }
                }
            },
            720: (t, e, r) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.HttpClientBuilder = void 0;
                var n = r(943),
                    o = r(377);

                function i() {}
                i.prototype.withRetryStrategy = function(t) {
                    return this._retryStrategy = new o.HttpRetryStrategy(t), this
                }, i.prototype.withMockHttpClient = function(t) {
                    return this._mockedHttpClient = t, this
                }, i.prototype.build = function() {
                    return this._mockedHttpClient || new n.HttpClient(this)
                }, e.HttpClientBuilder = i
            },
            727: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = this && this.__spreadArray || function(t, e, r) {
                        if (r || 2 === arguments.length)
                            for (var n, o = 0, i = e.length; o < i; o++) !n && o in e || ((n = n || Array.prototype.slice.call(e, 0, o))[o] = e[o]);
                        return t.concat(n || Array.prototype.slice.call(e))
                    },
                    a = this && this.__importDefault || function(t) {
                        return t && t.__esModule ? t : {
                            default: t
                        }
                    },
                    u = this,
                    c = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.fetchProtectCoreScript = e.checkoutButtonEventDispatcher = e.areButtonsEqual = e.deepCloneCheckoutButtons = e.getExpressCheckoutButtons = e.getSubmitButtons = void 0, e.dispatchElement = g, e.checkRouteDivAttribute = m, e.addCheckoutHooks = function() {
                        return n(this, void 0, void 0, (function() {
                            function t(t) {
                                return n(this, void 0, void 0, (function() {
                                    var r, n, i;
                                    return o(this, (function(o) {
                                        for (r = 0, n = t; r < n.length; r++) i = n[r], document.contains(i.target) && (i = E(i = i.target, b.concat(v)) ? i : i.closest("[data-route-ref]")) && C(i, e.checkoutButtonEventDispatcher, u, s, a, c);
                                        return [2]
                                    }))
                                }))
                            }
                            var r, a, u, c, s;
                            return o(this, (function(l) {
                                switch (l.label) {
                                    case 0:
                                        return window.routeInterceptedCheckoutHooks ? (y.log("Checkout hooks are already being added. Skipping."), [2]) : m("data-listener-delay") ? [4, (0, h.delay)(500)] : [3, 2];
                                    case 1:
                                        l.sent(), l.label = 2;
                                    case 2:
                                        return r = 0, a = [], u = m("data-remove-form-action"), c = new MutationObserver((0, p.debounce)(t, 250)), window.routeInterceptedCheckoutHooks = !0, d = [], v = document.querySelectorAll(".route-div"), Array.from(v).forEach((function(t) {
                                                (t = t.getAttribute("data-route-remove-class")) && (d = t.replace(/\s/g, "").split(","))
                                            })), s = d,
                                            function t() {
                                                return n(this, void 0, void 0, (function() {
                                                    var n;
                                                    return o(this, (function(o) {
                                                        switch (o.label) {
                                                            case 0:
                                                                o.trys.push([0, 5, 6, 7]), o.label = 1;
                                                            case 1:
                                                                return r < 50 && !w ? (n = i(i([], (0, e.getSubmitButtons)(), !0), (0, e.getExpressCheckoutButtons)(), !0), [4, (0, e.deepCloneCheckoutButtons)(n.filter((function(t) {
                                                                    return !t.getAttribute("data-route-copy") && !t.getAttribute("data-route-ref")
                                                                })), e.checkoutButtonEventDispatcher, u, s, a, c)]) : [3, 4];
                                                            case 2:
                                                                return o.sent(), ++r <= 50 && (window.routeInterceptedCheckoutHooks = !0), [4, (0, f.sleep)(500)];
                                                            case 3:
                                                                return o.sent(), window.routeInterceptedRecalculate && (r = 0, window.routeInterceptedRecalculate = !1), [2, t()];
                                                            case 4:
                                                                return [3, 7];
                                                            case 5:
                                                                return o.sent(), window.routeInterceptedCheckoutHooks = !1, [3, 7];
                                                            case 6:
                                                                return 50 <= r && (window.routeInterceptedCheckoutHooks = !1), [7];
                                                            case 7:
                                                                return [2]
                                                        }
                                                    }))
                                                }))
                                            }(), [2]
                                }
                                var d, v
                            }))
                        }))
                    }, e.updateClassFromClonedButton = S, e.addCheckoutWithoutProtectionLink = O, r(779)),
                    s = r(496),
                    l = a(r(671)),
                    f = r(120),
                    d = r(136),
                    p = r(683),
                    h = r(857),
                    y = (0, s.consoleLoggerAdapterFactory)().consoleLoggerAdapter,
                    v = ['[data-testid="ShopifyPay-button"]', '[data-testid="GooglePay-button"]', 'form[action="https://payments.amazon.com/checkout/signin"] button[type="submit"]', ".paypal-button", ".sezzle-checkout-button", ".rebuy-cart__shop-pay-button"],
                    b = ['form[action="/cart"] input[type="submit"]', 'form[action="/cart"] button[type="submit"]', '[name="checkout"]', '[href="/checkout"]', '[href="/checkout/"]', 'form[action="/checkout"] input[type="submit"]', 'form[action="/checkout"] button[type="submit"]', ".checkout_button:not(p)", ".btn--checkout", ".button-checkout", ".ec-pdp-checkout-button", ".rebuy-checkout-button", ".rebuy-cart__checkout-button", ".picky-bundle-add-to-cart-button", "#mu-checkout-button", 'a[title="checkout"].btn-green-solid', ".sidecart__checkout-button"];

                function g(t) {
                    var e;
                    window.routeSkipInterception = !0;
                    try {
                        if (t && t.tagName && "form" === t.tagName.toLowerCase()) t.submit();
                        else {
                            var r = Array.from(document.querySelectorAll(".route-div")).some((function(t) {
                                return null == t ? void 0 : t.hasAttribute("data-ignore-anchor-redirect")
                            }));
                            if (t && t.tagName && "a" === t.tagName.toLowerCase() && (null == (e = t.getAttribute("href")) ? void 0 : e.includes("checkout")) && !r) window.location.href = "/checkout";
                            else {
                                var n, o = document.querySelectorAll(".route-div");
                                if (0 < o.length)
                                    for (var i = 0; i < o.length; i++)
                                        if (o[i].hasAttribute("data-redirect-to-checkout")) return void(window.location.href = "/checkout");
                                Array.from(document.querySelectorAll(".route-div")).some((function(t) {
                                    return t.hasAttribute("data-route-hide-continue-without-coverage")
                                })) && (n = t.parentNode) && n.querySelectorAll(".preferred-checkout-wrapper").forEach((function(t) {
                                    return t.remove()
                                })), t.click()
                            }
                        }
                    } catch (t) {
                        console.error("Shopify Widget: Error in dispatchElement:", t), window.location.href = "/checkout"
                    }
                }
                e.getSubmitButtons = function() {
                    var t = document.querySelectorAll(b.join(",")),
                        e = (t = Array.prototype.slice.apply(t).filter((function(t) {
                            return "update" !== t.name
                        })), document.querySelectorAll('button,input[type="submit"],input[type="button"],a'));
                    e = Array.from(e).filter((function(t) {
                        var e, r = (t.innerHTML || "").toLowerCase();
                        return (r.includes("checkout") || r.includes("check out")) && (r = document.querySelectorAll(".route-div"), e = document.querySelectorAll(".route-continue-without-coverage-link"), !i(i([], Array.from(r), !0), Array.from(e), !0).some((function(t) {
                            return null == t ? void 0 : t.hasAttribute("data-ignore-checkout-ref")
                        }))) && !((r = t).hasAttribute("data-checkout-without-coverage-link") && r.classList.contains("route-continue-without-coverage-link"))
                    }));
                    return i(i([], t, !0), e, !0).reduce((function(t, e) {
                        return t.includes(e) || t.push(e), t
                    }), [])
                }, e.getExpressCheckoutButtons = function() {
                    var t = document.querySelectorAll(v.join(","));
                    return Array.prototype.slice.apply(t).filter((function(t) {
                        return "update" !== t.name
                    }))
                };
                var w = !1;

                function m(t) {
                    var e = document.querySelectorAll(".route-div");
                    return Array.from(e).some((function(e) {
                        return null !== e.getAttribute(t)
                    }))
                }

                function S(t, e) {
                    t.forEach((function(t) {
                        var r, n, o, i, a;
                        e.classList.contains(t) && (0 === _("." + (r = "route-class-" + t.trim())).trim().length && 0 < (i = _("." + t.trim())).trim().length && (n = r, o = t, (a = document.createElement("style")).type = "text/css", a.setAttribute("name", n), o = new RegExp("\\." + o, "g"), a.innerHTML = i.replace(o, "." + n), i = a, document.body.appendChild(i)), e.classList.replace(t, r))
                    }))
                }

                function _(t) {
                    for (var e = document.styleSheets, r = "", n = 0; n < e.length; n++) try {
                        var o = "cssRules" in e[n] ? e[n].cssRules : e[n].rules;
                        if (o)
                            for (var i = 0; i < o.length; i++) {
                                var a = o[i];
                                a.selectorText && a.selectorText.includes(t) && (r += "".concat(a.selectorText, " { ").concat(a.style.cssText, " } \n"))
                            }
                    } catch (t) {
                        y.log("Css not found while trying to get styles for class");
                        continue
                    }
                    return r
                }
                window.routeInterceptedCheckoutHooks = !1, window.routeRef = 0, e.deepCloneCheckoutButtons = function(t, e) {
                    for (var r = [], a = 2; a < arguments.length; a++) r[a - 2] = arguments[a];
                    return n(void 0, i([t, e], r, !0), void 0, (function(t, e, r, n, i, a) {
                        return void 0 === r && (r = !1), o(this, (function(o) {
                            return t.forEach((function(t) {
                                t.getAttribute("data-route-copy") || i.some((function(e) {
                                    return e.getAttribute("data-route-ref") === t.getAttribute("data-route-ref")
                                })) || C(t, e, r, n, i, a)
                            })), [2]
                        }))
                    }))
                };
                var C = function(t, r, n, o, i, a) {
                        void 0 === n && (n = !1);
                        var u = 0,
                            c = null == (c = null == (c = window.Route) ? void 0 : c.Protection) ? void 0 : c.ABTestData;
                        if (t.getAttribute("data-route-ref")) {
                            u = Number(t.getAttribute("data-route-ref"));
                            var s = document.querySelector('[data-route-copy="'.concat(u, '"]'));
                            if (s && (0, e.areButtonsEqual)(t, s, o)) return;
                            null != s && s.remove(), t.hasAttribute("style") && t.getAttribute("style").includes("display: none !important;") && (s = (s = t.getAttribute("style")) || "", t.setAttribute("style", s.replace("display: none !important;", "")))
                        } else window.routeRef++, t.setAttribute("data-route-ref", (u = window.routeRef).toString()), i.push(t), (k(t) || P(t)) && !m("data-include-svg-mutation") || a.observe(t, {
                            attributes: !0,
                            childList: !0,
                            subtree: !0
                        });
                        A(t) ? ("coverage" !== (null == c ? void 0 : c.abPreferredCheckoutVariant) && "recommended" !== (null == c ? void 0 : c.abPreferredCheckoutVariant) && "social_proof" !== (null == c ? void 0 : c.abPreferredCheckoutVariant) || ((t, e) => {
                            for (var r, n = document.createTreeWalker(t, NodeFilter.SHOW_TEXT, null), o = "social_proof" === e ? "VIP" : "coverage"; r = n.nextNode();) {
                                var i = (null == (i = r.nodeValue) ? void 0 : i.toUpperCase()) === r.nodeValue,
                                    a = (null == (a = r.nodeValue) ? void 0 : a.toLowerCase()) || "";
                                if (a.match(/\bcheck[\s-]*out\b/i) && !a.toLowerCase().includes("with ".concat(o).toLowerCase())) return a = "out with ".concat(o), r.nodeValue = r.nodeValue.replace(/(out)/i, i ? a.toUpperCase() : a)
                            }
                        })(t, null == c ? void 0 : c.abPreferredCheckoutVariant), s = t.parentNode, i = t.cloneNode(!0), s.insertBefore(i, t), a = t.getAttribute("style"), t.setAttribute("style", "display: none !important;" + (a || "")), i.removeAttribute("disabled"), i.removeAttribute("data-route-ref"), i.setAttribute("data-route-copy", u.toString()), i.setAttribute("name", "button-route-" + u), i.setAttribute("aria-label", "Checkout with Shipping Protection included for an additional fee as listed above"), 0 < o.length && S(o, i), i.removeAttribute("data-ocu-checkout"), i.removeAttribute("qbk-checkout-listener"), i.removeAttribute("id"), "a" === (null == (c = null == i ? void 0 : i.tagName) ? void 0 : c.toLowerCase()) && null != (s = null == i ? void 0 : i.getAttribute("href")) && s.includes("checkout") && (i.setAttribute("href", "javascript:void(0);"), i.setAttribute("data-route-href", "".concat(window.location.origin, "/checkout"))), "button" === i.tagName.toLowerCase() && i.hasAttribute("onclick") && i.getAttribute("onclick").includes("window.location='/checkout'") && i.removeAttribute("onclick"), t.classList.contains("rebuy-cart__checkout-button") && t.hasAttribute("onclick") && i.removeAttribute("onclick"), i.addEventListener("click", (function(e) {
                            return r(t, e)
                        })), n && !E(i, v) && (null != (o = null == (a = t.closest("form")) ? void 0 : a.getAttribute("action")) && (i.setAttribute("data-route-form-action", o), t.setAttribute("data-route-form-action", o)), null != a) && a.removeAttribute("action"), O(t, i, u)) : (c = t.parentNode) && c.querySelectorAll(".preferred-checkout-wrapper").forEach((function(t) {
                            return t.remove()
                        }))
                    },
                    k = function(t) {
                        return 0 < Array.from(t.querySelectorAll("svg")).length
                    },
                    P = function(t) {
                        return 0 < Array.from(t.querySelectorAll(".button__loader")).length
                    },
                    A = function(t) {
                        return !(t.hasAttribute("disabled") && "disabled" == t.getAttribute("disabled") || "true" == t.getAttribute("disabled") || "" == t.getAttribute("disabled") || t.hasAttribute("class") && t.classList.contains("disabled") || t.hasAttribute("style") && (t.getAttribute("style").includes("visibility: hidden") || t.getAttribute("style").includes("visibility:hidden")) || t.hasAttribute("data-loop-button"))
                    },
                    R = function(t) {
                        var e;
                        if (t && t.attributes) return e = {}, Array.from(t.attributes).forEach((function(t) {
                            var r;
                            t.nodeName.startsWith("style") && t.nodeValue ? "" !== (r = t.nodeValue.replace("display: none !important;", "")).trim() && (e[t.nodeName] = r) : t.nodeName.startsWith("data-route") || t.nodeName.startsWith("data-ocu-checkout") || t.nodeName.startsWith("qbk-checkout-listener") || t.nodeName.startsWith("name") || t.nodeName.startsWith("id") || t.nodeName.startsWith("href") || t.nodeName.startsWith("aria-label") || t.nodeName.startsWith("onclick") || !t.nodeValue || (e[t.nodeName] = t.nodeValue)
                        })), {
                            innerText: t.innerHTML,
                            dataAttributes: e
                        }
                    };

                function x(t) {
                    return !!t && Array.from(t.classList).some((function(t) {
                        return t.includes("rebuy")
                    }))
                }

                function I(t) {
                    var e, r = document.createElement("a"),
                        n = (t => {
                            for (var e, r = document.createTreeWalker(t, NodeFilter.SHOW_TEXT, null); e = r.nextNode();)
                                if (((null == (o = e.nodeValue) ? void 0 : o.toLowerCase()) || "").match(/\bcheck[\s-]*out\b/i) && e.parentElement) {
                                    var n = window.getComputedStyle(e.parentElement).fontSize,
                                        o = (e.nodeValue || "").match(/\bcheck[\s-]*out\b/i),
                                        i = o ? o[0].trim() : "";
                                    break
                                }
                            return {
                                fontSize: n,
                                checkoutTextSanitized: i
                            }
                        })(t),
                        o = n.checkoutTextSanitized === (null == (o = n.checkoutTextSanitized) ? void 0 : o.toUpperCase()),
                        i = n.checkoutTextSanitized === (null == (i = n.checkoutTextSanitized) ? void 0 : i.toLowerCase()),
                        a = n.checkoutTextSanitized ? "".concat(null == n ? void 0 : n.checkoutTextSanitized, " without") : "Checkout without",
                        u = "social_proof" === (null == (u = null == (u = null == (u = window.Route) ? void 0 : u.Protection) ? void 0 : u.ABTestData) ? void 0 : u.abPreferredCheckoutVariant) ? "VIP" : null != (u = null == (u = window.Route) ? void 0 : u.Protection) && u.isPreferredCheckoutCashbackWidget ? "Cash Back" : "Coverage";
                    a = "".concat(a, " ").concat(u);
                    return r.innerText = o ? a.toUpperCase() : i ? a.toLowerCase() : a, r.href = "#", r.className = "full-unstyled-link route-continue-without-coverage-link", r.style.textDecoration = "underline", r.style.fontWeight = "500", r.style.fontSize = null != n && n.fontSize ? null == n ? void 0 : n.fontSize : "1rem", r.style.color = "currentColor", r.setAttribute("aria-label", "Continue to checkout without Shipping Protection"), r.setAttribute("data-checkout-without-coverage-link", "true"), r.addEventListener("click", (e = t, function() {
                        window.Route.Protection.isPreferredCheckoutWidget && window.Route.Protection.trackEvent("preferred_checkout_frontend_event", {
                            preferred_checkout_button_click: "unprotected"
                        }), window.routeSkipInterception = !1, l.default.getState().getCart().then((function() {
                            return l.default.getState().removeRouteProducts(!0)
                        })).then((function() {
                            return e.click()
                        })).catch((function(t) {
                            return console.error("Click without protection error:", t)
                        }))
                    })), "dark" !== (null == (i = null == (o = null == (u = window.Route) ? void 0 : u.Protection) ? void 0 : o.assets) ? void 0 : i.mode) && "dark" !== (null == (n = null == (a = window.Route) ? void 0 : a.Protection) ? void 0 : n.getThemeMode()) || (r.style.color = "rgba(255, 255, 255, 0.9)"), r
                }

                function O(t, e, r) {
                    function n() {
                        var n, o, i, a, u, c, s, l, f;
                        !window.Route.Protection.isPreferredCheckoutWidget && !window.Route.Protection.isPreferredCheckoutCashbackWidget || document.querySelector("[button-without-protection-".concat(r, "]")) || (n = t.parentNode) && (o = "display: flex; flex-flow: column; flex-basis: 100%; height: 100%;", n.querySelectorAll(".preferred-checkout-wrapper").forEach((function(t) {
                            return t.remove()
                        })), c = 0 === document.getElementsByTagName("route-protect-widget").length || Array.from(document.getElementsByTagName("route-protect-widget")).some((function(t) {
                            return "no_coverage" !== t.getAttribute("payer")
                        })), a = Array.from(document.querySelectorAll(".route-div")).some((function(t) {
                            return t.hasAttribute("data-route-remove-inline-style")
                        })), 0 < (null == (u = (() => {
                            var t = [],
                                e = document.querySelectorAll(".route-div");
                            if (Array.from(e).forEach((function(e) {
                                    (e = e.getAttribute("data-route-update-cart-button")) && (t = e.replace(/\s/g, "").split(","))
                                })), 0 < t.length) return e = t.map((function(t) {
                                return ".".concat(t)
                            })).join(","), document.querySelectorAll(e)
                        })()) ? void 0 : u.length) && null != (i = n.parentNode) && i.querySelectorAll(".preferred-checkout-wrapper").forEach((function(t) {
                            return t.remove()
                        })), i = x(e) || x(t) || a, a = {
                            textAlign: "center",
                            flexBasis: "100%",
                            marginTop: "10px",
                            paddingTop: "12px",
                            borderTop: "dark" === (null == (a = null == (a = null == (a = window.Route) ? void 0 : a.Protection) ? void 0 : a.assets) ? void 0 : a.mode) || "dark" === (null == (a = null == (a = window.Route) ? void 0 : a.Protection) ? void 0 : a.getThemeMode()) ? "1px solid rgba(255, 255, 255, 0.75)" : "1px solid rgba(0, 0, 0, 0.15)",
                            display: c ? "" : "none"
                        }, i || u && 0 < u.length ? ((f = document.createElement("div")).className = "preferred-checkout-wrapper", f.style.cssText = o, s = I(t), (l = document.createElement("small")).setAttribute("button-without-protection-".concat(r), "true"), l.appendChild(s), Object.assign(l.style, a), u = (c = n.getBoundingClientRect()).width, 0 < (c = c.height) && (l.style.height = "".concat(c, "px")), 0 < u && (l.style.width = "".concat(u, "px")), f.appendChild(l), i ? n.insertBefore(f, e.nextSibling) : n.after(f)) : (s = I(t), (l = document.createElement("small")).setAttribute("button-without-protection-".concat(r), "true"), l.appendChild(s), Object.assign(l.style, a), (f = document.createElement("div")).className = "preferred-checkout-wrapper", f.style.cssText = o, f.appendChild(e), null != (c = t.getAttribute("name")) && c.includes("checkout") && (f.appendChild(l), n.insertBefore(f, t))))
                    }
                    var o;
                    null != (o = null == (o = null == (o = window.Route) ? void 0 : o.Protection) ? void 0 : o.readyStateManager) && o.isReady ? n() : null != (o = window.Route) && o.Protection ? window.Route.Protection.onReady(n) : console.warn("Route Protection is not available")
                }

                function E(t, e) {
                    for (var r = 0, n = e; r < n.length; r++) {
                        var o = n[r];
                        if (t.matches(o)) return 1
                    }
                }
                e.areButtonsEqual = function(t, e, r) {
                    void 0 === r && (r = []);
                    var n = R(t),
                        o = R(e);
                    return 0 < r.length && r.forEach((function(t) {
                        var e = n.dataAttributes.class;
                        e && e.includes(t) && (n.dataAttributes.class = e.replace(t, "").replace(/\s{2,}/g, " ").trim(), o.dataAttributes.class = o.dataAttributes.class.replace("route-class-" + t, "").replace(/\s{2,}/g, " ").trim())
                    })), JSON.stringify(n) === JSON.stringify(o)
                }, e.checkoutButtonEventDispatcher = function(t, e) {
                    return n(this, void 0, void 0, (function() {
                        var r, i, a, u, s, f, p, h, v, b = this;
                        return o(this, (function(m) {
                            switch (m.label) {
                                case 0:
                                    return e.preventDefault(), e.stopImmediatePropagation(), r = document.getElementsByTagName("route-protect-widget"), i = r && r[0] && (window.Route.Protection.isPreferredCheckoutWidget || "true" == r[0].getAttribute("status")) && "no_coverage" !== r[0].getAttribute("payer") && "merchant" !== r[0].getAttribute("payer"), a = r[0] && r[0].getAttribute("quote").replace(/[^\d.]/g, ""), y.log("Route Package Protection $".concat(a), {
                                        quote: a,
                                        placement: r
                                    }), s = l.default.getState().product.variants, !a || !s || s.length <= 0 ? (g(t), [2, !1]) : [4, l.default.getState().getClosestRouteVariant(parseFloat(a))];
                                case 1:
                                    return m.sent(), u = window.Route.Protection.getGrafanaFaroWebClientFactory(), [4, l.default.getState().getCart()];
                                case 2:
                                    return m.sent(), s = l.default.getState(), f = s.merchantId, p = s.storeDomain, h = s.cart, w || u.log(["Shopify Widget: Checkout button was triggered by customer"], {
                                        context: {
                                            merchantId: f,
                                            storeDomain: p,
                                            status: String(i),
                                            payer: r[0].getAttribute("payer"),
                                            quote: a,
                                            currency: null == h ? void 0 : h.currency,
                                            tagName: t.tagName || ""
                                        }
                                    }), i ? w ? ((null == (v = null == h ? void 0 : h.items) ? void 0 : v.find((function(t) {
                                        return c.Assert.isProductFromRoute(t.vendor)
                                    }))) && g(t), [2]) : (window.Route.Protection.isPreferredCheckoutWidget && window.Route.Protection.trackEvent("preferred_checkout_frontend_event", {
                                        preferred_checkout_button_click: "protected"
                                    }), y.log("Shopify Widget: Checkout button was triggered!", {
                                        status: String(i),
                                        concurrency: w
                                    }), u.log(["Shopify Widget: Checkout button was triggered and it should add Route Package Protection"], {
                                        context: {
                                            merchantId: f,
                                            storeDomain: p,
                                            status: String(i),
                                            payer: r[0].getAttribute("payer"),
                                            quote: a,
                                            currency: null == h ? void 0 : h.currency,
                                            tagName: t.tagName || ""
                                        }
                                    }), w = !0, v = {
                                        maxRetries: 10,
                                        delay: 200,
                                        onSuccess: function(e, r) {
                                            y.log("Shopify Widget: Route successfully added", e), window.Route.Protection.getGrafanaFaroWebClientFactory().log(["Shopify Widget: Route successfully added"], {
                                                context: {
                                                    quantity: String(e.quantity),
                                                    variantId: String(e.variantId),
                                                    price: String(e.price / 100),
                                                    currency: null == h ? void 0 : h.currency,
                                                    retryAttempt: String(r),
                                                    tagName: t.tagName || ""
                                                }
                                            }), setTimeout((function() {
                                                return g(t)
                                            }), 250)
                                        },
                                        onError: function(e, n) {
                                            window.Route.Protection.getGrafanaFaroWebClientFactory().log(["Shopify Widget: Error when trying to add Route Package Protection"], {
                                                context: {
                                                    merchantId: f,
                                                    storeDomain: p,
                                                    status: String(i),
                                                    payer: r[0].getAttribute("payer"),
                                                    quote: a,
                                                    currency: null == h ? void 0 : h.currency,
                                                    error: (null == e ? void 0 : e.message) || JSON.stringify(e),
                                                    retryAttempt: String(n),
                                                    tagName: t.tagName || ""
                                                }
                                            }), y.error("Shopify Widget: Error when trying to add Route Package Protection", e), setTimeout((function() {
                                                return g(t)
                                            }), 250)
                                        }
                                    }, [4, (0, d.retryUntil)((function() {
                                        return n(b, void 0, void 0, (function() {
                                            return o(this, (function(t) {
                                                switch (t.label) {
                                                    case 0:
                                                        return [4, l.default.getState().addRouteProduct()];
                                                    case 1:
                                                        return [2, t.sent()]
                                                }
                                            }))
                                        }))
                                    }), v)]) : [3, 4];
                                case 3:
                                    return m.sent(), [3, 5];
                                case 4:
                                    g(t), m.label = 5;
                                case 5:
                                    return [2, !1]
                            }
                        }))
                    }))
                }, e.fetchProtectCoreScript = function(t) {
                    return new Promise((function(e, r) {
                        if (null != (n = window.Route) && n.Protection) return e(u);
                        var n = document.createElement("script");
                        n.setAttribute("src", t), n.setAttribute("data-route-widget", "true"), n.addEventListener("load", e), n.addEventListener("error", (function(t) {
                            r(new Error("Failed to load the Protect Core"))
                        })), 0 < document.querySelectorAll("[data-route-widget]").length || document.body.appendChild(n)
                    }))
                }
            },
            739: (t, e, r) => {
                r.r(e), r.d(e, {
                    createStore: () => o,
                    default: () => i
                });
                let n = t => {
                        let e, r = new Set;
                        var n = (t, n) => {
                                if (t = "function" == typeof t ? t(e) : t, !Object.is(t, e)) {
                                    let o = e;
                                    e = (null != n ? n : "object" != typeof t || null === t) ? t : Object.assign({}, e, t), r.forEach((t => t(e, o)))
                                }
                            },
                            o = () => e,
                            i = {
                                setState: n,
                                getState: o,
                                getInitialState: () => a,
                                subscribe: t => (r.add(t), () => r.delete(t)),
                                destroy: () => {
                                    r.clear()
                                }
                            };
                        let a = e = t(n, o, i);
                        return i
                    },
                    o = t => t ? n(t) : n;
                var i = t => o(t)
            },
            742: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.getCacheByKey = e.setCacheByKey = e.cacheIds = void 0, r(35));
                e.cacheIds = {
                    routeProductIsPresentInCart: "route-product-is-present-in-cart",
                    routeProductRemovedByRoute: "route-product-removed-by-route"
                }, e.setCacheByKey = function(t) {
                    return n(void 0, [t], void 0, (function(t) {
                        var e = t.cacheID,
                            r = t.cacheData,
                            n = t.cacheTTL;
                        return o(this, (function(t) {
                            return (0, i.createCacheClient)().set(e, r, n), [2]
                        }))
                    }))
                }, e.getCacheByKey = function(t) {
                    return n(void 0, [t], void 0, (function(t) {
                        var e = t.cacheID;
                        return o(this, (function(t) {
                            return [2, (0, i.createCacheClient)().get(e)]
                        }))
                    }))
                }
            },
            775: function(t, e) {
                var r = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    n = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    o = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.GetCartUseCase = void 0, i.prototype.execute = function() {
                        return r(this, void 0, void 0, (function() {
                            var t, e, r, o, i, a, u, c, s, l, f, d;
                            return n(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.shopifyRepository.getCart()];
                                    case 1:
                                        return l = n.sent(), t = l.itemsCount, e = l.items, r = l.itemsSubtotalPrice, o = l.originalTotalPrice, i = l.requiresShipping, a = l.token, u = l.totalDiscount, c = l.totalPrice, s = l.currency, l = l.attributes, f = 0, e && 0 < e.length && (d = e.filter((function(t) {
                                            return t.requires_shipping && "route" !== (null == (t = t.vendor) ? void 0 : t.toLowerCase())
                                        })), f = d.reduce((function(t, e) {
                                            return t + (e.original_line_price || e.final_line_price)
                                        }), 0)), [2, {
                                            itemsCount: t,
                                            items: e,
                                            itemsSubtotalPrice: r,
                                            originalTotalPrice: o,
                                            requiresShipping: i,
                                            token: a,
                                            totalDiscount: u,
                                            totalPrice: c,
                                            currency: s,
                                            subtotal: f,
                                            attributes: l
                                        }]
                                }
                            }))
                        }))
                    }, i);

                function i(t) {
                    this.shopifyRepository = t
                }
                e.GetCartUseCase = o
            },
            779: (t, e) => {
                function r() {}
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.Assert = void 0, r.isNullOrEmpty = function(t) {
                    return "object" == typeof t && null !== t ? 0 === Object.keys(t).length : null == t || "" === t
                }, r.isNotNullOrEmpty = function(t) {
                    return !this.isNullOrEmpty(t)
                }, r.isNotNumber = function(t) {
                    return isNaN(t)
                }, r.isValidShopifyDomain = function(t) {
                    return t && "" !== t && t.includes(".myshopify.com")
                }, r.isUrl = function(t) {
                    return new RegExp("^(https?:\\/\\/)?((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|((\\d{1,3}\\.){3}\\d{1,3}))(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*(\\?[;&a-z\\d%_.~+=-]*)?(\\#[-a-z\\d_]*)?$", "i").test(t)
                }, r.isProductFromRoute = function(t) {
                    return t && "route" === t.trim().toLowerCase()
                }, e.Assert = r
            },
            792: (t, e) => {
                function r() {
                    this.consoleLogger = console, this.icons = {
                        INFO: "ℹ️",
                        ERROR: "❌",
                        WARN: "⚠️",
                        LOG: "📝",
                        DEBUG: "🐛"
                    }
                }
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.ConsoleLoggerAdapter = void 0, r.prototype.info = function(t, e) {
                    this.logMessage(this.consoleLogger.info.bind(this.consoleLogger), "INFO", t, e)
                }, r.prototype.error = function(t, e) {
                    this.logMessage(this.consoleLogger.error.bind(this.consoleLogger), "ERROR", t, e)
                }, r.prototype.warn = function(t, e) {
                    this.logMessage(this.consoleLogger.warn.bind(this.consoleLogger), "WARN", t, e)
                }, r.prototype.debug = function(t, e) {
                    this.logMessage(this.consoleLogger.debug.bind(this.consoleLogger), "DEBUG", t, e)
                }, r.prototype.log = function(t, e) {
                    this.logMessage(this.consoleLogger.log.bind(this.consoleLogger), "LOG", t, e)
                }, r.prototype.logMessage = function(t, e, r, n) {
                    this.canProcessLog() && (e = "".concat(this.icons[e], " [ROUTE][").concat(e, "] ").concat(r), n ? t(e, n) : t(e))
                }, r.prototype.canProcessLog = function() {
                    return window && window.location && window.location.href.includes("#route-debug") || window.localStorage && "1" === window.localStorage.getItem("route-debug")
                }, e.ConsoleLoggerAdapter = r
            },
            801: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.AddRouteVariantUseCase = void 0, r(779));

                function a(t) {
                    this.shopifyRepository = t
                }
                a.prototype.execute = function(t) {
                    return n(this, void 0, void 0, (function() {
                        var e;
                        return o(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    if (!t) throw new Error("Input is required");
                                    if (i.Assert.isNullOrEmpty(t.productId)) throw new Error("ProductID is required");
                                    if (i.Assert.isNotNumber(t.productId)) throw new Error("ProductID must be a number");
                                    return e = {
                                        items: [{
                                            id: t.productId,
                                            quantity: 1
                                        }]
                                    }, window.routeSkipInterception = !0, [4, this.shopifyRepository.addCart(e)];
                                case 1:
                                    if (e = r.sent().items, window.routeSkipInterception = !1, 0 === e.length) throw new Error("Product not added successfully to the cart");
                                    return [2, Promise.resolve({
                                        productId: e[0].id,
                                        quantity: e[0].quantity,
                                        variantId: e[0].variant_id,
                                        price: e[0].price
                                    })]
                            }
                        }))
                    }))
                }, e.AddRouteVariantUseCase = a
            },
            818: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.global = void 0, e.global = {
                    shopifyServiceURL: "https://shopify.route.com",
                    protectCoreURL: "https://protection-widget.route.com/protect.core.js"
                }
            },
            835: function(t, e, r) {
                var n = this && this.__assign || function() {
                        return (n = Object.assign || function(t) {
                            for (var e, r = 1, n = arguments.length; r < n; r++)
                                for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                            return t
                        }).apply(this, arguments)
                    },
                    o = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    i = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    a = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.GetRouteVariantsUseCase = void 0, r(779));

                function u(t) {
                    this.shopifyApiRepository = t
                }
                u.prototype.execute = function(t) {
                    return o(this, void 0, void 0, (function() {
                        return i(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    if (a.Assert.isNullOrEmpty(t)) throw new Error("Missing Input");
                                    if (a.Assert.isNullOrEmpty(t.shopifyDomain)) throw new Error("Missing Shopify Domain");
                                    if (a.Assert.isUrl(t.shopifyDomain)) return [4, this.shopifyApiRepository.getRouteVariants()];
                                    throw new Error("Missing valid Shopify Domain or Store Domain");
                                case 1:
                                    return [2, e.sent().map((function(t) {
                                        return n(n({}, t), {
                                            id: t.id,
                                            price: Number(t.price) / 100
                                        })
                                    }))]
                            }
                        }))
                    }))
                }, e.GetRouteVariantsUseCase = u
            },
            857: function(t, e) {
                var r = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    n = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.delay = void 0, e.delay = function(t) {
                    return r(void 0, void 0, void 0, (function() {
                        return n(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, new Promise((function(e) {
                                        return setTimeout(e, t)
                                    }))];
                                case 1:
                                    return e.sent(), [2]
                            }
                        }))
                    }))
                }
            },
            876: (t, e, r) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.createShopifyRepositoryFactory = void 0;
                var n = r(120),
                    o = r(977),
                    i = r(224);
                e.createShopifyRepositoryFactory = function() {
                    var t = (0, n.getStoreDomain)(),
                        e = (0, o.createHttpClientWithRetry)();
                    return new i.ShopifyRepository({
                        httpClient: e,
                        storeDomain: t
                    })
                }
            },
            912: function(t, e, r) {
                var n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.createCartSlice = void 0, r(624)),
                    a = r(779),
                    u = r(742);
                e.createCartSlice = function(t, e) {
                    return {
                        getCart: function() {
                            return n(void 0, void 0, void 0, (function() {
                                var e, r, n, c, s, l, f, d, p, h, y;
                                return o(this, (function(o) {
                                    switch (o.label) {
                                        case 0:
                                            return [4, (0, i.getCartUseCaseFactory)().execute()];
                                        case 1:
                                            return y = o.sent(), e = y.itemsCount, r = y.items, n = y.itemsSubtotalPrice, c = y.originalTotalPrice, s = y.requiresShipping, l = y.token, f = y.totalDiscount, d = y.totalPrice, p = y.currency, h = y.subtotal, y = y.attributes, r && 0 < r.length && r.some((function(t) {
                                                return a.Assert.isProductFromRoute(t.vendor)
                                            })) ? [4, (0, u.setCacheByKey)({
                                                cacheID: u.cacheIds.routeProductIsPresentInCart,
                                                cacheData: {
                                                    routeProductIsPresent: !0
                                                },
                                                cacheTTL: 864e5
                                            })] : [3, 3];
                                        case 2:
                                            o.sent(), o.label = 3;
                                        case 3:
                                            return t({
                                                cart: {
                                                    token: l,
                                                    itemsCount: e,
                                                    items: r,
                                                    itemsSubtotalPrice: n,
                                                    originalTotalPrice: c,
                                                    requiresShipping: s,
                                                    totalDiscount: f,
                                                    totalPrice: d,
                                                    subtotal: h,
                                                    currency: p,
                                                    attributes: y
                                                }
                                            }), [2]
                                    }
                                }))
                            }))
                        }
                    }
                }
            },
            943: function(t, e) {
                var r = this && this.__assign || function() {
                        return (r = Object.assign || function(t) {
                            for (var e, r = 1, n = arguments.length; r < n; r++)
                                for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                            return t
                        }).apply(this, arguments)
                    },
                    n = this && this.__awaiter || function(t, e, r, n) {
                        return new(r = r || Promise)((function(o, i) {
                            function a(t) {
                                try {
                                    c(n.next(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function u(t) {
                                try {
                                    c(n.throw(t))
                                } catch (t) {
                                    i(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? o(t.value) : ((e = t.value) instanceof r ? e : new r((function(t) {
                                    t(e)
                                }))).then(a, u)
                            }
                            c((n = n.apply(t, e || [])).next())
                        }))
                    },
                    o = this && this.__generator || function(t, e) {
                        var r, n, o, i = {
                                label: 0,
                                sent: function() {
                                    if (1 & o[0]) throw o[1];
                                    return o[1]
                                },
                                trys: [],
                                ops: []
                            },
                            a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                        return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function u(u) {
                            return function(c) {
                                var s = [u, c];
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; i = a && s[a = 0] ? 0 : i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, (s = o ? [2 & s[0], o.value] : s)[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = 0 < (o = i.trys).length && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) i.label = s[1];
                                            else if (6 === s[0] && i.label < o[1]) i.label = o[1], o = s;
                                            else {
                                                if (!(o && i.label < o[2])) {
                                                    o[2] && i.ops.pop(), i.trys.pop();
                                                    continue
                                                }
                                                i.label = o[2], i.ops.push(s)
                                            }
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }
                        }
                    },
                    i = (Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.HttpClient = void 0, a.prototype.request = function(t, e, r) {
                        return n(this, void 0, void 0, (function() {
                            var i = this;
                            return o(this, (function(a) {
                                return this._retryStrategy ? [2, this._retryStrategy.execute((function() {
                                    return n(i, void 0, void 0, (function() {
                                        return o(this, (function(n) {
                                            switch (n.label) {
                                                case 0:
                                                    return [4, this._performRequest(t, e, r)];
                                                case 1:
                                                    return [2, n.sent()]
                                            }
                                        }))
                                    }))
                                }))] : [2, this._performRequest(t, e, r)]
                            }))
                        }))
                    }, a.prototype._performRequest = function(t, e, i) {
                        return n(this, void 0, void 0, (function() {
                            var n;
                            return o(this, (function(o) {
                                switch (o.label) {
                                    case 0:
                                        return [4, fetch(e, r({
                                            method: t
                                        }, i))];
                                    case 1:
                                        if ((n = o.sent()).ok) return [2, n];
                                        throw new Error("Request failed with status ".concat(n.status))
                                }
                            }))
                        }))
                    }, a.prototype.get = function(t, e) {
                        return n(this, void 0, void 0, (function() {
                            return o(this, (function(r) {
                                return [2, this.request("GET", t, e)]
                            }))
                        }))
                    }, a.prototype.post = function(t, e) {
                        return n(this, void 0, void 0, (function() {
                            return o(this, (function(r) {
                                return [2, this.request("POST", t, e)]
                            }))
                        }))
                    }, a);

                function a(t) {
                    this._retryStrategy = t._retryStrategy
                }
                e.HttpClient = i
            },
            977: (t, e, r) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.createHttpClient = function(t) {
                    var e = new n.HttpClientBuilder;
                    return t ? e.withRetryStrategy(t).build() : e.build()
                }, e.createHttpClientWithRetry = function(t) {
                    var e = new n.HttpClientBuilder;
                    return t ? e.withRetryStrategy(t).build() : e.withRetryStrategy({
                        maxRetries: 3,
                        retryDelayMs: 1e3,
                        backoffFactor: 2
                    }).build()
                };
                var n = r(720)
            }
        },
        e = {};

    function r(n) {
        var o = e[n];
        return void 0 !== o || (o = e[n] = {
            exports: {}
        }, t[n].call(o.exports, o, o.exports, r)), o.exports
    }
    r.d = (t, e) => {
        for (var n in e) r.o(e, n) && !r.o(t, n) && Object.defineProperty(t, n, {
            enumerable: !0,
            get: e[n]
        })
    }, r.o = (t, e) => Object.prototype.hasOwnProperty.call(t, e), r.r = t => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, r(675)
})();