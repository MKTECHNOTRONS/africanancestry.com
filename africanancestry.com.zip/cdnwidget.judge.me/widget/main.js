(function() {
    jdgm.$(function(e) {
        var t;
        return e(".jdgm-fake-sample-review-widget").length > 0 && (t = e(".jdgm-fake-sample-review-widget").html(), e(".jdgm-review-widget").each(function(n, r) {
            var i, d;
            return d = e(r), i = d.find(".jdgm-rev-widg"), i.length <= 0 || parseInt(i.data("number-of-reviews")) <= 0 ? d.html(t) : void 0
        })), e(".jdgm-fake-sample-preview-badge").length > 0 ? (t = e(".jdgm-fake-sample-preview-badge").html(), e(".jdgm-preview-badge:lt(3)").each(function(n, r) {
            var i, d;
            return d = e(r), i = d.find(".jdgm-prev-badge"), i.length <= 0 || parseInt(i.data("number-of-reviews")) <= 0 ? (d.html(t), d.addClass("jdgm--with-fake-sample-content"), d.show()) : void 0
        })) : void 0
    })
}).call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/qa_badge"] = function(obj) {
            var __p = [];
            with(obj || {}) {
                __p.push("");
                var badgePlacementClass = bottomPlacement ? "jdgm-qa-badge__pos-below" : "";
                __p.push("\n<span class='jdgm-qa-badge ", badgePlacementClass, "'>\n  "), showIcon && __p.push("\n    <span class='jdgm-qa-badge__icon' style='color: ", iconColor, ";'>\n    </span>\n  "), __p.push("\n  <span class='jdgm-qa-badge__text'>\n    ", text, "\n  </span>\n</span>\n")
            }
            return __p.join("")
        }
    }.call(this), jdgm.$(function(e) {
        jdgm.templates = jdgm.templates || {}
    }),
    function() {
        var e, t, n;
        e = jdgm.$, t = ["Customer reviews", "Customer Reviews", "Review", "Reviews", "REVIEWS", "REVIEWS for this Product", "Q&A"], jdgm.isWidgetVisible || (jdgm.isWidgetVisible = function() {
            return jdgm.visibleRevWidget().length > 0
        }), jdgm._scrollDownToWidget || (jdgm._scrollDownToWidget = function() {
            var e;
            return e = jdgm.isWidgetVisible() ? 0 : 500, setTimeout(function() {
                return jdgm.isWidgetVisible() ? jdgm.scrollTo(jdgm.visibleRevWidget(), jdgmSettings.scrollTopOffset) : void 0
            }, e)
        }), jdgm._clickEasyTabsApp || (jdgm._clickEasyTabsApp = function() {
            return setTimeout(function() {
                var t;
                return t = e("#" + e(".jdgm-review-widget").parent().attr("aria-labelledby"))[0], t ? t.click() : void 0
            }, 1500)
        }), jdgm._openTabAndScrollToRevWidget || (jdgm._openTabAndScrollToRevWidget = function() {
            return jdgm._openReviewTab(), jdgm._scrollDownToWidget()
        }), jdgm.clickElement = function(t, r) {
            return e(t + ":contains('" + r + "')").each(function(e, t) {
                return n(t.getAttribute("href")) ? void 0 : t.click()
            })
        }, n = function(e) {
            return null === e || void 0 === e ? !1 : "" === e || 0 !== e.indexOf("#") && 0 !== e.indexOf("javascript:void")
        }, jdgm._openReviewTab || (jdgm._openReviewTab = jdgmSettings.openReviewTab || function() {
            return !jdgm.isWidgetVisible() && jdgmSettings.revTabSelector && e(jdgmSettings.revTabSelector)[0].click(), jdgm.isWidgetVisible() || jdgm._clickEasyTabsApp(), e.each(t, function(e, t) {
                return jdgm.isWidgetVisible() ? !1 : (jdgm.clickElement("a", t), jdgm.isWidgetVisible() ? !1 : jdgm.clickElement("li.tab__item", t))
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, d, o, a, g, u, m, l, s, c, f, j;
            return r = '.jdgm-widget.jdgm-preview-badge[data-auto-install="true"]', a = ["shopify"], o = [".page-width", ".wrapper", ".shopify-section"], t = e('[itemtype="http://schema.org/Product"] [itemtype="http://schema.org/Offer"]').first(), n = e('[itemtype="http://schema.org/Product"] :not(meta)[itemprop="name"]').first(), d = ".product-single__title, .ProductMeta__Title", i = '<div style="clear:both"></div>', u = function() {
                var i, o, a, u;
                return o = e(r), o.length <= 0 ? void 0 : (u = o.data("id"), i = e('.jdgm-preview-badge[data-id="' + u + '"]'), a = e(d), g(o.length, i.length, t.length || n.length || a.length) ? (e(r + ":not(:first)").remove(), s(a)) : o.remove())
            }, s = function(i) {
                return i.length > 0 ? i.after(e(r)) : n.length > 0 ? n.after(e(r)) : t.length > 0 ? t.before(e(r)) : void 0
            }, j = function() {
                return e(r).attr("data-auto-install", "processed")
            }, g = function(e, t, n) {
                return e && n && e === t
            }, c = function() {
                var t;
                return t = l(), t ? t.append(i).append(e('.jdgm-review-widget[data-auto-install="true"]')) : void 0
            }, l = function() {
                var t, n;
                return t = f(), n = o.find(function(e) {
                    return t.find(e).length > 0
                }), n ? e(t.find(n).last()) : t
            }, f = function() {
                var n;
                return t.length > 0 ? t.parents('[itemtype="http://schema.org/Product"]') : (n = e('[itemtype="http://schema.org/Product"]:not([itemprop="itemReviewed"])').first(), n.length > 0 ? n : e("main, body").last())
            }, (m = function() {
                return a.indexOf(jdgmSettings.platform) >= 0 ? (c(), u(), j()) : void 0
            })()
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, d, o, a, g, u, m, l;
            return n = ".jdgm-rev-widg__paginate-spinner-wrapper", i = ".jdgm-rev-widg__body", t = ".jdgm-rev-widg__body .jdgm-paginate", r = ".jdgm-rev-widg__primary-lang", m = function(e) {
                var r, o, a;
                return o = function() {
                    return jdgm.ajaxParamsFor(e)
                }, r = function() {
                    return jdgm.isWidgetLoadMore() ? (e.find(t).hide(), e.find(n).show()) : g(e)
                }, a = function(t) {
                    return jdgm.isWidgetLoadMore() ? jdgm._appendPaginateResultToBody(t, e, ".jdgm-rev", ".jdgm-rev-widg__reviews", d) : u(t, e)
                }, jdgm.setupPaginate(e.find(i), r, a, o)
            }, u = function(e, t, n) {
                var r;
                return null == n && (n = null), r = t.find(i), r.html(e.html), d(t), r.slideDown(), o(t, n)
            }, d = function(e) {
                return jdgm.customizeReviews(), jdgm.setupMediaGallery && jdgm.setupMediaGallery(e), e.find(n).hide()
            }, g = function(e, t) {
                return null == t && (t = null), jdgm.openSubtab(e, "reviews"), o(e, t), e.find(n).show(), e.find(i).hide()
            }, o = function(e, t) {
                var n, r;
                return null == t && (t = null), r = e.find(i), e.data("not-scroll-to") ? void 0 : (n = e, r.length > 0 && (n = r), null !== t && t.length > 0 && (n = t), jdgm.scrollTo(n))
            }, l = function(t) {
                var n, r, i, d;
                return jdgm.isVersion3 && (n = e(".jdgm-row-search")), i = function() {
                    return jdgm.ajaxParamsFor(t)
                }, r = function() {
                    return g(t, n)
                }, d = function(e) {
                    return u(e, t, n)
                }, jdgm.setupSearch(t, r, d, i)
            }, a = function(e, t) {
                var n, r, i;
                return r = function() {
                    return jdgm.ajaxParamsFor(t)
                }, n = function() {
                    return g(t)
                }, i = function(e) {
                    return u(e, t)
                }, jdgm.fetchSingleReview(t, e, n, i, r)
            }, jdgm._setupLoadReviewsEventsFor = function(e) {
                return jdgm._setupSortAndFilterFor(e, g, u), m(e), l(e)
            }, jdgm.eachRevWidgets(function(t) {
                return t.find(r).length > 0 ? void 0 : (jdgm._setupLoadReviewsEventsFor(t), e.urlParam("judgeme_review_uuid") ? setTimeout(function() {
                    return a(e.urlParam("judgeme_review_uuid"), t)
                }, 0) : void 0)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, d, o, a, g, u, m, l, s, c, f, j, v, _, p, h;
            if (jdgmSettings.widget_multilingual_sorting_enabled) return i = ".jdgm-rev-widg__paginate-spinner-wrapper", o = ".jdgm-rev-widg__body", r = ".jdgm-rev-widg__body .jdgm-paginate", d = ".jdgm-rev-widg__primary-lang", t = ".jdgm-rev-widg__other-lang", n = 3, s = function(e) {
                var t;
                return t = e.find(d).data("widget-locale"), jdgmSettings.enable_multi_locales_translations ? document.documentElement.lang : t
            }, h = function() {
                var e;
                return e = document.createEvent("Event"), e.initEvent("jdgm.multilingual_languages_loaded", !0, !0), document.dispatchEvent(e)
            }, p = function(e) {
                return v(e, !0), v(e, !1)
            }, f = function(e, t) {
                var r, i;
                return r = jdgm.ajaxParamsFor(e), r.search || r.keyword ? r : (i = jdgm.normalizeLanguage(s(e)), t ? r.primary_language = i : (r.exclude_language = i, r.per_page = n), r)
            }, v = function(n, r) {
                var o, g, u, m, l;
                return m = r ? d : t, o = n.find(m), u = function(e) {
                    return null == e && (e = r), f(n, e)
                }, g = function() {
                    return o.find(".jdgm-rev-widg__reviews").hide(), o.find(i).show()
                }, l = function(g) {
                    return (null != g ? g.html : void 0) ? ("carousel" === jdgmSettings.widget_theme && (n = e(".jdgm-rev-popup:visible .jdgm-widget__popup-content")), o = n.find(".jdgm-rev-widg__" + (r ? "primary" : "other") + "-content"), jdgm.isWidgetLoadMore() ? jdgm._appendPaginateResultToBody(g, o, ".jdgm-rev", ".jdgm-rev-widg__reviews", a) : o.html(g.html), r && !g.html.includes("jdgm-rev__body") && n.find(d).hide(), r || g.html.includes("jdgm-rev__body") || n.find(t).hide(), a(n), o.find(".jdgm-rev-widg__reviews").slideDown()) : (console.error("No HTML in response for " + (r ? "primary" : "other") + " section"), o.find(i).hide())
                }, r && jdgm._setupSortAndFilterFor(n, c, j, u), jdgm.setupPaginate(o, g, l, u)
            }, a = function(t) {
                return jdgm.customizeReviews(), jdgm.setupMediaGallery && jdgm.setupMediaGallery(t), t.find(i).hide(), t.find(".jdgm-rev-widg__primary-content, .jdgm-rev-widg__other-content").each(function() {
                    var t;
                    return t = e(this), t.find(".jdgm-rev__body").length ? void 0 : t.siblings(".jdgm-paginate").remove()
                })
            }, c = function(e, t) {
                return null == t && (t = null), jdgm.openSubtab(e, "reviews"), g(e, t), e.find(i).show(), e.find(o).hide()
            }, g = function(e, t) {
                var n, r;
                return null == t && (t = null), r = e.find(o), e.data("not-scroll-to") ? void 0 : (n = e, r.length > 0 && (n = r), null !== t && t.length > 0 && (n = t), jdgm.scrollTo(n))
            }, _ = function(t) {
                var n, r, i, d;
                return n = e(".jdgm-row-search"), i = function(e) {
                    return null == e && (e = !0), f(t, e)
                }, r = function() {
                    return c(t, n)
                }, d = function(e, r) {
                    return null == r && (r = {}), null == r.hideOtherLang && (r.hideOtherLang = !0), j(e, t, n, r)
                }, jdgm.setupSearch(t, r, d, i)
            }, l = function(e, t) {
                var n, r, i;
                return r = function() {
                    return jdgm.ajaxParamsFor(t)
                }, n = function() {
                    return c(t)
                }, i = function(e) {
                    return j(e, t)
                }, jdgm.fetchSingleReview(t, e, n, i, r)
            }, j = function(e, n, r, i) {
                var d, u;
                return null == r && (r = null), null == i && (i = {}), (null != e ? e.html : void 0) ? (d = n.find(t), d.length > 0 && (i.otherLang ? e.html.includes("jdgm-rev__body") ? d.show() : d.hide() : i.hideOtherLang && d.hide()), u = n.find(".jdgm-rev-widg__" + (i.otherLang ? "other" : "primary") + "-content"), u.html(e.html), a(n), n.find(o).slideDown(), g(n, r)) : void 0
            }, u = function(r) {
                var o, g, u, m, l;
                return m = jdgm.normalizeLanguage(s(r)), l = r.find(d).data("widget-locale"), o = r.find(".jdgm-rev-widg__other-content"), o.find(".jdgm-rev__body").length || r.find(t).hide(), jdgmSettings.enable_multi_locales_translations && m !== l ? (u = function(t) {
                    var n, o, g;
                    return null == t && (t = function() {}), o = jdgm.ajaxParamsFor(r), o.primary_language = m, n = function() {
                        return r.find(".jdgm-rev-widg__primary-content").find(".jdgm-rev-widg__reviews").hide(), r.find(d).show(), r.find(d).find(i).show()
                    }, g = function(e) {
                        return (null != e ? e.html : void 0) ? (r.find(".jdgm-rev-widg__primary-content").html(e.html), a(r), r.find(d).attr("data-widget-locale", m)) : console.error("No HTML in response when reloading primary section for locale:", m), r.find(d).find(i).hide(), e.html.includes("jdgm-rev__body") || r.find(d).hide(), t()
                    }, n(), e.ajax({
                        url: jdgm.HTTPS_HOST + "/reviews/reviews_for_widget",
                        data: o,
                        success: g,
                        error: function(e, t, n) {
                            return console.error("Error reloading primary section for locale:", m), console.error("Status:", t), console.error("Error:", n), r.find(d).find(i).hide()
                        }
                    })
                }, g = function(d) {
                    var o, g, u;
                    return null == d && (d = function() {}), g = jdgm.ajaxParamsFor(r), g.exclude_language = m, g.per_page = n, o = function() {
                        return r.find(".jdgm-rev-widg__other-content").find(".jdgm-rev-widg__reviews").hide(), r.find(t).show(), r.find(t).find(i).show()
                    }, u = function(e) {
                        return (null != e ? e.html : void 0) ? (r.find(".jdgm-rev-widg__other-content").html(e.html), a(r)) : console.error("No HTML in response when reloading other section"), r.find(t).find(i).hide(), e.html.includes("jdgm-rev__body") || r.find(t).hide(), d()
                    }, o(), e.ajax({
                        url: jdgm.HTTPS_HOST + "/reviews/reviews_for_widget",
                        data: g,
                        success: u,
                        error: function(e, n, d) {
                            return console.error("Error reloading other section"), console.error("Status:", n), console.error("Error:", d), r.find(t).find(i).hide()
                        }
                    })
                }, Promise.all([new Promise(function(e) {
                    return u(e)
                }), new Promise(function(e) {
                    return g(e)
                })]).then(function() {
                    return h()
                })) : void h()
            }, m = function(e) {
                var t;
                return t = e.find(".jdgm-rev-widg__other-lang"), t.length > 0 ? t.find(".jdgm-rev-widg__section-title").text(jdgmSettings.widget_other_languages_heading) : void 0
            }, jdgm.eachRevWidgets(function(t) {
                return t.find(d).length > 0 ? (_(t), m(t), p(t), u(t), e.urlParam("judgeme_review_uuid") ? setTimeout(function() {
                    return l(e.urlParam("judgeme_review_uuid"), t)
                }, 0) : void 0) : void 0
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t;
            return t = function(e) {
                return "0px" === e.css("fontSize") ? e.css("fontSize", "14px") : void 0
            }, jdgm.eachRevWidgets(function(e) {
                var t;
                return t = e.closest(":visible").width(), (t > 420 && 680 >= t || jdgmSettings.smallReviewWidget) && e.addClass("jdgm-review-widget--medium"), 420 >= t ? e.addClass("jdgm-review-widget--small") : void 0
            }), jdgm.asyncEach(e(".jdgm-widget"), function(n) {
                return t(e(n))
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, d;
            return jdgm.badge = function() {
                return console.log("This function is no longer needed. Please remove it.")
            }, jdgm.customizeBadges = function() {
                var n;
                return n = e(".jdgm-preview-badge:not(." + jdgm.DONE_SETUP_CLASS + ")"), jdgm.asyncEach(n, function(n) {
                    var r, o, a, g, u;
                    return o = e(n), jdgm._addEmptyPreviewBadge(o), r = o.find(".jdgm-prev-badge__text"), u = o.find(".jdgm-prev-badge").data("number-of-reviews"), a = parseFloat(o.find(".jdgm-prev-badge").data("average-rating")), g = o.find(".jdgm-prev-badge").data("number-of-questions"), o.hasClass("jdgm--with-fake-sample-content") || jdgm._customizeBadgeTexts(r, u, a), jdgmSettings.preview_badge_show_question_text && jdgmSettings.enable_question_anwser && t(o.find(".jdgm-prev-badge"), g), d(o), i(o)
                }), n.addClass(jdgm.DONE_SETUP_CLASS)
            }, t = function(e, t) {
                var r, i, d;
                return d = n(t), r = "same-row" !== jdgmSettings.qa_badge_position, i = JST["templates/shopify_v2/qa_badge"]({
                    text: d,
                    bottomPlacement: r,
                    showIcon: jdgmSettings.qa_badge_show_icon,
                    iconColor: jdgmSettings.qa_badge_icon_color || "inherit"
                }), e.append(i)
            }, n = function(e) {
                return e ? r(e) : jdgmSettings.preview_badge_no_question_text
            }, r = function(e) {
                var t, n;
                return (n = jdgmSettings.preview_badge_n_question_text) ? (t = n.replace("{{ number_of_questions }}", e), jdgm.pluralizeLongText(t, e)) : void 0
            }, d = function(e) {
                var t, n;
                return t = e.closest("a").attr("href") || "", n = e.data("id") === jdgm.caches.$revWidgets.data("id"), e.on("click", function(e) {
                    return n ? (jdgm._openTabAndScrollToRevWidget(), !1) : t ? (window.location.href = t.split("#")[0] + "#judgeme_product_reviews", !1) : void 0
                }), n || t ? e.addClass("jdgm-preview-badge--with-link") : void 0
            }, i = function(e) {
                var t, n;
                return t = e.css("text-align").indexOf("center") >= 0, n = jdgmSettings.enforce_center_preview_badge && t, e.toggleClass("enforce-center-preview-badge", n)
            }, jdgm.customizeBadges()
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, d, o, a, g, u, m;
            return t = "<div class='jdgm-quest-widg__body'></div>", i = ".jdgm-quest-widg__body", r = ".jdgm-rev-widg__paginate-spinner-wrapper", n = ".jdgm-quest-widg__body .jdgm-paginate", jdgm.fetchQuestsFirstTime = function(t) {
                var n, r, i, d, o;
                return d = t.find(".jdgm-rev-widg").data("number-of-questions") || t.data("number-of-questions") || 0, t.data("first-time-quests-load") || 0 >= d ? void 0 : (t.data("first-time-quests-load", !0), n = t.find(".jdgm-subtab__name.jdgm--active").data("tabname"), "questions" === n && m(t), r = t.data("id"), i = "api/questions/questions_for_widget", "example-product-id" === r && (i = "api/questions/fake_question_widget"), o = jdgmSettings.enable_ajax_cdn_cache && jdgm.SPECIAL_CDN_HOST_HTTPS || jdgm.API_HOST, o += "/", e.ajax({
                    url: "" + o + i,
                    data: {
                        product_id: r,
                        shop_domain: jdgm.shopDomain(),
                        platform: jdgmSettings.platform
                    },
                    success: function(e) {
                        return a(e, t)
                    }
                }))
            }, u = function(e) {
                var t, n, r;
                return t = e.find(".jdgm-rev-widg"), r = t.data("number-of-reviews") || 0, n = t.data("number-of-questions") || 0, 0 >= n ? void 0 : g(e, r, n)
            }, g = function(n, r, i) {
                var d, a;
                return a = [{
                    key: "reviews",
                    title: jdgmSettings.widget_reviews_subtab_text,
                    count: r
                }, {
                    key: "questions",
                    title: jdgmSettings.widget_questions_subtab_text,
                    count: i
                }], d = e(jdgm._renderSubtab(a)), jdgm.isVersion3 && "leex" === jdgmSettings.widget_theme ? n.find(".jdgm-rev-widg__actions").prepend(d) : d.insertAfter(n.find(".jdgm-rev-widg__header")), d.data("open-tab-callback", function(e) {
                    return o(n, e)
                }), e(t).insertAfter(n.find(".jdgm-rev-widg__body"))
            }, o = function(e, t) {
                return null == t && (t = "reviews"), e.find(".jdgm-rev-widg__body").toggle("reviews" === t), e.find(i).toggle("questions" === t), "questions" === t ? jdgm.fetchQuestsFirstTime(e) : void 0
            }, a = function(e, t) {
                return t.find(i).html(e.html), d(t), t.find(i).slideDown()
            }, d = function(e) {
                return jdgm._fixAuthorNameIfFromShop(e), jdgm.customizeQuestions(), e.find(n).text() <= 0 && e.find(n).remove(), e.find(r).hide()
            }, jdgm._setupPaginateForQuestionWidget = function(e) {
                var t, o, g;
                return o = function() {
                    return {
                        product_id: e.data("id")
                    }
                }, t = function() {
                    return jdgm.isWidgetLoadMore() ? (e.find(n).hide(), e.find(r).show()) : m(e)
                }, g = function(t) {
                    return jdgm.isWidgetLoadMore() ? jdgm._appendPaginateResultToBody(t, e, ".jdgm-quest", ".jdgm-quest-widg__questions", d) : a(t, e)
                }, jdgm.setupPaginate(e.find(i), t, g, o)
            }, m = function(e) {
                return e.find(r).show(), e.find(i).slideUp(), e.data("not-scroll-to") ? void 0 : jdgm.scrollTo(e)
            }, jdgmSettings.enable_question_anwser ? jdgm.eachRevWidgets(function(e) {
                return u(e), jdgm._setupPaginateForQuestionWidget(e)
            }) : void 0
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n;
            return t = "jdgm.doneSetup", n = document.createEvent("Event"), n.initEvent(t, !0, !0), document.dispatchEvent(n), jdgm._doneSetup = !0
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t;
            return t = jdgm._safeRun, e.each(jdgm.templates, function(e, n) {
                return t(n)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, d, o, a;
            return n = jdgm.CDN_HOST + "widget/form.js", t = ["judgeme_token", "judgeme_review_uuid", "judgeme_dynamic_form", "judgeme_follow_up_token", "judgeme_upload_pictures"], o = function() {
                return jdgm.loadScript(n), jdgm.loadCSS(jdgm.widgetPath("form.css"))
            }, d = function() {
                return jdgm.loadScript.requestedUrls.indexOf(n) >= 0
            }, a = function() {
                var e, n;
                return e = window.location, n = "#judgeme" === e.hash || "#judgeme_product_reviews" === e.hash, t.forEach(function(t) {
                    return n || (n = e.search.indexOf(t) >= 0)
                }), n
            }, r = function() {
                return e(document).on("click", ".jdgm-write-rev-link, .jdgm-ask-question-btn", function(e) {
                    return d() ? void 0 : (o(), !1)
                })
            }, i = function() {
                var t;
                return d() ? void jdgm.ScrollEvent.dettach("checkToLoadFormJsFile") : (t = !1, jdgm.asyncEach(e(".jdgm-write-rev-link, .jdgm-ask-question-btn"), function(n) {
                    return t ? void 0 : jdgm.isInViewport(e(n).closest(":visible")[0]) ? (t = !0, o()) : void 0
                }))
            }, a() ? o() : (r(), i(), jdgm.ScrollEvent.attach(i, "checkToLoadFormJsFile"))
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, d, o;
            return n = ".jdgm-yt-video, .jdgm-rev__pic-link, .jdgm-rev__pic-img, .jdgm-vid-player, .jdgm-medal__image, .jdgm-gallery, .jdgm-ugc-media", t = jdgm.widgetPath("media.css"), o = function() {
                return jdgm.loadCSS(t, function() {
                    return jdgm.triggerEvent("doneLoadingMediaCss")
                }), jdgm.loadScript(jdgm.CDN_HOST + "widget/media.js")
            }, e(n).length > 0 && o(), r = e(".jdgm-gallery-data").data("json"), i = jdgmSettings.widget_show_photo_gallery && r && r.length > 0, d = "carousel" === jdgmSettings.widget_theme, (d || i) && o(), e(document).on("jdgm.beforeFetchingReviews", function(e, t) {
                return o()
            }), e(document).on("click", ".jdgm-ugc-media__thumbnail-link, .jdgm-ugc-media__load-more-btn", function(t) {
                return e(this).attr("data-execute-after-load", !0), o()
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, d, o, a, g, u, m, l, s, c;
            return jdgm.addProductJld = function(t, n) {
                var r, i, d, o, a, u;
                if (!g()) return r = e(".jdgm-rev-widg"), o = r.data("number-of-reviews"), a = r.data("average-rating"), t || (t = e("link[rel='canonical']").prop("href") + "#product"), n || (n = e(".jdgm-review-widget").data("product-title")), u = e(".jdgm-rev-widg .jdgm-rev").map(function() {
                    var t, n, r, i;
                    return i = e(this).find(".jdgm-rev__body").text().trim(), r = e(this).find(".jdgm-rev__rating").data("score"), t = e(this).find(".jdgm-rev__author").text().trim(), n = e(this).find(".jdgm-rev__timestamp").data("content"), {
                        "@type": "Review",
                        reviewRating: {
                            "@type": "Rating",
                            ratingValue: r
                        },
                        author: {
                            "@type": "Person",
                            name: t
                        },
                        reviewBody: i,
                        datePublished: n
                    }
                }).get(), o > 0 && a && t && n ? (i = document.createElement("script"), i.className = "jdgm-aggregate-rating-jld", i.type = "application/ld+json", d = {
                    "@context": "http://schema.org",
                    "@type": "Product",
                    "@id": t,
                    name: n,
                    aggregateRating: {
                        "@type": "AggregateRating",
                        ratingValue: a,
                        reviewCount: o
                    }
                }, jdgmSettings.enable_json_ld_products && (d.review = u), i.text = JSON.stringify(d), document.querySelector("body").appendChild(i)) : void 0
            }, jdgm.addProductJldIdToExistingSchema = function() {
                var e, t, n, r, i, d;
                for (d = document.querySelectorAll("script[type='application/ld+json']"), t = 0; t < d.length;) d[t].innerHTML.indexOf('"@type": "Product"') >= 0 && (i = d[t], -1 === i.innerHTML.indexOf("@id") && (e = window.location.pathname + "#product", n = '     "@id" : "' + e + '",\n', r = '"@type": "Product",\n', i.innerHTML = i.innerHTML.replace(r, r + n))), t++
            }, jdgm.addJldToAllReviewsPage = function(t) {
                var n, r, i, d, o;
                if (!g()) return n = e(".jdgm-all-reviews__header"), i = n.data("number-of-reviews"), d = n.data("average-rating"), t || (t = e('meta[property="og:site_name"]').attr("content") || e("title").text()), o = jdgmSettings.allReviewsPageStructuredDataType || "Product", i > 0 && d && t ? (r = document.createElement("script"), r.className = "jdgm-aggregate-rating-jld", r.type = "application/ld+json", r.text = JSON.stringify({
                    "@context": "http://schema.org",
                    "@type": o,
                    name: t,
                    aggregateRating: {
                        "@type": "AggregateRating",
                        ratingValue: d,
                        reviewCount: i
                    }
                }), document.querySelector("body").appendChild(r)) : void 0
            }, t = function() {
                return e.map(e('script[type="application/ld+json"]'), function(e) {
                    var t;
                    try {
                        return JSON.parse(e.innerHTML)
                    } catch (n) {
                        return t = n, {}
                    }
                })
            }, n = t(), jdgm.productJldUriId = function() {
                var e, t, g, u;
                return u = n.filter(d).filter(i), t = u[0], t ? t["@id"] : (e = o(n.filter(r).map(a)), (g = e[0]) ? g["@id"] : void 0)
            }, u = function(e) {
                return e.aggregateRating && "Product" === e["@type"]
            }, r = function(e) {
                return !!e["@graph"]
            }, d = function(e) {
                return "Product" === e["@type"]
            }, i = function(e) {
                return !!e["@id"]
            }, a = function(e) {
                return function(e) {
                    return e["@graph"].filter(d).filter(i)
                }
            }(this), o = function(e) {
                return [].concat.apply([], e)
            }, g = function() {
                return n.filter(u).length > 0
            }, l = function() {
                return 0 === e('[itemtype="http://schema.org/Product"]').length || 0 === e('[itemtype="https://schema.org/Product"]').length
            }, c = e(".jdgm-rich-snippet.jdgm--old").length <= 0, jdgmSettings.jldDisable || jdgmSettings.disable_json_ld || !c || (m = jdgmSettings.jldCanonicalUrl || jdgm.productJldUriId(), jdgm.addProductJld(m, jdgmSettings.jldProductTitle), s = window.location.href, s.indexOf("/products/") >= 0 && jdgm.addProductJldIdToExistingSchema()), jdgmSettings.add_json_ld_snippet_on_all_reviews_page && c && jdgm.addJldToAllReviewsPage(jdgmSettings.shopName), jdgmSettings.removeMicrodata || jdgmSettings.remove_microdata_snippet || l() ? e(".jdgm-rich-snippet").remove() : void 0
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, d, o, a, g, u, m;
            return t = 18e5, n = "jdgm_rs_referral", r = ["ref", "utm_source", "utm_campaign", "utm_medium"], i = r.slice().concat(["jdgm_referral_location", "jdgm_referral_influencer", "jdgm_referral_manager", "jdgm_ref_id"]), m = function() {
                var e, r, i, a;
                if (e = Date.now(), "judgeme-review-site" === jdgm.$.urlParam("utm_campaign")) a = u(e), i = localStorage.getItem(n), i && i.length > 0 && (r = JSON.parse(i).trackingAllowed), a.trackingAllowed = o(r);
                else {
                    if (a = localStorage.getItem(n), !(a && a.length > 0)) return;
                    a = JSON.parse(a), g() && d(a), a.hasExpired || (a.hasExpired = e - a.lastActivityAt > t), a.trackingAllowed = o(a.trackingAllowed)
                }
                return a.lastActivityAt = e, localStorage.setItem(n, JSON.stringify(a))
            }, g = function() {
                var e;
                return e = 0 === document.referrer.indexOf(jdgm.HTTPS_HOST) || 0 === document.referrer.indexOf(window.location.origin), document.referrer.length > 0 && !e || a()
            }, u = function(t) {
                var n;
                return n = {
                    createdAt: t,
                    referralData: {
                        landing: window.location.pathname,
                        referrer: document.referrer
                    },
                    otherReferralCount: 0,
                    lastOtherReferralData: {},
                    hasExpired: !1,
                    id: (1e16 * Math.random()).toString(36).substring(0, 10)
                }, e.each(i, function(e, t) {
                    return n.referralData[t] = jdgm.$.urlParam(t)
                }), n
            }, d = function(t) {
                return t.otherReferralCount = (parseInt(t.otherReferralCount) || 0) + 1, t.lastOtherReferralData = {
                    landing: window.location.pathname,
                    referrer: document.referrer
                }, e.each(r, function(e, n) {
                    return t.lastOtherReferralData[n] = jdgm.$.urlParam(n)
                })
            }, a = function() {
                var t;
                return t = !1, e.each(r, function(e, n) {
                    return jdgm.$.urlParam(n) ? t = !0 : void 0
                }), t
            }, o = function(e) {
                try {
                    return window.Shopify && window.Shopify.customerPrivacy ? window.Shopify.customerPrivacy.analyticsProcessingAllowed() : e
                } catch (t) {
                    return console.log("Something went wrong with Shopify.customerPrivacy API"), e
                }
            }, m()
        })
    }.call(this);