/*!
 * Bootstrap v4.4.1 (https://getbootstrap.com/)
 * Copyright 2011-2019 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */
(function(global, factory) {
    typeof exports == "object" && typeof module != "undefined" ? factory(exports, require("jquery"), require("popper.js")) : typeof define == "function" && define.amd ? define(["exports", "jquery", "popper.js"], factory) : (global = global || self, factory(global.bootstrap = {}, global.jQuery, global.Popper))
})(this, function(exports2, $, Popper) {
    "use strict";
    $ = $ && $.hasOwnProperty("default") ? $.default : $, Popper = Popper && Popper.hasOwnProperty("default") ? Popper.default : Popper;

    function _defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || !1, descriptor.configurable = !0, "value" in descriptor && (descriptor.writable = !0), Object.defineProperty(target, descriptor.key, descriptor)
        }
    }

    function _createClass(Constructor, protoProps, staticProps) {
        return protoProps && _defineProperties(Constructor.prototype, protoProps), staticProps && _defineProperties(Constructor, staticProps), Constructor
    }

    function _defineProperty(obj, key, value) {
        return key in obj ? Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : obj[key] = value, obj
    }

    function ownKeys(object, enumerableOnly) {
        var keys = Object.keys(object);
        if (Object.getOwnPropertySymbols) {
            var symbols = Object.getOwnPropertySymbols(object);
            enumerableOnly && (symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable
            })), keys.push.apply(keys, symbols)
        }
        return keys
    }

    function _objectSpread2(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i] != null ? arguments[i] : {};
            i % 2 ? ownKeys(Object(source), !0).forEach(function(key) {
                _defineProperty(target, key, source[key])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
                Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key))
            })
        }
        return target
    }

    function _inheritsLoose(subClass, superClass) {
        subClass.prototype = Object.create(superClass.prototype), subClass.prototype.constructor = subClass, subClass.__proto__ = superClass
    }
    var TRANSITION_END = "transitionend",
        MAX_UID = 1e6,
        MILLISECONDS_MULTIPLIER = 1e3;

    function toType(obj) {
        return {}.toString.call(obj).match(/\s([a-z]+)/i)[1].toLowerCase()
    }

    function getSpecialTransitionEndEvent() {
        return {
            bindType: TRANSITION_END,
            delegateType: TRANSITION_END,
            handle: function(event) {
                if ($(event.target).is(this)) return event.handleObj.handler.apply(this, arguments)
            }
        }
    }

    function transitionEndEmulator(duration) {
        var _this = this,
            called = !1;
        return $(this).one(Util.TRANSITION_END, function() {
            called = !0
        }), setTimeout(function() {
            called || Util.triggerTransitionEnd(_this)
        }, duration), this
    }

    function setTransitionEndSupport() {
        $.fn.emulateTransitionEnd = transitionEndEmulator, $.event.special[Util.TRANSITION_END] = getSpecialTransitionEndEvent()
    }
    var Util = {
        TRANSITION_END: "bsTransitionEnd",
        getUID: function(prefix) {
            do prefix += ~~(Math.random() * MAX_UID); while (document.getElementById(prefix));
            return prefix
        },
        getSelectorFromElement: function(element) {
            var selector = element.getAttribute("data-target");
            if (!selector || selector === "#") {
                var hrefAttr = element.getAttribute("href");
                selector = hrefAttr && hrefAttr !== "#" ? hrefAttr.trim() : ""
            }
            try {
                return document.querySelector(selector) ? selector : null
            } catch (err) {
                return null
            }
        },
        getTransitionDurationFromElement: function(element) {
            if (!element) return 0;
            var transitionDuration = $(element).css("transition-duration"),
                transitionDelay = $(element).css("transition-delay"),
                floatTransitionDuration = parseFloat(transitionDuration),
                floatTransitionDelay = parseFloat(transitionDelay);
            return !floatTransitionDuration && !floatTransitionDelay ? 0 : (transitionDuration = transitionDuration.split(",")[0], transitionDelay = transitionDelay.split(",")[0], (parseFloat(transitionDuration) + parseFloat(transitionDelay)) * MILLISECONDS_MULTIPLIER)
        },
        reflow: function(element) {
            return element.offsetHeight
        },
        triggerTransitionEnd: function(element) {
            $(element).trigger(TRANSITION_END)
        },
        supportsTransitionEnd: function() {
            return !!TRANSITION_END
        },
        isElement: function(obj) {
            return (obj[0] || obj).nodeType
        },
        typeCheckConfig: function(componentName, config, configTypes) {
            for (var property in configTypes)
                if (Object.prototype.hasOwnProperty.call(configTypes, property)) {
                    var expectedTypes = configTypes[property],
                        value = config[property],
                        valueType = value && Util.isElement(value) ? "element" : toType(value);
                    if (!new RegExp(expectedTypes).test(valueType)) throw new Error(componentName.toUpperCase() + ": " + ('Option "' + property + '" provided type "' + valueType + '" ') + ('but expected type "' + expectedTypes + '".'))
                }
        },
        findShadowRoot: function(element) {
            if (!document.documentElement.attachShadow) return null;
            if (typeof element.getRootNode == "function") {
                var root = element.getRootNode();
                return root instanceof ShadowRoot ? root : null
            }
            return element instanceof ShadowRoot ? element : element.parentNode ? Util.findShadowRoot(element.parentNode) : null
        },
        jQueryDetection: function() {
            if (typeof $ == "undefined") throw new TypeError("Bootstrap's JavaScript requires jQuery. jQuery must be included before Bootstrap's JavaScript.");
            var version = $.fn.jquery.split(" ")[0].split("."),
                minMajor = 1,
                ltMajor = 2,
                minMinor = 9,
                minPatch = 1,
                maxMajor = 4;
            if (version[0] < ltMajor && version[1] < minMinor || version[0] === minMajor && version[1] === minMinor && version[2] < minPatch || version[0] >= maxMajor) throw new Error("Bootstrap's JavaScript requires at least jQuery v1.9.1 but less than v4.0.0")
        }
    };
    Util.jQueryDetection(), setTransitionEndSupport();
    var NAME = "alert",
        VERSION = "4.4.1",
        DATA_KEY = "bs.alert",
        EVENT_KEY = "." + DATA_KEY,
        DATA_API_KEY = ".data-api",
        JQUERY_NO_CONFLICT = $.fn[NAME],
        Selector = {
            DISMISS: '[data-dismiss="alert"]'
        },
        Event = {
            CLOSE: "close" + EVENT_KEY,
            CLOSED: "closed" + EVENT_KEY,
            CLICK_DATA_API: "click" + EVENT_KEY + DATA_API_KEY
        },
        ClassName = {
            ALERT: "alert",
            FADE: "fade",
            SHOW: "show"
        },
        Alert = function() {
            function Alert2(element) {
                this._element = element
            }
            var _proto = Alert2.prototype;
            return _proto.close = function(element) {
                var rootElement = this._element;
                element && (rootElement = this._getRootElement(element));
                var customEvent = this._triggerCloseEvent(rootElement);
                customEvent.isDefaultPrevented() || this._removeElement(rootElement)
            }, _proto.dispose = function() {
                $.removeData(this._element, DATA_KEY), this._element = null
            }, _proto._getRootElement = function(element) {
                var selector = Util.getSelectorFromElement(element),
                    parent = !1;
                return selector && (parent = document.querySelector(selector)), parent || (parent = $(element).closest("." + ClassName.ALERT)[0]), parent
            }, _proto._triggerCloseEvent = function(element) {
                var closeEvent = $.Event(Event.CLOSE);
                return $(element).trigger(closeEvent), closeEvent
            }, _proto._removeElement = function(element) {
                var _this = this;
                if ($(element).removeClass(ClassName.SHOW), !$(element).hasClass(ClassName.FADE)) {
                    this._destroyElement(element);
                    return
                }
                var transitionDuration = Util.getTransitionDurationFromElement(element);
                $(element).one(Util.TRANSITION_END, function(event) {
                    return _this._destroyElement(element, event)
                }).emulateTransitionEnd(transitionDuration)
            }, _proto._destroyElement = function(element) {
                $(element).detach().trigger(Event.CLOSED).remove()
            }, Alert2._jQueryInterface = function(config) {
                return this.each(function() {
                    var $element = $(this),
                        data = $element.data(DATA_KEY);
                    data || (data = new Alert2(this), $element.data(DATA_KEY, data)), config === "close" && data[config](this)
                })
            }, Alert2._handleDismiss = function(alertInstance) {
                return function(event) {
                    event && event.preventDefault(), alertInstance.close(this)
                }
            }, _createClass(Alert2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION
                }
            }]), Alert2
        }();
    $(document).on(Event.CLICK_DATA_API, Selector.DISMISS, Alert._handleDismiss(new Alert)), $.fn[NAME] = Alert._jQueryInterface, $.fn[NAME].Constructor = Alert, $.fn[NAME].noConflict = function() {
        return $.fn[NAME] = JQUERY_NO_CONFLICT, Alert._jQueryInterface
    };
    var NAME$1 = "button",
        VERSION$1 = "4.4.1",
        DATA_KEY$1 = "bs.button",
        EVENT_KEY$1 = "." + DATA_KEY$1,
        DATA_API_KEY$1 = ".data-api",
        JQUERY_NO_CONFLICT$1 = $.fn[NAME$1],
        ClassName$1 = {
            ACTIVE: "active",
            BUTTON: "btn",
            FOCUS: "focus"
        },
        Selector$1 = {
            DATA_TOGGLE_CARROT: '[data-toggle^="button"]',
            DATA_TOGGLES: '[data-toggle="buttons"]',
            DATA_TOGGLE: '[data-toggle="button"]',
            DATA_TOGGLES_BUTTONS: '[data-toggle="buttons"] .btn',
            INPUT: 'input:not([type="hidden"])',
            ACTIVE: ".active",
            BUTTON: ".btn"
        },
        Event$1 = {
            CLICK_DATA_API: "click" + EVENT_KEY$1 + DATA_API_KEY$1,
            FOCUS_BLUR_DATA_API: "focus" + EVENT_KEY$1 + DATA_API_KEY$1 + " " + ("blur" + EVENT_KEY$1 + DATA_API_KEY$1),
            LOAD_DATA_API: "load" + EVENT_KEY$1 + DATA_API_KEY$1
        },
        Button = function() {
            function Button2(element) {
                this._element = element
            }
            var _proto = Button2.prototype;
            return _proto.toggle = function() {
                var triggerChangeEvent = !0,
                    addAriaPressed = !0,
                    rootElement = $(this._element).closest(Selector$1.DATA_TOGGLES)[0];
                if (rootElement) {
                    var input = this._element.querySelector(Selector$1.INPUT);
                    if (input) {
                        if (input.type === "radio")
                            if (input.checked && this._element.classList.contains(ClassName$1.ACTIVE)) triggerChangeEvent = !1;
                            else {
                                var activeElement = rootElement.querySelector(Selector$1.ACTIVE);
                                activeElement && $(activeElement).removeClass(ClassName$1.ACTIVE)
                            }
                        else input.type === "checkbox" ? this._element.tagName === "LABEL" && input.checked === this._element.classList.contains(ClassName$1.ACTIVE) && (triggerChangeEvent = !1) : triggerChangeEvent = !1;
                        triggerChangeEvent && (input.checked = !this._element.classList.contains(ClassName$1.ACTIVE), $(input).trigger("change")), input.focus(), addAriaPressed = !1
                    }
                }
                this._element.hasAttribute("disabled") || this._element.classList.contains("disabled") || (addAriaPressed && this._element.setAttribute("aria-pressed", !this._element.classList.contains(ClassName$1.ACTIVE)), triggerChangeEvent && $(this._element).toggleClass(ClassName$1.ACTIVE))
            }, _proto.dispose = function() {
                $.removeData(this._element, DATA_KEY$1), this._element = null
            }, Button2._jQueryInterface = function(config) {
                return this.each(function() {
                    var data = $(this).data(DATA_KEY$1);
                    data || (data = new Button2(this), $(this).data(DATA_KEY$1, data)), config === "toggle" && data[config]()
                })
            }, _createClass(Button2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$1
                }
            }]), Button2
        }();
    $(document).on(Event$1.CLICK_DATA_API, Selector$1.DATA_TOGGLE_CARROT, function(event) {
        var button = event.target;
        if ($(button).hasClass(ClassName$1.BUTTON) || (button = $(button).closest(Selector$1.BUTTON)[0]), !button || button.hasAttribute("disabled") || button.classList.contains("disabled")) event.preventDefault();
        else {
            var inputBtn = button.querySelector(Selector$1.INPUT);
            if (inputBtn && (inputBtn.hasAttribute("disabled") || inputBtn.classList.contains("disabled"))) {
                event.preventDefault();
                return
            }
            Button._jQueryInterface.call($(button), "toggle")
        }
    }).on(Event$1.FOCUS_BLUR_DATA_API, Selector$1.DATA_TOGGLE_CARROT, function(event) {
        var button = $(event.target).closest(Selector$1.BUTTON)[0];
        $(button).toggleClass(ClassName$1.FOCUS, /^focus(in)?$/.test(event.type))
    }), $(window).on(Event$1.LOAD_DATA_API, function() {
        for (var buttons = [].slice.call(document.querySelectorAll(Selector$1.DATA_TOGGLES_BUTTONS)), i = 0, len = buttons.length; i < len; i++) {
            var button = buttons[i],
                input = button.querySelector(Selector$1.INPUT);
            input.checked || input.hasAttribute("checked") ? button.classList.add(ClassName$1.ACTIVE) : button.classList.remove(ClassName$1.ACTIVE)
        }
        buttons = [].slice.call(document.querySelectorAll(Selector$1.DATA_TOGGLE));
        for (var _i = 0, _len = buttons.length; _i < _len; _i++) {
            var _button = buttons[_i];
            _button.getAttribute("aria-pressed") === "true" ? _button.classList.add(ClassName$1.ACTIVE) : _button.classList.remove(ClassName$1.ACTIVE)
        }
    }), $.fn[NAME$1] = Button._jQueryInterface, $.fn[NAME$1].Constructor = Button, $.fn[NAME$1].noConflict = function() {
        return $.fn[NAME$1] = JQUERY_NO_CONFLICT$1, Button._jQueryInterface
    };
    var NAME$2 = "carousel",
        VERSION$2 = "4.4.1",
        DATA_KEY$2 = "bs.carousel",
        EVENT_KEY$2 = "." + DATA_KEY$2,
        DATA_API_KEY$2 = ".data-api",
        JQUERY_NO_CONFLICT$2 = $.fn[NAME$2],
        ARROW_LEFT_KEYCODE = 37,
        ARROW_RIGHT_KEYCODE = 39,
        TOUCHEVENT_COMPAT_WAIT = 500,
        SWIPE_THRESHOLD = 40,
        Default = {
            interval: 5e3,
            keyboard: !0,
            slide: !1,
            pause: "hover",
            wrap: !0,
            touch: !0
        },
        DefaultType = {
            interval: "(number|boolean)",
            keyboard: "boolean",
            slide: "(boolean|string)",
            pause: "(string|boolean)",
            wrap: "boolean",
            touch: "boolean"
        },
        Direction = {
            NEXT: "next",
            PREV: "prev",
            LEFT: "left",
            RIGHT: "right"
        },
        Event$2 = {
            SLIDE: "slide" + EVENT_KEY$2,
            SLID: "slid" + EVENT_KEY$2,
            KEYDOWN: "keydown" + EVENT_KEY$2,
            MOUSEENTER: "mouseenter" + EVENT_KEY$2,
            MOUSELEAVE: "mouseleave" + EVENT_KEY$2,
            TOUCHSTART: "touchstart" + EVENT_KEY$2,
            TOUCHMOVE: "touchmove" + EVENT_KEY$2,
            TOUCHEND: "touchend" + EVENT_KEY$2,
            POINTERDOWN: "pointerdown" + EVENT_KEY$2,
            POINTERUP: "pointerup" + EVENT_KEY$2,
            DRAG_START: "dragstart" + EVENT_KEY$2,
            LOAD_DATA_API: "load" + EVENT_KEY$2 + DATA_API_KEY$2,
            CLICK_DATA_API: "click" + EVENT_KEY$2 + DATA_API_KEY$2
        },
        ClassName$2 = {
            CAROUSEL: "carousel",
            ACTIVE: "active",
            SLIDE: "slide",
            RIGHT: "carousel-item-right",
            LEFT: "carousel-item-left",
            NEXT: "carousel-item-next",
            PREV: "carousel-item-prev",
            ITEM: "carousel-item",
            POINTER_EVENT: "pointer-event"
        },
        Selector$2 = {
            ACTIVE: ".active",
            ACTIVE_ITEM: ".active.carousel-item",
            ITEM: ".carousel-item",
            ITEM_IMG: ".carousel-item img",
            NEXT_PREV: ".carousel-item-next, .carousel-item-prev",
            INDICATORS: ".carousel-indicators",
            DATA_SLIDE: "[data-slide], [data-slide-to]",
            DATA_RIDE: '[data-ride="carousel"]'
        },
        PointerType = {
            TOUCH: "touch",
            PEN: "pen"
        },
        Carousel = function() {
            function Carousel2(element, config) {
                this._items = null, this._interval = null, this._activeElement = null, this._isPaused = !1, this._isSliding = !1, this.touchTimeout = null, this.touchStartX = 0, this.touchDeltaX = 0, this._config = this._getConfig(config), this._element = element, this._indicatorsElement = this._element.querySelector(Selector$2.INDICATORS), this._touchSupported = "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0, this._pointerEvent = !!(window.PointerEvent || window.MSPointerEvent), this._addEventListeners()
            }
            var _proto = Carousel2.prototype;
            return _proto.next = function() {
                this._isSliding || this._slide(Direction.NEXT)
            }, _proto.nextWhenVisible = function() {
                !document.hidden && $(this._element).is(":visible") && $(this._element).css("visibility") !== "hidden" && this.next()
            }, _proto.prev = function() {
                this._isSliding || this._slide(Direction.PREV)
            }, _proto.pause = function(event) {
                event || (this._isPaused = !0), this._element.querySelector(Selector$2.NEXT_PREV) && (Util.triggerTransitionEnd(this._element), this.cycle(!0)), clearInterval(this._interval), this._interval = null
            }, _proto.cycle = function(event) {
                event || (this._isPaused = !1), this._interval && (clearInterval(this._interval), this._interval = null), this._config.interval && !this._isPaused && (this._interval = setInterval((document.visibilityState ? this.nextWhenVisible : this.next).bind(this), this._config.interval))
            }, _proto.to = function(index) {
                var _this = this;
                this._activeElement = this._element.querySelector(Selector$2.ACTIVE_ITEM);
                var activeIndex = this._getItemIndex(this._activeElement);
                if (!(index > this._items.length - 1 || index < 0)) {
                    if (this._isSliding) {
                        $(this._element).one(Event$2.SLID, function() {
                            return _this.to(index)
                        });
                        return
                    }
                    if (activeIndex === index) {
                        this.pause(), this.cycle();
                        return
                    }
                    var direction = index > activeIndex ? Direction.NEXT : Direction.PREV;
                    this._slide(direction, this._items[index])
                }
            }, _proto.dispose = function() {
                $(this._element).off(EVENT_KEY$2), $.removeData(this._element, DATA_KEY$2), this._items = null, this._config = null, this._element = null, this._interval = null, this._isPaused = null, this._isSliding = null, this._activeElement = null, this._indicatorsElement = null
            }, _proto._getConfig = function(config) {
                return config = _objectSpread2({}, Default, {}, config), Util.typeCheckConfig(NAME$2, config, DefaultType), config
            }, _proto._handleSwipe = function() {
                var absDeltax = Math.abs(this.touchDeltaX);
                if (!(absDeltax <= SWIPE_THRESHOLD)) {
                    var direction = absDeltax / this.touchDeltaX;
                    this.touchDeltaX = 0, direction > 0 && this.prev(), direction < 0 && this.next()
                }
            }, _proto._addEventListeners = function() {
                var _this2 = this;
                this._config.keyboard && $(this._element).on(Event$2.KEYDOWN, function(event) {
                    return _this2._keydown(event)
                }), this._config.pause === "hover" && $(this._element).on(Event$2.MOUSEENTER, function(event) {
                    return _this2.pause(event)
                }).on(Event$2.MOUSELEAVE, function(event) {
                    return _this2.cycle(event)
                }), this._config.touch && this._addTouchEventListeners()
            }, _proto._addTouchEventListeners = function() {
                var _this3 = this;
                if (this._touchSupported) {
                    var start = function(event) {
                            _this3._pointerEvent && PointerType[event.originalEvent.pointerType.toUpperCase()] ? _this3.touchStartX = event.originalEvent.clientX : _this3._pointerEvent || (_this3.touchStartX = event.originalEvent.touches[0].clientX)
                        },
                        move = function(event) {
                            event.originalEvent.touches && event.originalEvent.touches.length > 1 ? _this3.touchDeltaX = 0 : _this3.touchDeltaX = event.originalEvent.touches[0].clientX - _this3.touchStartX
                        },
                        end = function(event) {
                            _this3._pointerEvent && PointerType[event.originalEvent.pointerType.toUpperCase()] && (_this3.touchDeltaX = event.originalEvent.clientX - _this3.touchStartX), _this3._handleSwipe(), _this3._config.pause === "hover" && (_this3.pause(), _this3.touchTimeout && clearTimeout(_this3.touchTimeout), _this3.touchTimeout = setTimeout(function(event2) {
                                return _this3.cycle(event2)
                            }, TOUCHEVENT_COMPAT_WAIT + _this3._config.interval))
                        };
                    $(this._element.querySelectorAll(Selector$2.ITEM_IMG)).on(Event$2.DRAG_START, function(e) {
                        return e.preventDefault()
                    }), this._pointerEvent ? ($(this._element).on(Event$2.POINTERDOWN, function(event) {
                        return start(event)
                    }), $(this._element).on(Event$2.POINTERUP, function(event) {
                        return end(event)
                    }), this._element.classList.add(ClassName$2.POINTER_EVENT)) : ($(this._element).on(Event$2.TOUCHSTART, function(event) {
                        return start(event)
                    }), $(this._element).on(Event$2.TOUCHMOVE, function(event) {
                        return move(event)
                    }), $(this._element).on(Event$2.TOUCHEND, function(event) {
                        return end(event)
                    }))
                }
            }, _proto._keydown = function(event) {
                if (!/input|textarea/i.test(event.target.tagName)) switch (event.which) {
                    case ARROW_LEFT_KEYCODE:
                        event.preventDefault(), this.prev();
                        break;
                    case ARROW_RIGHT_KEYCODE:
                        event.preventDefault(), this.next();
                        break
                }
            }, _proto._getItemIndex = function(element) {
                return this._items = element && element.parentNode ? [].slice.call(element.parentNode.querySelectorAll(Selector$2.ITEM)) : [], this._items.indexOf(element)
            }, _proto._getItemByDirection = function(direction, activeElement) {
                var isNextDirection = direction === Direction.NEXT,
                    isPrevDirection = direction === Direction.PREV,
                    activeIndex = this._getItemIndex(activeElement),
                    lastItemIndex = this._items.length - 1,
                    isGoingToWrap = isPrevDirection && activeIndex === 0 || isNextDirection && activeIndex === lastItemIndex;
                if (isGoingToWrap && !this._config.wrap) return activeElement;
                var delta = direction === Direction.PREV ? -1 : 1,
                    itemIndex = (activeIndex + delta) % this._items.length;
                return itemIndex === -1 ? this._items[this._items.length - 1] : this._items[itemIndex]
            }, _proto._triggerSlideEvent = function(relatedTarget, eventDirectionName) {
                var targetIndex = this._getItemIndex(relatedTarget),
                    fromIndex = this._getItemIndex(this._element.querySelector(Selector$2.ACTIVE_ITEM)),
                    slideEvent = $.Event(Event$2.SLIDE, {
                        relatedTarget: relatedTarget,
                        direction: eventDirectionName,
                        from: fromIndex,
                        to: targetIndex
                    });
                return $(this._element).trigger(slideEvent), slideEvent
            }, _proto._setActiveIndicatorElement = function(element) {
                if (this._indicatorsElement) {
                    var indicators = [].slice.call(this._indicatorsElement.querySelectorAll(Selector$2.ACTIVE));
                    $(indicators).removeClass(ClassName$2.ACTIVE);
                    var nextIndicator = this._indicatorsElement.children[this._getItemIndex(element)];
                    nextIndicator && $(nextIndicator).addClass(ClassName$2.ACTIVE)
                }
            }, _proto._slide = function(direction, element) {
                var _this4 = this,
                    activeElement = this._element.querySelector(Selector$2.ACTIVE_ITEM),
                    activeElementIndex = this._getItemIndex(activeElement),
                    nextElement = element || activeElement && this._getItemByDirection(direction, activeElement),
                    nextElementIndex = this._getItemIndex(nextElement),
                    isCycling = !!this._interval,
                    directionalClassName, orderClassName, eventDirectionName;
                if (direction === Direction.NEXT ? (directionalClassName = ClassName$2.LEFT, orderClassName = ClassName$2.NEXT, eventDirectionName = Direction.LEFT) : (directionalClassName = ClassName$2.RIGHT, orderClassName = ClassName$2.PREV, eventDirectionName = Direction.RIGHT), nextElement && $(nextElement).hasClass(ClassName$2.ACTIVE)) {
                    this._isSliding = !1;
                    return
                }
                var slideEvent = this._triggerSlideEvent(nextElement, eventDirectionName);
                if (!slideEvent.isDefaultPrevented() && !(!activeElement || !nextElement)) {
                    this._isSliding = !0, isCycling && this.pause(), this._setActiveIndicatorElement(nextElement);
                    var slidEvent = $.Event(Event$2.SLID, {
                        relatedTarget: nextElement,
                        direction: eventDirectionName,
                        from: activeElementIndex,
                        to: nextElementIndex
                    });
                    if ($(this._element).hasClass(ClassName$2.SLIDE)) {
                        $(nextElement).addClass(orderClassName), Util.reflow(nextElement), $(activeElement).addClass(directionalClassName), $(nextElement).addClass(directionalClassName);
                        var nextElementInterval = parseInt(nextElement.getAttribute("data-interval"), 10);
                        nextElementInterval ? (this._config.defaultInterval = this._config.defaultInterval || this._config.interval, this._config.interval = nextElementInterval) : this._config.interval = this._config.defaultInterval || this._config.interval;
                        var transitionDuration = Util.getTransitionDurationFromElement(activeElement);
                        $(activeElement).one(Util.TRANSITION_END, function() {
                            $(nextElement).removeClass(directionalClassName + " " + orderClassName).addClass(ClassName$2.ACTIVE), $(activeElement).removeClass(ClassName$2.ACTIVE + " " + orderClassName + " " + directionalClassName), _this4._isSliding = !1, setTimeout(function() {
                                return $(_this4._element).trigger(slidEvent)
                            }, 0)
                        }).emulateTransitionEnd(transitionDuration)
                    } else $(activeElement).removeClass(ClassName$2.ACTIVE), $(nextElement).addClass(ClassName$2.ACTIVE), this._isSliding = !1, $(this._element).trigger(slidEvent);
                    isCycling && this.cycle()
                }
            }, Carousel2._jQueryInterface = function(config) {
                return this.each(function() {
                    var data = $(this).data(DATA_KEY$2),
                        _config = _objectSpread2({}, Default, {}, $(this).data());
                    typeof config == "object" && (_config = _objectSpread2({}, _config, {}, config));
                    var action = typeof config == "string" ? config : _config.slide;
                    if (data || (data = new Carousel2(this, _config), $(this).data(DATA_KEY$2, data)), typeof config == "number") data.to(config);
                    else if (typeof action == "string") {
                        if (typeof data[action] == "undefined") throw new TypeError('No method named "' + action + '"');
                        data[action]()
                    } else _config.interval && _config.ride && (data.pause(), data.cycle())
                })
            }, Carousel2._dataApiClickHandler = function(event) {
                var selector = Util.getSelectorFromElement(this);
                if (selector) {
                    var target = $(selector)[0];
                    if (!(!target || !$(target).hasClass(ClassName$2.CAROUSEL))) {
                        var config = _objectSpread2({}, $(target).data(), {}, $(this).data()),
                            slideIndex = this.getAttribute("data-slide-to");
                        slideIndex && (config.interval = !1), Carousel2._jQueryInterface.call($(target), config), slideIndex && $(target).data(DATA_KEY$2).to(slideIndex), event.preventDefault()
                    }
                }
            }, _createClass(Carousel2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$2
                }
            }, {
                key: "Default",
                get: function() {
                    return Default
                }
            }]), Carousel2
        }();
    $(document).on(Event$2.CLICK_DATA_API, Selector$2.DATA_SLIDE, Carousel._dataApiClickHandler), $(window).on(Event$2.LOAD_DATA_API, function() {
        for (var carousels = [].slice.call(document.querySelectorAll(Selector$2.DATA_RIDE)), i = 0, len = carousels.length; i < len; i++) {
            var $carousel = $(carousels[i]);
            Carousel._jQueryInterface.call($carousel, $carousel.data())
        }
    }), $.fn[NAME$2] = Carousel._jQueryInterface, $.fn[NAME$2].Constructor = Carousel, $.fn[NAME$2].noConflict = function() {
        return $.fn[NAME$2] = JQUERY_NO_CONFLICT$2, Carousel._jQueryInterface
    };
    var NAME$3 = "collapse",
        VERSION$3 = "4.4.1",
        DATA_KEY$3 = "bs.collapse",
        EVENT_KEY$3 = "." + DATA_KEY$3,
        DATA_API_KEY$3 = ".data-api",
        JQUERY_NO_CONFLICT$3 = $.fn[NAME$3],
        Default$1 = {
            toggle: !0,
            parent: ""
        },
        DefaultType$1 = {
            toggle: "boolean",
            parent: "(string|element)"
        },
        Event$3 = {
            SHOW: "show" + EVENT_KEY$3,
            SHOWN: "shown" + EVENT_KEY$3,
            HIDE: "hide" + EVENT_KEY$3,
            HIDDEN: "hidden" + EVENT_KEY$3,
            CLICK_DATA_API: "click" + EVENT_KEY$3 + DATA_API_KEY$3
        },
        ClassName$3 = {
            SHOW: "show",
            COLLAPSE: "collapse",
            COLLAPSING: "collapsing",
            COLLAPSED: "collapsed"
        },
        Dimension = {
            WIDTH: "width",
            HEIGHT: "height"
        },
        Selector$3 = {
            ACTIVES: ".show, .collapsing",
            DATA_TOGGLE: '[data-toggle="collapse"]'
        },
        Collapse = function() {
            function Collapse2(element, config) {
                this._isTransitioning = !1, this._element = element, this._config = this._getConfig(config), this._triggerArray = [].slice.call(document.querySelectorAll('[data-toggle="collapse"][href="#' + element.id + '"],' + ('[data-toggle="collapse"][data-target="#' + element.id + '"]')));
                for (var toggleList = [].slice.call(document.querySelectorAll(Selector$3.DATA_TOGGLE)), i = 0, len = toggleList.length; i < len; i++) {
                    var elem = toggleList[i],
                        selector = Util.getSelectorFromElement(elem),
                        filterElement = [].slice.call(document.querySelectorAll(selector)).filter(function(foundElem) {
                            return foundElem === element
                        });
                    selector !== null && filterElement.length > 0 && (this._selector = selector, this._triggerArray.push(elem))
                }
                this._parent = this._config.parent ? this._getParent() : null, this._config.parent || this._addAriaAndCollapsedClass(this._element, this._triggerArray), this._config.toggle && this.toggle()
            }
            var _proto = Collapse2.prototype;
            return _proto.toggle = function() {
                $(this._element).hasClass(ClassName$3.SHOW) ? this.hide() : this.show()
            }, _proto.show = function() {
                var _this = this;
                if (!(this._isTransitioning || $(this._element).hasClass(ClassName$3.SHOW))) {
                    var actives, activesData;
                    if (this._parent && (actives = [].slice.call(this._parent.querySelectorAll(Selector$3.ACTIVES)).filter(function(elem) {
                            return typeof _this._config.parent == "string" ? elem.getAttribute("data-parent") === _this._config.parent : elem.classList.contains(ClassName$3.COLLAPSE)
                        }), actives.length === 0 && (actives = null)), !(actives && (activesData = $(actives).not(this._selector).data(DATA_KEY$3), activesData && activesData._isTransitioning))) {
                        var startEvent = $.Event(Event$3.SHOW);
                        if ($(this._element).trigger(startEvent), !startEvent.isDefaultPrevented()) {
                            actives && (Collapse2._jQueryInterface.call($(actives).not(this._selector), "hide"), activesData || $(actives).data(DATA_KEY$3, null));
                            var dimension = this._getDimension();
                            $(this._element).removeClass(ClassName$3.COLLAPSE).addClass(ClassName$3.COLLAPSING), this._element.style[dimension] = 0, this._triggerArray.length && $(this._triggerArray).removeClass(ClassName$3.COLLAPSED).attr("aria-expanded", !0), this.setTransitioning(!0);
                            var complete = function() {
                                    $(_this._element).removeClass(ClassName$3.COLLAPSING).addClass(ClassName$3.COLLAPSE).addClass(ClassName$3.SHOW), _this._element.style[dimension] = "", _this.setTransitioning(!1), $(_this._element).trigger(Event$3.SHOWN)
                                },
                                capitalizedDimension = dimension[0].toUpperCase() + dimension.slice(1),
                                scrollSize = "scroll" + capitalizedDimension,
                                transitionDuration = Util.getTransitionDurationFromElement(this._element);
                            $(this._element).one(Util.TRANSITION_END, complete).emulateTransitionEnd(transitionDuration), this._element.style[dimension] = this._element[scrollSize] + "px"
                        }
                    }
                }
            }, _proto.hide = function() {
                var _this2 = this;
                if (!(this._isTransitioning || !$(this._element).hasClass(ClassName$3.SHOW))) {
                    var startEvent = $.Event(Event$3.HIDE);
                    if ($(this._element).trigger(startEvent), !startEvent.isDefaultPrevented()) {
                        var dimension = this._getDimension();
                        this._element.style[dimension] = this._element.getBoundingClientRect()[dimension] + "px", Util.reflow(this._element), $(this._element).addClass(ClassName$3.COLLAPSING).removeClass(ClassName$3.COLLAPSE).removeClass(ClassName$3.SHOW);
                        var triggerArrayLength = this._triggerArray.length;
                        if (triggerArrayLength > 0)
                            for (var i = 0; i < triggerArrayLength; i++) {
                                var trigger = this._triggerArray[i],
                                    selector = Util.getSelectorFromElement(trigger);
                                if (selector !== null) {
                                    var $elem = $([].slice.call(document.querySelectorAll(selector)));
                                    $elem.hasClass(ClassName$3.SHOW) || $(trigger).addClass(ClassName$3.COLLAPSED).attr("aria-expanded", !1)
                                }
                            }
                        this.setTransitioning(!0);
                        var complete = function() {
                            _this2.setTransitioning(!1), $(_this2._element).removeClass(ClassName$3.COLLAPSING).addClass(ClassName$3.COLLAPSE).trigger(Event$3.HIDDEN)
                        };
                        this._element.style[dimension] = "";
                        var transitionDuration = Util.getTransitionDurationFromElement(this._element);
                        $(this._element).one(Util.TRANSITION_END, complete).emulateTransitionEnd(transitionDuration)
                    }
                }
            }, _proto.setTransitioning = function(isTransitioning) {
                this._isTransitioning = isTransitioning
            }, _proto.dispose = function() {
                $.removeData(this._element, DATA_KEY$3), this._config = null, this._parent = null, this._element = null, this._triggerArray = null, this._isTransitioning = null
            }, _proto._getConfig = function(config) {
                return config = _objectSpread2({}, Default$1, {}, config), config.toggle = !!config.toggle, Util.typeCheckConfig(NAME$3, config, DefaultType$1), config
            }, _proto._getDimension = function() {
                var hasWidth = $(this._element).hasClass(Dimension.WIDTH);
                return hasWidth ? Dimension.WIDTH : Dimension.HEIGHT
            }, _proto._getParent = function() {
                var _this3 = this,
                    parent;
                Util.isElement(this._config.parent) ? (parent = this._config.parent, typeof this._config.parent.jquery != "undefined" && (parent = this._config.parent[0])) : parent = document.querySelector(this._config.parent);
                var selector = '[data-toggle="collapse"][data-parent="' + this._config.parent + '"]',
                    children = [].slice.call(parent.querySelectorAll(selector));
                return $(children).each(function(i, element) {
                    _this3._addAriaAndCollapsedClass(Collapse2._getTargetFromElement(element), [element])
                }), parent
            }, _proto._addAriaAndCollapsedClass = function(element, triggerArray) {
                var isOpen = $(element).hasClass(ClassName$3.SHOW);
                triggerArray.length && $(triggerArray).toggleClass(ClassName$3.COLLAPSED, !isOpen).attr("aria-expanded", isOpen)
            }, Collapse2._getTargetFromElement = function(element) {
                var selector = Util.getSelectorFromElement(element);
                return selector ? document.querySelector(selector) : null
            }, Collapse2._jQueryInterface = function(config) {
                return this.each(function() {
                    var $this = $(this),
                        data = $this.data(DATA_KEY$3),
                        _config = _objectSpread2({}, Default$1, {}, $this.data(), {}, typeof config == "object" && config ? config : {});
                    if (!data && _config.toggle && /show|hide/.test(config) && (_config.toggle = !1), data || (data = new Collapse2(this, _config), $this.data(DATA_KEY$3, data)), typeof config == "string") {
                        if (typeof data[config] == "undefined") throw new TypeError('No method named "' + config + '"');
                        data[config]()
                    }
                })
            }, _createClass(Collapse2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$3
                }
            }, {
                key: "Default",
                get: function() {
                    return Default$1
                }
            }]), Collapse2
        }();
    $(document).on(Event$3.CLICK_DATA_API, Selector$3.DATA_TOGGLE, function(event) {
        event.currentTarget.tagName === "A" && event.preventDefault();
        var $trigger = $(this),
            selector = Util.getSelectorFromElement(this),
            selectors = [].slice.call(document.querySelectorAll(selector));
        $(selectors).each(function() {
            var $target = $(this),
                data = $target.data(DATA_KEY$3),
                config = data ? "toggle" : $trigger.data();
            Collapse._jQueryInterface.call($target, config)
        })
    }), $.fn[NAME$3] = Collapse._jQueryInterface, $.fn[NAME$3].Constructor = Collapse, $.fn[NAME$3].noConflict = function() {
        return $.fn[NAME$3] = JQUERY_NO_CONFLICT$3, Collapse._jQueryInterface
    };
    var NAME$4 = "dropdown",
        VERSION$4 = "4.4.1",
        DATA_KEY$4 = "bs.dropdown",
        EVENT_KEY$4 = "." + DATA_KEY$4,
        DATA_API_KEY$4 = ".data-api",
        JQUERY_NO_CONFLICT$4 = $.fn[NAME$4],
        ESCAPE_KEYCODE = 27,
        SPACE_KEYCODE = 32,
        TAB_KEYCODE = 9,
        ARROW_UP_KEYCODE = 38,
        ARROW_DOWN_KEYCODE = 40,
        RIGHT_MOUSE_BUTTON_WHICH = 3,
        REGEXP_KEYDOWN = new RegExp(ARROW_UP_KEYCODE + "|" + ARROW_DOWN_KEYCODE + "|" + ESCAPE_KEYCODE),
        Event$4 = {
            HIDE: "hide" + EVENT_KEY$4,
            HIDDEN: "hidden" + EVENT_KEY$4,
            SHOW: "show" + EVENT_KEY$4,
            SHOWN: "shown" + EVENT_KEY$4,
            CLICK: "click" + EVENT_KEY$4,
            CLICK_DATA_API: "click" + EVENT_KEY$4 + DATA_API_KEY$4,
            KEYDOWN_DATA_API: "keydown" + EVENT_KEY$4 + DATA_API_KEY$4,
            KEYUP_DATA_API: "keyup" + EVENT_KEY$4 + DATA_API_KEY$4
        },
        ClassName$4 = {
            DISABLED: "disabled",
            SHOW: "show",
            DROPUP: "dropup",
            DROPRIGHT: "dropright",
            DROPLEFT: "dropleft",
            MENURIGHT: "dropdown-menu-right",
            MENULEFT: "dropdown-menu-left",
            POSITION_STATIC: "position-static"
        },
        Selector$4 = {
            DATA_TOGGLE: '[data-toggle="dropdown"]',
            FORM_CHILD: ".dropdown form",
            MENU: ".dropdown-menu",
            NAVBAR_NAV: ".navbar-nav",
            VISIBLE_ITEMS: ".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)"
        },
        AttachmentMap = {
            TOP: "top-start",
            TOPEND: "top-end",
            BOTTOM: "bottom-start",
            BOTTOMEND: "bottom-end",
            RIGHT: "right-start",
            RIGHTEND: "right-end",
            LEFT: "left-start",
            LEFTEND: "left-end"
        },
        Default$2 = {
            offset: 0,
            flip: !0,
            boundary: "scrollParent",
            reference: "toggle",
            display: "dynamic",
            popperConfig: null
        },
        DefaultType$2 = {
            offset: "(number|string|function)",
            flip: "boolean",
            boundary: "(string|element)",
            reference: "(string|element)",
            display: "string",
            popperConfig: "(null|object)"
        },
        Dropdown = function() {
            function Dropdown2(element, config) {
                this._element = element, this._popper = null, this._config = this._getConfig(config), this._menu = this._getMenuElement(), this._inNavbar = this._detectNavbar(), this._addEventListeners()
            }
            var _proto = Dropdown2.prototype;
            return _proto.toggle = function() {
                if (!(this._element.disabled || $(this._element).hasClass(ClassName$4.DISABLED))) {
                    var isActive = $(this._menu).hasClass(ClassName$4.SHOW);
                    Dropdown2._clearMenus(), !isActive && this.show(!0)
                }
            }, _proto.show = function(usePopper) {
                if (usePopper === void 0 && (usePopper = !1), !(this._element.disabled || $(this._element).hasClass(ClassName$4.DISABLED) || $(this._menu).hasClass(ClassName$4.SHOW))) {
                    var relatedTarget = {
                            relatedTarget: this._element
                        },
                        showEvent = $.Event(Event$4.SHOW, relatedTarget),
                        parent = Dropdown2._getParentFromElement(this._element);
                    if ($(parent).trigger(showEvent), !showEvent.isDefaultPrevented()) {
                        if (!this._inNavbar && usePopper) {
                            if (typeof Popper == "undefined") throw new TypeError("Bootstrap's dropdowns require Popper.js (https://popper.js.org/)");
                            var referenceElement = this._element;
                            this._config.reference === "parent" ? referenceElement = parent : Util.isElement(this._config.reference) && (referenceElement = this._config.reference, typeof this._config.reference.jquery != "undefined" && (referenceElement = this._config.reference[0])), this._config.boundary !== "scrollParent" && $(parent).addClass(ClassName$4.POSITION_STATIC), this._popper = new Popper(referenceElement, this._menu, this._getPopperConfig())
                        }
                        "ontouchstart" in document.documentElement && $(parent).closest(Selector$4.NAVBAR_NAV).length === 0 && $(document.body).children().on("mouseover", null, $.noop), this._element.focus(), this._element.setAttribute("aria-expanded", !0), $(this._menu).toggleClass(ClassName$4.SHOW), $(parent).toggleClass(ClassName$4.SHOW).trigger($.Event(Event$4.SHOWN, relatedTarget))
                    }
                }
            }, _proto.hide = function() {
                if (!(this._element.disabled || $(this._element).hasClass(ClassName$4.DISABLED) || !$(this._menu).hasClass(ClassName$4.SHOW))) {
                    var relatedTarget = {
                            relatedTarget: this._element
                        },
                        hideEvent = $.Event(Event$4.HIDE, relatedTarget),
                        parent = Dropdown2._getParentFromElement(this._element);
                    $(parent).trigger(hideEvent), !hideEvent.isDefaultPrevented() && (this._popper && this._popper.destroy(), $(this._menu).toggleClass(ClassName$4.SHOW), $(parent).toggleClass(ClassName$4.SHOW).trigger($.Event(Event$4.HIDDEN, relatedTarget)))
                }
            }, _proto.dispose = function() {
                $.removeData(this._element, DATA_KEY$4), $(this._element).off(EVENT_KEY$4), this._element = null, this._menu = null, this._popper !== null && (this._popper.destroy(), this._popper = null)
            }, _proto.update = function() {
                this._inNavbar = this._detectNavbar(), this._popper !== null && this._popper.scheduleUpdate()
            }, _proto._addEventListeners = function() {
                var _this = this;
                $(this._element).on(Event$4.CLICK, function(event) {
                    event.preventDefault(), event.stopPropagation(), _this.toggle()
                })
            }, _proto._getConfig = function(config) {
                return config = _objectSpread2({}, this.constructor.Default, {}, $(this._element).data(), {}, config), Util.typeCheckConfig(NAME$4, config, this.constructor.DefaultType), config
            }, _proto._getMenuElement = function() {
                if (!this._menu) {
                    var parent = Dropdown2._getParentFromElement(this._element);
                    parent && (this._menu = parent.querySelector(Selector$4.MENU))
                }
                return this._menu
            }, _proto._getPlacement = function() {
                var $parentDropdown = $(this._element.parentNode),
                    placement = AttachmentMap.BOTTOM;
                return $parentDropdown.hasClass(ClassName$4.DROPUP) ? (placement = AttachmentMap.TOP, $(this._menu).hasClass(ClassName$4.MENURIGHT) && (placement = AttachmentMap.TOPEND)) : $parentDropdown.hasClass(ClassName$4.DROPRIGHT) ? placement = AttachmentMap.RIGHT : $parentDropdown.hasClass(ClassName$4.DROPLEFT) ? placement = AttachmentMap.LEFT : $(this._menu).hasClass(ClassName$4.MENURIGHT) && (placement = AttachmentMap.BOTTOMEND), placement
            }, _proto._detectNavbar = function() {
                return $(this._element).closest(".navbar").length > 0
            }, _proto._getOffset = function() {
                var _this2 = this,
                    offset = {};
                return typeof this._config.offset == "function" ? offset.fn = function(data) {
                    return data.offsets = _objectSpread2({}, data.offsets, {}, _this2._config.offset(data.offsets, _this2._element) || {}), data
                } : offset.offset = this._config.offset, offset
            }, _proto._getPopperConfig = function() {
                var popperConfig = {
                    placement: this._getPlacement(),
                    modifiers: {
                        offset: this._getOffset(),
                        flip: {
                            enabled: this._config.flip
                        },
                        preventOverflow: {
                            boundariesElement: this._config.boundary
                        }
                    }
                };
                return this._config.display === "static" && (popperConfig.modifiers.applyStyle = {
                    enabled: !1
                }), _objectSpread2({}, popperConfig, {}, this._config.popperConfig)
            }, Dropdown2._jQueryInterface = function(config) {
                return this.each(function() {
                    var data = $(this).data(DATA_KEY$4),
                        _config = typeof config == "object" ? config : null;
                    if (data || (data = new Dropdown2(this, _config), $(this).data(DATA_KEY$4, data)), typeof config == "string") {
                        if (typeof data[config] == "undefined") throw new TypeError('No method named "' + config + '"');
                        data[config]()
                    }
                })
            }, Dropdown2._clearMenus = function(event) {
                if (!(event && (event.which === RIGHT_MOUSE_BUTTON_WHICH || event.type === "keyup" && event.which !== TAB_KEYCODE)))
                    for (var toggles = [].slice.call(document.querySelectorAll(Selector$4.DATA_TOGGLE)), i = 0, len = toggles.length; i < len; i++) {
                        var parent = Dropdown2._getParentFromElement(toggles[i]),
                            context = $(toggles[i]).data(DATA_KEY$4),
                            relatedTarget = {
                                relatedTarget: toggles[i]
                            };
                        if (event && event.type === "click" && (relatedTarget.clickEvent = event), !!context) {
                            var dropdownMenu = context._menu;
                            if ($(parent).hasClass(ClassName$4.SHOW) && !(event && (event.type === "click" && /input|textarea/i.test(event.target.tagName) || event.type === "keyup" && event.which === TAB_KEYCODE) && $.contains(parent, event.target))) {
                                var hideEvent = $.Event(Event$4.HIDE, relatedTarget);
                                $(parent).trigger(hideEvent), !hideEvent.isDefaultPrevented() && ("ontouchstart" in document.documentElement && $(document.body).children().off("mouseover", null, $.noop), toggles[i].setAttribute("aria-expanded", "false"), context._popper && context._popper.destroy(), $(dropdownMenu).removeClass(ClassName$4.SHOW), $(parent).removeClass(ClassName$4.SHOW).trigger($.Event(Event$4.HIDDEN, relatedTarget)))
                            }
                        }
                    }
            }, Dropdown2._getParentFromElement = function(element) {
                var parent, selector = Util.getSelectorFromElement(element);
                return selector && (parent = document.querySelector(selector)), parent || element.parentNode
            }, Dropdown2._dataApiKeydownHandler = function(event) {
                if (!(/input|textarea/i.test(event.target.tagName) ? event.which === SPACE_KEYCODE || event.which !== ESCAPE_KEYCODE && (event.which !== ARROW_DOWN_KEYCODE && event.which !== ARROW_UP_KEYCODE || $(event.target).closest(Selector$4.MENU).length) : !REGEXP_KEYDOWN.test(event.which)) && (event.preventDefault(), event.stopPropagation(), !(this.disabled || $(this).hasClass(ClassName$4.DISABLED)))) {
                    var parent = Dropdown2._getParentFromElement(this),
                        isActive = $(parent).hasClass(ClassName$4.SHOW);
                    if (!(!isActive && event.which === ESCAPE_KEYCODE)) {
                        if (!isActive || isActive && (event.which === ESCAPE_KEYCODE || event.which === SPACE_KEYCODE)) {
                            if (event.which === ESCAPE_KEYCODE) {
                                var toggle = parent.querySelector(Selector$4.DATA_TOGGLE);
                                $(toggle).trigger("focus")
                            }
                            $(this).trigger("click");
                            return
                        }
                        var items = [].slice.call(parent.querySelectorAll(Selector$4.VISIBLE_ITEMS)).filter(function(item) {
                            return $(item).is(":visible")
                        });
                        if (items.length !== 0) {
                            var index = items.indexOf(event.target);
                            event.which === ARROW_UP_KEYCODE && index > 0 && index--, event.which === ARROW_DOWN_KEYCODE && index < items.length - 1 && index++, index < 0 && (index = 0), items[index].focus()
                        }
                    }
                }
            }, _createClass(Dropdown2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$4
                }
            }, {
                key: "Default",
                get: function() {
                    return Default$2
                }
            }, {
                key: "DefaultType",
                get: function() {
                    return DefaultType$2
                }
            }]), Dropdown2
        }();
    $(document).on(Event$4.KEYDOWN_DATA_API, Selector$4.DATA_TOGGLE, Dropdown._dataApiKeydownHandler).on(Event$4.KEYDOWN_DATA_API, Selector$4.MENU, Dropdown._dataApiKeydownHandler).on(Event$4.CLICK_DATA_API + " " + Event$4.KEYUP_DATA_API, Dropdown._clearMenus).on(Event$4.CLICK_DATA_API, Selector$4.DATA_TOGGLE, function(event) {
        event.preventDefault(), event.stopPropagation(), Dropdown._jQueryInterface.call($(this), "toggle")
    }).on(Event$4.CLICK_DATA_API, Selector$4.FORM_CHILD, function(e) {
        e.stopPropagation()
    }), $.fn[NAME$4] = Dropdown._jQueryInterface, $.fn[NAME$4].Constructor = Dropdown, $.fn[NAME$4].noConflict = function() {
        return $.fn[NAME$4] = JQUERY_NO_CONFLICT$4, Dropdown._jQueryInterface
    };
    var NAME$5 = "modal",
        VERSION$5 = "4.4.1",
        DATA_KEY$5 = "bs.modal",
        EVENT_KEY$5 = "." + DATA_KEY$5,
        DATA_API_KEY$5 = ".data-api",
        JQUERY_NO_CONFLICT$5 = $.fn[NAME$5],
        ESCAPE_KEYCODE$1 = 27,
        Default$3 = {
            backdrop: !0,
            keyboard: !0,
            focus: !0,
            show: !0
        },
        DefaultType$3 = {
            backdrop: "(boolean|string)",
            keyboard: "boolean",
            focus: "boolean",
            show: "boolean"
        },
        Event$5 = {
            HIDE: "hide" + EVENT_KEY$5,
            HIDE_PREVENTED: "hidePrevented" + EVENT_KEY$5,
            HIDDEN: "hidden" + EVENT_KEY$5,
            SHOW: "show" + EVENT_KEY$5,
            SHOWN: "shown" + EVENT_KEY$5,
            FOCUSIN: "focusin" + EVENT_KEY$5,
            RESIZE: "resize" + EVENT_KEY$5,
            CLICK_DISMISS: "click.dismiss" + EVENT_KEY$5,
            KEYDOWN_DISMISS: "keydown.dismiss" + EVENT_KEY$5,
            MOUSEUP_DISMISS: "mouseup.dismiss" + EVENT_KEY$5,
            MOUSEDOWN_DISMISS: "mousedown.dismiss" + EVENT_KEY$5,
            CLICK_DATA_API: "click" + EVENT_KEY$5 + DATA_API_KEY$5
        },
        ClassName$5 = {
            SCROLLABLE: "modal-dialog-scrollable",
            SCROLLBAR_MEASURER: "modal-scrollbar-measure",
            BACKDROP: "modal-backdrop",
            OPEN: "modal-open",
            FADE: "fade",
            SHOW: "show",
            STATIC: "modal-static"
        },
        Selector$5 = {
            DIALOG: ".modal-dialog",
            MODAL_BODY: ".modal-body",
            DATA_TOGGLE: '[data-toggle="modal"]',
            DATA_DISMISS: '[data-dismiss="modal"]',
            FIXED_CONTENT: ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top",
            STICKY_CONTENT: ".sticky-top"
        },
        Modal = function() {
            function Modal2(element, config) {
                this._config = this._getConfig(config), this._element = element, this._dialog = element.querySelector(Selector$5.DIALOG), this._backdrop = null, this._isShown = !1, this._isBodyOverflowing = !1, this._ignoreBackdropClick = !1, this._isTransitioning = !1, this._scrollbarWidth = 0
            }
            var _proto = Modal2.prototype;
            return _proto.toggle = function(relatedTarget) {
                return this._isShown ? this.hide() : this.show(relatedTarget)
            }, _proto.show = function(relatedTarget) {
                var _this = this;
                if (!(this._isShown || this._isTransitioning)) {
                    $(this._element).hasClass(ClassName$5.FADE) && (this._isTransitioning = !0);
                    var showEvent = $.Event(Event$5.SHOW, {
                        relatedTarget: relatedTarget
                    });
                    $(this._element).trigger(showEvent), !(this._isShown || showEvent.isDefaultPrevented()) && (this._isShown = !0, this._checkScrollbar(), this._setScrollbar(), this._adjustDialog(), this._setEscapeEvent(), this._setResizeEvent(), $(this._element).on(Event$5.CLICK_DISMISS, Selector$5.DATA_DISMISS, function(event) {
                        return _this.hide(event)
                    }), $(this._dialog).on(Event$5.MOUSEDOWN_DISMISS, function() {
                        $(_this._element).one(Event$5.MOUSEUP_DISMISS, function(event) {
                            $(event.target).is(_this._element) && (_this._ignoreBackdropClick = !0)
                        })
                    }), this._showBackdrop(function() {
                        return _this._showElement(relatedTarget)
                    }))
                }
            }, _proto.hide = function(event) {
                var _this2 = this;
                if (event && event.preventDefault(), !(!this._isShown || this._isTransitioning)) {
                    var hideEvent = $.Event(Event$5.HIDE);
                    if ($(this._element).trigger(hideEvent), !(!this._isShown || hideEvent.isDefaultPrevented())) {
                        this._isShown = !1;
                        var transition = $(this._element).hasClass(ClassName$5.FADE);
                        if (transition && (this._isTransitioning = !0), this._setEscapeEvent(), this._setResizeEvent(), $(document).off(Event$5.FOCUSIN), $(this._element).removeClass(ClassName$5.SHOW), $(this._element).off(Event$5.CLICK_DISMISS), $(this._dialog).off(Event$5.MOUSEDOWN_DISMISS), transition) {
                            var transitionDuration = Util.getTransitionDurationFromElement(this._element);
                            $(this._element).one(Util.TRANSITION_END, function(event2) {
                                return _this2._hideModal(event2)
                            }).emulateTransitionEnd(transitionDuration)
                        } else this._hideModal()
                    }
                }
            }, _proto.dispose = function() {
                [window, this._element, this._dialog].forEach(function(htmlElement) {
                    return $(htmlElement).off(EVENT_KEY$5)
                }), $(document).off(Event$5.FOCUSIN), $.removeData(this._element, DATA_KEY$5), this._config = null, this._element = null, this._dialog = null, this._backdrop = null, this._isShown = null, this._isBodyOverflowing = null, this._ignoreBackdropClick = null, this._isTransitioning = null, this._scrollbarWidth = null
            }, _proto.handleUpdate = function() {
                this._adjustDialog()
            }, _proto._getConfig = function(config) {
                return config = _objectSpread2({}, Default$3, {}, config), Util.typeCheckConfig(NAME$5, config, DefaultType$3), config
            }, _proto._triggerBackdropTransition = function() {
                var _this3 = this;
                if (this._config.backdrop === "static") {
                    var hideEventPrevented = $.Event(Event$5.HIDE_PREVENTED);
                    if ($(this._element).trigger(hideEventPrevented), hideEventPrevented.defaultPrevented) return;
                    this._element.classList.add(ClassName$5.STATIC);
                    var modalTransitionDuration = Util.getTransitionDurationFromElement(this._element);
                    $(this._element).one(Util.TRANSITION_END, function() {
                        _this3._element.classList.remove(ClassName$5.STATIC)
                    }).emulateTransitionEnd(modalTransitionDuration), this._element.focus()
                } else this.hide()
            }, _proto._showElement = function(relatedTarget) {
                var _this4 = this,
                    transition = $(this._element).hasClass(ClassName$5.FADE),
                    modalBody = this._dialog ? this._dialog.querySelector(Selector$5.MODAL_BODY) : null;
                (!this._element.parentNode || this._element.parentNode.nodeType !== Node.ELEMENT_NODE) && document.body.appendChild(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), $(this._dialog).hasClass(ClassName$5.SCROLLABLE) && modalBody ? modalBody.scrollTop = 0 : this._element.scrollTop = 0, transition && Util.reflow(this._element), $(this._element).addClass(ClassName$5.SHOW), this._config.focus && this._enforceFocus();
                var shownEvent = $.Event(Event$5.SHOWN, {
                        relatedTarget: relatedTarget
                    }),
                    transitionComplete = function() {
                        _this4._config.focus && _this4._element.focus(), _this4._isTransitioning = !1, $(_this4._element).trigger(shownEvent)
                    };
                if (transition) {
                    var transitionDuration = Util.getTransitionDurationFromElement(this._dialog);
                    $(this._dialog).one(Util.TRANSITION_END, transitionComplete).emulateTransitionEnd(transitionDuration)
                } else transitionComplete()
            }, _proto._enforceFocus = function() {
                var _this5 = this;
                $(document).off(Event$5.FOCUSIN).on(Event$5.FOCUSIN, function(event) {
                    document !== event.target && _this5._element !== event.target && $(_this5._element).has(event.target).length === 0 && _this5._element.focus()
                })
            }, _proto._setEscapeEvent = function() {
                var _this6 = this;
                this._isShown && this._config.keyboard ? $(this._element).on(Event$5.KEYDOWN_DISMISS, function(event) {
                    event.which === ESCAPE_KEYCODE$1 && _this6._triggerBackdropTransition()
                }) : this._isShown || $(this._element).off(Event$5.KEYDOWN_DISMISS)
            }, _proto._setResizeEvent = function() {
                var _this7 = this;
                this._isShown ? $(window).on(Event$5.RESIZE, function(event) {
                    return _this7.handleUpdate(event)
                }) : $(window).off(Event$5.RESIZE)
            }, _proto._hideModal = function() {
                var _this8 = this;
                this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._isTransitioning = !1, this._showBackdrop(function() {
                    $(document.body).removeClass(ClassName$5.OPEN), _this8._resetAdjustments(), _this8._resetScrollbar(), $(_this8._element).trigger(Event$5.HIDDEN)
                })
            }, _proto._removeBackdrop = function() {
                this._backdrop && ($(this._backdrop).remove(), this._backdrop = null)
            }, _proto._showBackdrop = function(callback) {
                var _this9 = this,
                    animate = $(this._element).hasClass(ClassName$5.FADE) ? ClassName$5.FADE : "";
                if (this._isShown && this._config.backdrop) {
                    if (this._backdrop = document.createElement("div"), this._backdrop.className = ClassName$5.BACKDROP, animate && this._backdrop.classList.add(animate), $(this._backdrop).appendTo(document.body), $(this._element).on(Event$5.CLICK_DISMISS, function(event) {
                            if (_this9._ignoreBackdropClick) {
                                _this9._ignoreBackdropClick = !1;
                                return
                            }
                            event.target === event.currentTarget && _this9._triggerBackdropTransition()
                        }), animate && Util.reflow(this._backdrop), $(this._backdrop).addClass(ClassName$5.SHOW), !callback) return;
                    if (!animate) {
                        callback();
                        return
                    }
                    var backdropTransitionDuration = Util.getTransitionDurationFromElement(this._backdrop);
                    $(this._backdrop).one(Util.TRANSITION_END, callback).emulateTransitionEnd(backdropTransitionDuration)
                } else if (!this._isShown && this._backdrop) {
                    $(this._backdrop).removeClass(ClassName$5.SHOW);
                    var callbackRemove = function() {
                        _this9._removeBackdrop(), callback && callback()
                    };
                    if ($(this._element).hasClass(ClassName$5.FADE)) {
                        var _backdropTransitionDuration = Util.getTransitionDurationFromElement(this._backdrop);
                        $(this._backdrop).one(Util.TRANSITION_END, callbackRemove).emulateTransitionEnd(_backdropTransitionDuration)
                    } else callbackRemove()
                } else callback && callback()
            }, _proto._adjustDialog = function() {
                var isModalOverflowing = this._element.scrollHeight > document.documentElement.clientHeight;
                !this._isBodyOverflowing && isModalOverflowing && (this._element.style.paddingLeft = this._scrollbarWidth + "px"), this._isBodyOverflowing && !isModalOverflowing && (this._element.style.paddingRight = this._scrollbarWidth + "px")
            }, _proto._resetAdjustments = function() {
                this._element.style.paddingLeft = "", this._element.style.paddingRight = ""
            }, _proto._checkScrollbar = function() {
                var rect = document.body.getBoundingClientRect();
                this._isBodyOverflowing = rect.left + rect.right < window.innerWidth, this._scrollbarWidth = this._getScrollbarWidth()
            }, _proto._setScrollbar = function() {
                var _this10 = this;
                if (this._isBodyOverflowing) {
                    var fixedContent = [].slice.call(document.querySelectorAll(Selector$5.FIXED_CONTENT)),
                        stickyContent = [].slice.call(document.querySelectorAll(Selector$5.STICKY_CONTENT));
                    $(fixedContent).each(function(index, element) {
                        var actualPadding2 = element.style.paddingRight,
                            calculatedPadding2 = $(element).css("padding-right");
                        $(element).data("padding-right", actualPadding2).css("padding-right", parseFloat(calculatedPadding2) + _this10._scrollbarWidth + "px")
                    }), $(stickyContent).each(function(index, element) {
                        var actualMargin = element.style.marginRight,
                            calculatedMargin = $(element).css("margin-right");
                        $(element).data("margin-right", actualMargin).css("margin-right", parseFloat(calculatedMargin) - _this10._scrollbarWidth + "px")
                    });
                    var actualPadding = document.body.style.paddingRight,
                        calculatedPadding = $(document.body).css("padding-right");
                    $(document.body).data("padding-right", actualPadding).css("padding-right", parseFloat(calculatedPadding) + this._scrollbarWidth + "px")
                }
                $(document.body).addClass(ClassName$5.OPEN)
            }, _proto._resetScrollbar = function() {
                var fixedContent = [].slice.call(document.querySelectorAll(Selector$5.FIXED_CONTENT));
                $(fixedContent).each(function(index, element) {
                    var padding2 = $(element).data("padding-right");
                    $(element).removeData("padding-right"), element.style.paddingRight = padding2 || ""
                });
                var elements = [].slice.call(document.querySelectorAll("" + Selector$5.STICKY_CONTENT));
                $(elements).each(function(index, element) {
                    var margin = $(element).data("margin-right");
                    typeof margin != "undefined" && $(element).css("margin-right", margin).removeData("margin-right")
                });
                var padding = $(document.body).data("padding-right");
                $(document.body).removeData("padding-right"), document.body.style.paddingRight = padding || ""
            }, _proto._getScrollbarWidth = function() {
                var scrollDiv = document.createElement("div");
                scrollDiv.className = ClassName$5.SCROLLBAR_MEASURER, document.body.appendChild(scrollDiv);
                var scrollbarWidth = scrollDiv.getBoundingClientRect().width - scrollDiv.clientWidth;
                return document.body.removeChild(scrollDiv), scrollbarWidth
            }, Modal2._jQueryInterface = function(config, relatedTarget) {
                return this.each(function() {
                    var data = $(this).data(DATA_KEY$5),
                        _config = _objectSpread2({}, Default$3, {}, $(this).data(), {}, typeof config == "object" && config ? config : {});
                    if (data || (data = new Modal2(this, _config), $(this).data(DATA_KEY$5, data)), typeof config == "string") {
                        if (typeof data[config] == "undefined") throw new TypeError('No method named "' + config + '"');
                        data[config](relatedTarget)
                    } else _config.show && data.show(relatedTarget)
                })
            }, _createClass(Modal2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$5
                }
            }, {
                key: "Default",
                get: function() {
                    return Default$3
                }
            }]), Modal2
        }();
    $(document).on(Event$5.CLICK_DATA_API, Selector$5.DATA_TOGGLE, function(event) {
        var _this11 = this,
            target, selector = Util.getSelectorFromElement(this);
        selector && (target = document.querySelector(selector));
        var config = $(target).data(DATA_KEY$5) ? "toggle" : _objectSpread2({}, $(target).data(), {}, $(this).data());
        (this.tagName === "A" || this.tagName === "AREA") && event.preventDefault();
        var $target = $(target).one(Event$5.SHOW, function(showEvent) {
            showEvent.isDefaultPrevented() || $target.one(Event$5.HIDDEN, function() {
                $(_this11).is(":visible") && _this11.focus()
            })
        });
        Modal._jQueryInterface.call($(target), config, this)
    }), $.fn[NAME$5] = Modal._jQueryInterface, $.fn[NAME$5].Constructor = Modal, $.fn[NAME$5].noConflict = function() {
        return $.fn[NAME$5] = JQUERY_NO_CONFLICT$5, Modal._jQueryInterface
    };
    var uriAttrs = ["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"],
        ARIA_ATTRIBUTE_PATTERN = /^aria-[\w-]*$/i,
        DefaultWhitelist = {
            "*": ["class", "dir", "id", "lang", "role", ARIA_ATTRIBUTE_PATTERN],
            a: ["target", "href", "title", "rel"],
            area: [],
            b: [],
            br: [],
            col: [],
            code: [],
            div: [],
            em: [],
            hr: [],
            h1: [],
            h2: [],
            h3: [],
            h4: [],
            h5: [],
            h6: [],
            i: [],
            img: ["src", "alt", "title", "width", "height"],
            li: [],
            ol: [],
            p: [],
            pre: [],
            s: [],
            small: [],
            span: [],
            sub: [],
            sup: [],
            strong: [],
            u: [],
            ul: []
        },
        SAFE_URL_PATTERN = /^(?:(?:https?|mailto|ftp|tel|file):|[^&:/?#]*(?:[/?#]|$))/gi,
        DATA_URL_PATTERN = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[a-z0-9+/]+=*$/i;

    function allowedAttribute(attr, allowedAttributeList) {
        var attrName = attr.nodeName.toLowerCase();
        if (allowedAttributeList.indexOf(attrName) !== -1) return uriAttrs.indexOf(attrName) !== -1 ? !!(attr.nodeValue.match(SAFE_URL_PATTERN) || attr.nodeValue.match(DATA_URL_PATTERN)) : !0;
        for (var regExp = allowedAttributeList.filter(function(attrRegex) {
                return attrRegex instanceof RegExp
            }), i = 0, l = regExp.length; i < l; i++)
            if (attrName.match(regExp[i])) return !0;
        return !1
    }

    function sanitizeHtml(unsafeHtml, whiteList, sanitizeFn) {
        if (unsafeHtml.length === 0) return unsafeHtml;
        if (sanitizeFn && typeof sanitizeFn == "function") return sanitizeFn(unsafeHtml);
        for (var domParser = new window.DOMParser, createdDocument = domParser.parseFromString(unsafeHtml, "text/html"), whitelistKeys = Object.keys(whiteList), elements = [].slice.call(createdDocument.body.querySelectorAll("*")), _loop = function(i2, len2) {
                var el = elements[i2],
                    elName = el.nodeName.toLowerCase();
                if (whitelistKeys.indexOf(el.nodeName.toLowerCase()) === -1) return el.parentNode.removeChild(el), "continue";
                var attributeList = [].slice.call(el.attributes),
                    whitelistedAttributes = [].concat(whiteList["*"] || [], whiteList[elName] || []);
                attributeList.forEach(function(attr) {
                    allowedAttribute(attr, whitelistedAttributes) || el.removeAttribute(attr.nodeName)
                })
            }, i = 0, len = elements.length; i < len; i++) var _ret = _loop(i);
        return createdDocument.body.innerHTML
    }
    var NAME$6 = "tooltip",
        VERSION$6 = "4.4.1",
        DATA_KEY$6 = "bs.tooltip",
        EVENT_KEY$6 = "." + DATA_KEY$6,
        JQUERY_NO_CONFLICT$6 = $.fn[NAME$6],
        CLASS_PREFIX = "bs-tooltip",
        BSCLS_PREFIX_REGEX = new RegExp("(^|\\s)" + CLASS_PREFIX + "\\S+", "g"),
        DISALLOWED_ATTRIBUTES = ["sanitize", "whiteList", "sanitizeFn"],
        DefaultType$4 = {
            animation: "boolean",
            template: "string",
            title: "(string|element|function)",
            trigger: "string",
            delay: "(number|object)",
            html: "boolean",
            selector: "(string|boolean)",
            placement: "(string|function)",
            offset: "(number|string|function)",
            container: "(string|element|boolean)",
            fallbackPlacement: "(string|array)",
            boundary: "(string|element)",
            sanitize: "boolean",
            sanitizeFn: "(null|function)",
            whiteList: "object",
            popperConfig: "(null|object)"
        },
        AttachmentMap$1 = {
            AUTO: "auto",
            TOP: "top",
            RIGHT: "right",
            BOTTOM: "bottom",
            LEFT: "left"
        },
        Default$4 = {
            animation: !0,
            template: '<div class="tooltip" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>',
            trigger: "hover focus",
            title: "",
            delay: 0,
            html: !1,
            selector: !1,
            placement: "top",
            offset: 0,
            container: !1,
            fallbackPlacement: "flip",
            boundary: "scrollParent",
            sanitize: !0,
            sanitizeFn: null,
            whiteList: DefaultWhitelist,
            popperConfig: null
        },
        HoverState = {
            SHOW: "show",
            OUT: "out"
        },
        Event$6 = {
            HIDE: "hide" + EVENT_KEY$6,
            HIDDEN: "hidden" + EVENT_KEY$6,
            SHOW: "show" + EVENT_KEY$6,
            SHOWN: "shown" + EVENT_KEY$6,
            INSERTED: "inserted" + EVENT_KEY$6,
            CLICK: "click" + EVENT_KEY$6,
            FOCUSIN: "focusin" + EVENT_KEY$6,
            FOCUSOUT: "focusout" + EVENT_KEY$6,
            MOUSEENTER: "mouseenter" + EVENT_KEY$6,
            MOUSELEAVE: "mouseleave" + EVENT_KEY$6
        },
        ClassName$6 = {
            FADE: "fade",
            SHOW: "show"
        },
        Selector$6 = {
            TOOLTIP: ".tooltip",
            TOOLTIP_INNER: ".tooltip-inner",
            ARROW: ".arrow"
        },
        Trigger = {
            HOVER: "hover",
            FOCUS: "focus",
            CLICK: "click",
            MANUAL: "manual"
        },
        Tooltip = function() {
            function Tooltip2(element, config) {
                if (typeof Popper == "undefined") throw new TypeError("Bootstrap's tooltips require Popper.js (https://popper.js.org/)");
                this._isEnabled = !0, this._timeout = 0, this._hoverState = "", this._activeTrigger = {}, this._popper = null, this.element = element, this.config = this._getConfig(config), this.tip = null, this._setListeners()
            }
            var _proto = Tooltip2.prototype;
            return _proto.enable = function() {
                this._isEnabled = !0
            }, _proto.disable = function() {
                this._isEnabled = !1
            }, _proto.toggleEnabled = function() {
                this._isEnabled = !this._isEnabled
            }, _proto.toggle = function(event) {
                if (this._isEnabled)
                    if (event) {
                        var dataKey = this.constructor.DATA_KEY,
                            context = $(event.currentTarget).data(dataKey);
                        context || (context = new this.constructor(event.currentTarget, this._getDelegateConfig()), $(event.currentTarget).data(dataKey, context)), context._activeTrigger.click = !context._activeTrigger.click, context._isWithActiveTrigger() ? context._enter(null, context) : context._leave(null, context)
                    } else {
                        if ($(this.getTipElement()).hasClass(ClassName$6.SHOW)) {
                            this._leave(null, this);
                            return
                        }
                        this._enter(null, this)
                    }
            }, _proto.dispose = function() {
                clearTimeout(this._timeout), $.removeData(this.element, this.constructor.DATA_KEY), $(this.element).off(this.constructor.EVENT_KEY), $(this.element).closest(".modal").off("hide.bs.modal", this._hideModalHandler), this.tip && $(this.tip).remove(), this._isEnabled = null, this._timeout = null, this._hoverState = null, this._activeTrigger = null, this._popper && this._popper.destroy(), this._popper = null, this.element = null, this.config = null, this.tip = null
            }, _proto.show = function() {
                var _this = this;
                if ($(this.element).css("display") === "none") throw new Error("Please use show on visible elements");
                var showEvent = $.Event(this.constructor.Event.SHOW);
                if (this.isWithContent() && this._isEnabled) {
                    $(this.element).trigger(showEvent);
                    var shadowRoot = Util.findShadowRoot(this.element),
                        isInTheDom = $.contains(shadowRoot !== null ? shadowRoot : this.element.ownerDocument.documentElement, this.element);
                    if (showEvent.isDefaultPrevented() || !isInTheDom) return;
                    var tip = this.getTipElement(),
                        tipId = Util.getUID(this.constructor.NAME);
                    tip.setAttribute("id", tipId), this.element.setAttribute("aria-describedby", tipId), this.setContent(), this.config.animation && $(tip).addClass(ClassName$6.FADE);
                    var placement = typeof this.config.placement == "function" ? this.config.placement.call(this, tip, this.element) : this.config.placement,
                        attachment = this._getAttachment(placement);
                    this.addAttachmentClass(attachment);
                    var container = this._getContainer();
                    $(tip).data(this.constructor.DATA_KEY, this), $.contains(this.element.ownerDocument.documentElement, this.tip) || $(tip).appendTo(container), $(this.element).trigger(this.constructor.Event.INSERTED), this._popper = new Popper(this.element, tip, this._getPopperConfig(attachment)), $(tip).addClass(ClassName$6.SHOW), "ontouchstart" in document.documentElement && $(document.body).children().on("mouseover", null, $.noop);
                    var complete = function() {
                        _this.config.animation && _this._fixTransition();
                        var prevHoverState = _this._hoverState;
                        _this._hoverState = null, $(_this.element).trigger(_this.constructor.Event.SHOWN), prevHoverState === HoverState.OUT && _this._leave(null, _this)
                    };
                    if ($(this.tip).hasClass(ClassName$6.FADE)) {
                        var transitionDuration = Util.getTransitionDurationFromElement(this.tip);
                        $(this.tip).one(Util.TRANSITION_END, complete).emulateTransitionEnd(transitionDuration)
                    } else complete()
                }
            }, _proto.hide = function(callback) {
                var _this2 = this,
                    tip = this.getTipElement(),
                    hideEvent = $.Event(this.constructor.Event.HIDE),
                    complete = function() {
                        _this2._hoverState !== HoverState.SHOW && tip.parentNode && tip.parentNode.removeChild(tip), _this2._cleanTipClass(), _this2.element.removeAttribute("aria-describedby"), $(_this2.element).trigger(_this2.constructor.Event.HIDDEN), _this2._popper !== null && _this2._popper.destroy(), callback && callback()
                    };
                if ($(this.element).trigger(hideEvent), !hideEvent.isDefaultPrevented()) {
                    if ($(tip).removeClass(ClassName$6.SHOW), "ontouchstart" in document.documentElement && $(document.body).children().off("mouseover", null, $.noop), this._activeTrigger[Trigger.CLICK] = !1, this._activeTrigger[Trigger.FOCUS] = !1, this._activeTrigger[Trigger.HOVER] = !1, $(this.tip).hasClass(ClassName$6.FADE)) {
                        var transitionDuration = Util.getTransitionDurationFromElement(tip);
                        $(tip).one(Util.TRANSITION_END, complete).emulateTransitionEnd(transitionDuration)
                    } else complete();
                    this._hoverState = ""
                }
            }, _proto.update = function() {
                this._popper !== null && this._popper.scheduleUpdate()
            }, _proto.isWithContent = function() {
                return !!this.getTitle()
            }, _proto.addAttachmentClass = function(attachment) {
                $(this.getTipElement()).addClass(CLASS_PREFIX + "-" + attachment)
            }, _proto.getTipElement = function() {
                return this.tip = this.tip || $(this.config.template)[0], this.tip
            }, _proto.setContent = function() {
                var tip = this.getTipElement();
                this.setElementContent($(tip.querySelectorAll(Selector$6.TOOLTIP_INNER)), this.getTitle()), $(tip).removeClass(ClassName$6.FADE + " " + ClassName$6.SHOW)
            }, _proto.setElementContent = function($element, content) {
                if (typeof content == "object" && (content.nodeType || content.jquery)) {
                    this.config.html ? $(content).parent().is($element) || $element.empty().append(content) : $element.text($(content).text());
                    return
                }
                this.config.html ? (this.config.sanitize && (content = sanitizeHtml(content, this.config.whiteList, this.config.sanitizeFn)), $element.html(content)) : $element.text(content)
            }, _proto.getTitle = function() {
                var title = this.element.getAttribute("data-original-title");
                return title || (title = typeof this.config.title == "function" ? this.config.title.call(this.element) : this.config.title), title
            }, _proto._getPopperConfig = function(attachment) {
                var _this3 = this,
                    defaultBsConfig = {
                        placement: attachment,
                        modifiers: {
                            offset: this._getOffset(),
                            flip: {
                                behavior: this.config.fallbackPlacement
                            },
                            arrow: {
                                element: Selector$6.ARROW
                            },
                            preventOverflow: {
                                boundariesElement: this.config.boundary
                            }
                        },
                        onCreate: function(data) {
                            data.originalPlacement !== data.placement && _this3._handlePopperPlacementChange(data)
                        },
                        onUpdate: function(data) {
                            return _this3._handlePopperPlacementChange(data)
                        }
                    };
                return _objectSpread2({}, defaultBsConfig, {}, this.config.popperConfig)
            }, _proto._getOffset = function() {
                var _this4 = this,
                    offset = {};
                return typeof this.config.offset == "function" ? offset.fn = function(data) {
                    return data.offsets = _objectSpread2({}, data.offsets, {}, _this4.config.offset(data.offsets, _this4.element) || {}), data
                } : offset.offset = this.config.offset, offset
            }, _proto._getContainer = function() {
                return this.config.container === !1 ? document.body : Util.isElement(this.config.container) ? $(this.config.container) : $(document).find(this.config.container)
            }, _proto._getAttachment = function(placement) {
                return AttachmentMap$1[placement.toUpperCase()]
            }, _proto._setListeners = function() {
                var _this5 = this,
                    triggers = this.config.trigger.split(" ");
                triggers.forEach(function(trigger) {
                    if (trigger === "click") $(_this5.element).on(_this5.constructor.Event.CLICK, _this5.config.selector, function(event) {
                        return _this5.toggle(event)
                    });
                    else if (trigger !== Trigger.MANUAL) {
                        var eventIn = trigger === Trigger.HOVER ? _this5.constructor.Event.MOUSEENTER : _this5.constructor.Event.FOCUSIN,
                            eventOut = trigger === Trigger.HOVER ? _this5.constructor.Event.MOUSELEAVE : _this5.constructor.Event.FOCUSOUT;
                        $(_this5.element).on(eventIn, _this5.config.selector, function(event) {
                            return _this5._enter(event)
                        }).on(eventOut, _this5.config.selector, function(event) {
                            return _this5._leave(event)
                        })
                    }
                }), this._hideModalHandler = function() {
                    _this5.element && _this5.hide()
                }, $(this.element).closest(".modal").on("hide.bs.modal", this._hideModalHandler), this.config.selector ? this.config = _objectSpread2({}, this.config, {
                    trigger: "manual",
                    selector: ""
                }) : this._fixTitle()
            }, _proto._fixTitle = function() {
                var titleType = typeof this.element.getAttribute("data-original-title");
                (this.element.getAttribute("title") || titleType !== "string") && (this.element.setAttribute("data-original-title", this.element.getAttribute("title") || ""), this.element.setAttribute("title", ""))
            }, _proto._enter = function(event, context) {
                var dataKey = this.constructor.DATA_KEY;
                if (context = context || $(event.currentTarget).data(dataKey), context || (context = new this.constructor(event.currentTarget, this._getDelegateConfig()), $(event.currentTarget).data(dataKey, context)), event && (context._activeTrigger[event.type === "focusin" ? Trigger.FOCUS : Trigger.HOVER] = !0), $(context.getTipElement()).hasClass(ClassName$6.SHOW) || context._hoverState === HoverState.SHOW) {
                    context._hoverState = HoverState.SHOW;
                    return
                }
                if (clearTimeout(context._timeout), context._hoverState = HoverState.SHOW, !context.config.delay || !context.config.delay.show) {
                    context.show();
                    return
                }
                context._timeout = setTimeout(function() {
                    context._hoverState === HoverState.SHOW && context.show()
                }, context.config.delay.show)
            }, _proto._leave = function(event, context) {
                var dataKey = this.constructor.DATA_KEY;
                if (context = context || $(event.currentTarget).data(dataKey), context || (context = new this.constructor(event.currentTarget, this._getDelegateConfig()), $(event.currentTarget).data(dataKey, context)), event && (context._activeTrigger[event.type === "focusout" ? Trigger.FOCUS : Trigger.HOVER] = !1), !context._isWithActiveTrigger()) {
                    if (clearTimeout(context._timeout), context._hoverState = HoverState.OUT, !context.config.delay || !context.config.delay.hide) {
                        context.hide();
                        return
                    }
                    context._timeout = setTimeout(function() {
                        context._hoverState === HoverState.OUT && context.hide()
                    }, context.config.delay.hide)
                }
            }, _proto._isWithActiveTrigger = function() {
                for (var trigger in this._activeTrigger)
                    if (this._activeTrigger[trigger]) return !0;
                return !1
            }, _proto._getConfig = function(config) {
                var dataAttributes = $(this.element).data();
                return Object.keys(dataAttributes).forEach(function(dataAttr) {
                    DISALLOWED_ATTRIBUTES.indexOf(dataAttr) !== -1 && delete dataAttributes[dataAttr]
                }), config = _objectSpread2({}, this.constructor.Default, {}, dataAttributes, {}, typeof config == "object" && config ? config : {}), typeof config.delay == "number" && (config.delay = {
                    show: config.delay,
                    hide: config.delay
                }), typeof config.title == "number" && (config.title = config.title.toString()), typeof config.content == "number" && (config.content = config.content.toString()), Util.typeCheckConfig(NAME$6, config, this.constructor.DefaultType), config.sanitize && (config.template = sanitizeHtml(config.template, config.whiteList, config.sanitizeFn)), config
            }, _proto._getDelegateConfig = function() {
                var config = {};
                if (this.config)
                    for (var key in this.config) this.constructor.Default[key] !== this.config[key] && (config[key] = this.config[key]);
                return config
            }, _proto._cleanTipClass = function() {
                var $tip = $(this.getTipElement()),
                    tabClass = $tip.attr("class").match(BSCLS_PREFIX_REGEX);
                tabClass !== null && tabClass.length && $tip.removeClass(tabClass.join(""))
            }, _proto._handlePopperPlacementChange = function(popperData) {
                var popperInstance = popperData.instance;
                this.tip = popperInstance.popper, this._cleanTipClass(), this.addAttachmentClass(this._getAttachment(popperData.placement))
            }, _proto._fixTransition = function() {
                var tip = this.getTipElement(),
                    initConfigAnimation = this.config.animation;
                tip.getAttribute("x-placement") === null && ($(tip).removeClass(ClassName$6.FADE), this.config.animation = !1, this.hide(), this.show(), this.config.animation = initConfigAnimation)
            }, Tooltip2._jQueryInterface = function(config) {
                return this.each(function() {
                    var data = $(this).data(DATA_KEY$6),
                        _config = typeof config == "object" && config;
                    if (!(!data && /dispose|hide/.test(config)) && (data || (data = new Tooltip2(this, _config), $(this).data(DATA_KEY$6, data)), typeof config == "string")) {
                        if (typeof data[config] == "undefined") throw new TypeError('No method named "' + config + '"');
                        data[config]()
                    }
                })
            }, _createClass(Tooltip2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$6
                }
            }, {
                key: "Default",
                get: function() {
                    return Default$4
                }
            }, {
                key: "NAME",
                get: function() {
                    return NAME$6
                }
            }, {
                key: "DATA_KEY",
                get: function() {
                    return DATA_KEY$6
                }
            }, {
                key: "Event",
                get: function() {
                    return Event$6
                }
            }, {
                key: "EVENT_KEY",
                get: function() {
                    return EVENT_KEY$6
                }
            }, {
                key: "DefaultType",
                get: function() {
                    return DefaultType$4
                }
            }]), Tooltip2
        }();
    $.fn[NAME$6] = Tooltip._jQueryInterface, $.fn[NAME$6].Constructor = Tooltip, $.fn[NAME$6].noConflict = function() {
        return $.fn[NAME$6] = JQUERY_NO_CONFLICT$6, Tooltip._jQueryInterface
    };
    var NAME$7 = "popover",
        VERSION$7 = "4.4.1",
        DATA_KEY$7 = "bs.popover",
        EVENT_KEY$7 = "." + DATA_KEY$7,
        JQUERY_NO_CONFLICT$7 = $.fn[NAME$7],
        CLASS_PREFIX$1 = "bs-popover",
        BSCLS_PREFIX_REGEX$1 = new RegExp("(^|\\s)" + CLASS_PREFIX$1 + "\\S+", "g"),
        Default$5 = _objectSpread2({}, Tooltip.Default, {
            placement: "right",
            trigger: "click",
            content: "",
            template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>'
        }),
        DefaultType$5 = _objectSpread2({}, Tooltip.DefaultType, {
            content: "(string|element|function)"
        }),
        ClassName$7 = {
            FADE: "fade",
            SHOW: "show"
        },
        Selector$7 = {
            TITLE: ".popover-header",
            CONTENT: ".popover-body"
        },
        Event$7 = {
            HIDE: "hide" + EVENT_KEY$7,
            HIDDEN: "hidden" + EVENT_KEY$7,
            SHOW: "show" + EVENT_KEY$7,
            SHOWN: "shown" + EVENT_KEY$7,
            INSERTED: "inserted" + EVENT_KEY$7,
            CLICK: "click" + EVENT_KEY$7,
            FOCUSIN: "focusin" + EVENT_KEY$7,
            FOCUSOUT: "focusout" + EVENT_KEY$7,
            MOUSEENTER: "mouseenter" + EVENT_KEY$7,
            MOUSELEAVE: "mouseleave" + EVENT_KEY$7
        },
        Popover = function(_Tooltip) {
            _inheritsLoose(Popover2, _Tooltip);

            function Popover2() {
                return _Tooltip.apply(this, arguments) || this
            }
            var _proto = Popover2.prototype;
            return _proto.isWithContent = function() {
                return this.getTitle() || this._getContent()
            }, _proto.addAttachmentClass = function(attachment) {
                $(this.getTipElement()).addClass(CLASS_PREFIX$1 + "-" + attachment)
            }, _proto.getTipElement = function() {
                return this.tip = this.tip || $(this.config.template)[0], this.tip
            }, _proto.setContent = function() {
                var $tip = $(this.getTipElement());
                this.setElementContent($tip.find(Selector$7.TITLE), this.getTitle());
                var content = this._getContent();
                typeof content == "function" && (content = content.call(this.element)), this.setElementContent($tip.find(Selector$7.CONTENT), content), $tip.removeClass(ClassName$7.FADE + " " + ClassName$7.SHOW)
            }, _proto._getContent = function() {
                return this.element.getAttribute("data-content") || this.config.content
            }, _proto._cleanTipClass = function() {
                var $tip = $(this.getTipElement()),
                    tabClass = $tip.attr("class").match(BSCLS_PREFIX_REGEX$1);
                tabClass !== null && tabClass.length > 0 && $tip.removeClass(tabClass.join(""))
            }, Popover2._jQueryInterface = function(config) {
                return this.each(function() {
                    var data = $(this).data(DATA_KEY$7),
                        _config = typeof config == "object" ? config : null;
                    if (!(!data && /dispose|hide/.test(config)) && (data || (data = new Popover2(this, _config), $(this).data(DATA_KEY$7, data)), typeof config == "string")) {
                        if (typeof data[config] == "undefined") throw new TypeError('No method named "' + config + '"');
                        data[config]()
                    }
                })
            }, _createClass(Popover2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$7
                }
            }, {
                key: "Default",
                get: function() {
                    return Default$5
                }
            }, {
                key: "NAME",
                get: function() {
                    return NAME$7
                }
            }, {
                key: "DATA_KEY",
                get: function() {
                    return DATA_KEY$7
                }
            }, {
                key: "Event",
                get: function() {
                    return Event$7
                }
            }, {
                key: "EVENT_KEY",
                get: function() {
                    return EVENT_KEY$7
                }
            }, {
                key: "DefaultType",
                get: function() {
                    return DefaultType$5
                }
            }]), Popover2
        }(Tooltip);
    $.fn[NAME$7] = Popover._jQueryInterface, $.fn[NAME$7].Constructor = Popover, $.fn[NAME$7].noConflict = function() {
        return $.fn[NAME$7] = JQUERY_NO_CONFLICT$7, Popover._jQueryInterface
    };
    var NAME$8 = "scrollspy",
        VERSION$8 = "4.4.1",
        DATA_KEY$8 = "bs.scrollspy",
        EVENT_KEY$8 = "." + DATA_KEY$8,
        DATA_API_KEY$6 = ".data-api",
        JQUERY_NO_CONFLICT$8 = $.fn[NAME$8],
        Default$6 = {
            offset: 10,
            method: "auto",
            target: ""
        },
        DefaultType$6 = {
            offset: "number",
            method: "string",
            target: "(string|element)"
        },
        Event$8 = {
            ACTIVATE: "activate" + EVENT_KEY$8,
            SCROLL: "scroll" + EVENT_KEY$8,
            LOAD_DATA_API: "load" + EVENT_KEY$8 + DATA_API_KEY$6
        },
        ClassName$8 = {
            DROPDOWN_ITEM: "dropdown-item",
            DROPDOWN_MENU: "dropdown-menu",
            ACTIVE: "active"
        },
        Selector$8 = {
            DATA_SPY: '[data-spy="scroll"]',
            ACTIVE: ".active",
            NAV_LIST_GROUP: ".nav, .list-group",
            NAV_LINKS: ".nav-link",
            NAV_ITEMS: ".nav-item",
            LIST_ITEMS: ".list-group-item",
            DROPDOWN: ".dropdown",
            DROPDOWN_ITEMS: ".dropdown-item",
            DROPDOWN_TOGGLE: ".dropdown-toggle"
        },
        OffsetMethod = {
            OFFSET: "offset",
            POSITION: "position"
        },
        ScrollSpy = function() {
            function ScrollSpy2(element, config) {
                var _this = this;
                this._element = element, this._scrollElement = element.tagName === "BODY" ? window : element, this._config = this._getConfig(config), this._selector = this._config.target + " " + Selector$8.NAV_LINKS + "," + (this._config.target + " " + Selector$8.LIST_ITEMS + ",") + (this._config.target + " " + Selector$8.DROPDOWN_ITEMS), this._offsets = [], this._targets = [], this._activeTarget = null, this._scrollHeight = 0, $(this._scrollElement).on(Event$8.SCROLL, function(event) {
                    return _this._process(event)
                }), this.refresh(), this._process()
            }
            var _proto = ScrollSpy2.prototype;
            return _proto.refresh = function() {
                var _this2 = this,
                    autoMethod = this._scrollElement === this._scrollElement.window ? OffsetMethod.OFFSET : OffsetMethod.POSITION,
                    offsetMethod = this._config.method === "auto" ? autoMethod : this._config.method,
                    offsetBase = offsetMethod === OffsetMethod.POSITION ? this._getScrollTop() : 0;
                this._offsets = [], this._targets = [], this._scrollHeight = this._getScrollHeight();
                var targets = [].slice.call(document.querySelectorAll(this._selector));
                targets.map(function(element) {
                    var target, targetSelector = Util.getSelectorFromElement(element);
                    if (targetSelector && (target = document.querySelector(targetSelector)), target) {
                        var targetBCR = target.getBoundingClientRect();
                        if (targetBCR.width || targetBCR.height) return [$(target)[offsetMethod]().top + offsetBase, targetSelector]
                    }
                    return null
                }).filter(function(item) {
                    return item
                }).sort(function(a, b) {
                    return a[0] - b[0]
                }).forEach(function(item) {
                    _this2._offsets.push(item[0]), _this2._targets.push(item[1])
                })
            }, _proto.dispose = function() {
                $.removeData(this._element, DATA_KEY$8), $(this._scrollElement).off(EVENT_KEY$8), this._element = null, this._scrollElement = null, this._config = null, this._selector = null, this._offsets = null, this._targets = null, this._activeTarget = null, this._scrollHeight = null
            }, _proto._getConfig = function(config) {
                if (config = _objectSpread2({}, Default$6, {}, typeof config == "object" && config ? config : {}), typeof config.target != "string") {
                    var id = $(config.target).attr("id");
                    id || (id = Util.getUID(NAME$8), $(config.target).attr("id", id)), config.target = "#" + id
                }
                return Util.typeCheckConfig(NAME$8, config, DefaultType$6), config
            }, _proto._getScrollTop = function() {
                return this._scrollElement === window ? this._scrollElement.pageYOffset : this._scrollElement.scrollTop
            }, _proto._getScrollHeight = function() {
                return this._scrollElement.scrollHeight || Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)
            }, _proto._getOffsetHeight = function() {
                return this._scrollElement === window ? window.innerHeight : this._scrollElement.getBoundingClientRect().height
            }, _proto._process = function() {
                var scrollTop = this._getScrollTop() + this._config.offset,
                    scrollHeight = this._getScrollHeight(),
                    maxScroll = this._config.offset + scrollHeight - this._getOffsetHeight();
                if (this._scrollHeight !== scrollHeight && this.refresh(), scrollTop >= maxScroll) {
                    var target = this._targets[this._targets.length - 1];
                    this._activeTarget !== target && this._activate(target);
                    return
                }
                if (this._activeTarget && scrollTop < this._offsets[0] && this._offsets[0] > 0) {
                    this._activeTarget = null, this._clear();
                    return
                }
                for (var offsetLength = this._offsets.length, i = offsetLength; i--;) {
                    var isActiveTarget = this._activeTarget !== this._targets[i] && scrollTop >= this._offsets[i] && (typeof this._offsets[i + 1] == "undefined" || scrollTop < this._offsets[i + 1]);
                    isActiveTarget && this._activate(this._targets[i])
                }
            }, _proto._activate = function(target) {
                this._activeTarget = target, this._clear();
                var queries = this._selector.split(",").map(function(selector) {
                        return selector + '[data-target="' + target + '"],' + selector + '[href="' + target + '"]'
                    }),
                    $link = $([].slice.call(document.querySelectorAll(queries.join(","))));
                $link.hasClass(ClassName$8.DROPDOWN_ITEM) ? ($link.closest(Selector$8.DROPDOWN).find(Selector$8.DROPDOWN_TOGGLE).addClass(ClassName$8.ACTIVE), $link.addClass(ClassName$8.ACTIVE)) : ($link.addClass(ClassName$8.ACTIVE), $link.parents(Selector$8.NAV_LIST_GROUP).prev(Selector$8.NAV_LINKS + ", " + Selector$8.LIST_ITEMS).addClass(ClassName$8.ACTIVE), $link.parents(Selector$8.NAV_LIST_GROUP).prev(Selector$8.NAV_ITEMS).children(Selector$8.NAV_LINKS).addClass(ClassName$8.ACTIVE)), $(this._scrollElement).trigger(Event$8.ACTIVATE, {
                    relatedTarget: target
                })
            }, _proto._clear = function() {
                [].slice.call(document.querySelectorAll(this._selector)).filter(function(node) {
                    return node.classList.contains(ClassName$8.ACTIVE)
                }).forEach(function(node) {
                    return node.classList.remove(ClassName$8.ACTIVE)
                })
            }, ScrollSpy2._jQueryInterface = function(config) {
                return this.each(function() {
                    var data = $(this).data(DATA_KEY$8),
                        _config = typeof config == "object" && config;
                    if (data || (data = new ScrollSpy2(this, _config), $(this).data(DATA_KEY$8, data)), typeof config == "string") {
                        if (typeof data[config] == "undefined") throw new TypeError('No method named "' + config + '"');
                        data[config]()
                    }
                })
            }, _createClass(ScrollSpy2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$8
                }
            }, {
                key: "Default",
                get: function() {
                    return Default$6
                }
            }]), ScrollSpy2
        }();
    $(window).on(Event$8.LOAD_DATA_API, function() {
        for (var scrollSpys = [].slice.call(document.querySelectorAll(Selector$8.DATA_SPY)), scrollSpysLength = scrollSpys.length, i = scrollSpysLength; i--;) {
            var $spy = $(scrollSpys[i]);
            ScrollSpy._jQueryInterface.call($spy, $spy.data())
        }
    }), $.fn[NAME$8] = ScrollSpy._jQueryInterface, $.fn[NAME$8].Constructor = ScrollSpy, $.fn[NAME$8].noConflict = function() {
        return $.fn[NAME$8] = JQUERY_NO_CONFLICT$8, ScrollSpy._jQueryInterface
    };
    var NAME$9 = "tab",
        VERSION$9 = "4.4.1",
        DATA_KEY$9 = "bs.tab",
        EVENT_KEY$9 = "." + DATA_KEY$9,
        DATA_API_KEY$7 = ".data-api",
        JQUERY_NO_CONFLICT$9 = $.fn[NAME$9],
        Event$9 = {
            HIDE: "hide" + EVENT_KEY$9,
            HIDDEN: "hidden" + EVENT_KEY$9,
            SHOW: "show" + EVENT_KEY$9,
            SHOWN: "shown" + EVENT_KEY$9,
            CLICK_DATA_API: "click" + EVENT_KEY$9 + DATA_API_KEY$7
        },
        ClassName$9 = {
            DROPDOWN_MENU: "dropdown-menu",
            ACTIVE: "active",
            DISABLED: "disabled",
            FADE: "fade",
            SHOW: "show"
        },
        Selector$9 = {
            DROPDOWN: ".dropdown",
            NAV_LIST_GROUP: ".nav, .list-group",
            ACTIVE: ".active",
            ACTIVE_UL: "> li > .active",
            DATA_TOGGLE: '[data-toggle="tab"], [data-toggle="pill"], [data-toggle="list"]',
            DROPDOWN_TOGGLE: ".dropdown-toggle",
            DROPDOWN_ACTIVE_CHILD: "> .dropdown-menu .active"
        },
        Tab = function() {
            function Tab2(element) {
                this._element = element
            }
            var _proto = Tab2.prototype;
            return _proto.show = function() {
                var _this = this;
                if (!(this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE && $(this._element).hasClass(ClassName$9.ACTIVE) || $(this._element).hasClass(ClassName$9.DISABLED))) {
                    var target, previous, listElement = $(this._element).closest(Selector$9.NAV_LIST_GROUP)[0],
                        selector = Util.getSelectorFromElement(this._element);
                    if (listElement) {
                        var itemSelector = listElement.nodeName === "UL" || listElement.nodeName === "OL" ? Selector$9.ACTIVE_UL : Selector$9.ACTIVE;
                        previous = $.makeArray($(listElement).find(itemSelector)), previous = previous[previous.length - 1]
                    }
                    var hideEvent = $.Event(Event$9.HIDE, {
                            relatedTarget: this._element
                        }),
                        showEvent = $.Event(Event$9.SHOW, {
                            relatedTarget: previous
                        });
                    if (previous && $(previous).trigger(hideEvent), $(this._element).trigger(showEvent), !(showEvent.isDefaultPrevented() || hideEvent.isDefaultPrevented())) {
                        selector && (target = document.querySelector(selector)), this._activate(this._element, listElement);
                        var complete = function() {
                            var hiddenEvent = $.Event(Event$9.HIDDEN, {
                                    relatedTarget: _this._element
                                }),
                                shownEvent = $.Event(Event$9.SHOWN, {
                                    relatedTarget: previous
                                });
                            $(previous).trigger(hiddenEvent), $(_this._element).trigger(shownEvent)
                        };
                        target ? this._activate(target, target.parentNode, complete) : complete()
                    }
                }
            }, _proto.dispose = function() {
                $.removeData(this._element, DATA_KEY$9), this._element = null
            }, _proto._activate = function(element, container, callback) {
                var _this2 = this,
                    activeElements = container && (container.nodeName === "UL" || container.nodeName === "OL") ? $(container).find(Selector$9.ACTIVE_UL) : $(container).children(Selector$9.ACTIVE),
                    active = activeElements[0],
                    isTransitioning = callback && active && $(active).hasClass(ClassName$9.FADE),
                    complete = function() {
                        return _this2._transitionComplete(element, active, callback)
                    };
                if (active && isTransitioning) {
                    var transitionDuration = Util.getTransitionDurationFromElement(active);
                    $(active).removeClass(ClassName$9.SHOW).one(Util.TRANSITION_END, complete).emulateTransitionEnd(transitionDuration)
                } else complete()
            }, _proto._transitionComplete = function(element, active, callback) {
                if (active) {
                    $(active).removeClass(ClassName$9.ACTIVE);
                    var dropdownChild = $(active.parentNode).find(Selector$9.DROPDOWN_ACTIVE_CHILD)[0];
                    dropdownChild && $(dropdownChild).removeClass(ClassName$9.ACTIVE), active.getAttribute("role") === "tab" && active.setAttribute("aria-selected", !1)
                }
                if ($(element).addClass(ClassName$9.ACTIVE), element.getAttribute("role") === "tab" && element.setAttribute("aria-selected", !0), Util.reflow(element), element.classList.contains(ClassName$9.FADE) && element.classList.add(ClassName$9.SHOW), element.parentNode && $(element.parentNode).hasClass(ClassName$9.DROPDOWN_MENU)) {
                    var dropdownElement = $(element).closest(Selector$9.DROPDOWN)[0];
                    if (dropdownElement) {
                        var dropdownToggleList = [].slice.call(dropdownElement.querySelectorAll(Selector$9.DROPDOWN_TOGGLE));
                        $(dropdownToggleList).addClass(ClassName$9.ACTIVE)
                    }
                    element.setAttribute("aria-expanded", !0)
                }
                callback && callback()
            }, Tab2._jQueryInterface = function(config) {
                return this.each(function() {
                    var $this = $(this),
                        data = $this.data(DATA_KEY$9);
                    if (data || (data = new Tab2(this), $this.data(DATA_KEY$9, data)), typeof config == "string") {
                        if (typeof data[config] == "undefined") throw new TypeError('No method named "' + config + '"');
                        data[config]()
                    }
                })
            }, _createClass(Tab2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$9
                }
            }]), Tab2
        }();
    $(document).on(Event$9.CLICK_DATA_API, Selector$9.DATA_TOGGLE, function(event) {
        event.preventDefault(), Tab._jQueryInterface.call($(this), "show")
    }), $.fn[NAME$9] = Tab._jQueryInterface, $.fn[NAME$9].Constructor = Tab, $.fn[NAME$9].noConflict = function() {
        return $.fn[NAME$9] = JQUERY_NO_CONFLICT$9, Tab._jQueryInterface
    };
    var NAME$a = "toast",
        VERSION$a = "4.4.1",
        DATA_KEY$a = "bs.toast",
        EVENT_KEY$a = "." + DATA_KEY$a,
        JQUERY_NO_CONFLICT$a = $.fn[NAME$a],
        Event$a = {
            CLICK_DISMISS: "click.dismiss" + EVENT_KEY$a,
            HIDE: "hide" + EVENT_KEY$a,
            HIDDEN: "hidden" + EVENT_KEY$a,
            SHOW: "show" + EVENT_KEY$a,
            SHOWN: "shown" + EVENT_KEY$a
        },
        ClassName$a = {
            FADE: "fade",
            HIDE: "hide",
            SHOW: "show",
            SHOWING: "showing"
        },
        DefaultType$7 = {
            animation: "boolean",
            autohide: "boolean",
            delay: "number"
        },
        Default$7 = {
            animation: !0,
            autohide: !0,
            delay: 500
        },
        Selector$a = {
            DATA_DISMISS: '[data-dismiss="toast"]'
        },
        Toast = function() {
            function Toast2(element, config) {
                this._element = element, this._config = this._getConfig(config), this._timeout = null, this._setListeners()
            }
            var _proto = Toast2.prototype;
            return _proto.show = function() {
                var _this = this,
                    showEvent = $.Event(Event$a.SHOW);
                if ($(this._element).trigger(showEvent), !showEvent.isDefaultPrevented()) {
                    this._config.animation && this._element.classList.add(ClassName$a.FADE);
                    var complete = function() {
                        _this._element.classList.remove(ClassName$a.SHOWING), _this._element.classList.add(ClassName$a.SHOW), $(_this._element).trigger(Event$a.SHOWN), _this._config.autohide && (_this._timeout = setTimeout(function() {
                            _this.hide()
                        }, _this._config.delay))
                    };
                    if (this._element.classList.remove(ClassName$a.HIDE), Util.reflow(this._element), this._element.classList.add(ClassName$a.SHOWING), this._config.animation) {
                        var transitionDuration = Util.getTransitionDurationFromElement(this._element);
                        $(this._element).one(Util.TRANSITION_END, complete).emulateTransitionEnd(transitionDuration)
                    } else complete()
                }
            }, _proto.hide = function() {
                if (this._element.classList.contains(ClassName$a.SHOW)) {
                    var hideEvent = $.Event(Event$a.HIDE);
                    $(this._element).trigger(hideEvent), !hideEvent.isDefaultPrevented() && this._close()
                }
            }, _proto.dispose = function() {
                clearTimeout(this._timeout), this._timeout = null, this._element.classList.contains(ClassName$a.SHOW) && this._element.classList.remove(ClassName$a.SHOW), $(this._element).off(Event$a.CLICK_DISMISS), $.removeData(this._element, DATA_KEY$a), this._element = null, this._config = null
            }, _proto._getConfig = function(config) {
                return config = _objectSpread2({}, Default$7, {}, $(this._element).data(), {}, typeof config == "object" && config ? config : {}), Util.typeCheckConfig(NAME$a, config, this.constructor.DefaultType), config
            }, _proto._setListeners = function() {
                var _this2 = this;
                $(this._element).on(Event$a.CLICK_DISMISS, Selector$a.DATA_DISMISS, function() {
                    return _this2.hide()
                })
            }, _proto._close = function() {
                var _this3 = this,
                    complete = function() {
                        _this3._element.classList.add(ClassName$a.HIDE), $(_this3._element).trigger(Event$a.HIDDEN)
                    };
                if (this._element.classList.remove(ClassName$a.SHOW), this._config.animation) {
                    var transitionDuration = Util.getTransitionDurationFromElement(this._element);
                    $(this._element).one(Util.TRANSITION_END, complete).emulateTransitionEnd(transitionDuration)
                } else complete()
            }, Toast2._jQueryInterface = function(config) {
                return this.each(function() {
                    var $element = $(this),
                        data = $element.data(DATA_KEY$a),
                        _config = typeof config == "object" && config;
                    if (data || (data = new Toast2(this, _config), $element.data(DATA_KEY$a, data)), typeof config == "string") {
                        if (typeof data[config] == "undefined") throw new TypeError('No method named "' + config + '"');
                        data[config](this)
                    }
                })
            }, _createClass(Toast2, null, [{
                key: "VERSION",
                get: function() {
                    return VERSION$a
                }
            }, {
                key: "DefaultType",
                get: function() {
                    return DefaultType$7
                }
            }, {
                key: "Default",
                get: function() {
                    return Default$7
                }
            }]), Toast2
        }();
    $.fn[NAME$a] = Toast._jQueryInterface, $.fn[NAME$a].Constructor = Toast, $.fn[NAME$a].noConflict = function() {
        return $.fn[NAME$a] = JQUERY_NO_CONFLICT$a, Toast._jQueryInterface
    }, exports2.Alert = Alert, exports2.Button = Button, exports2.Carousel = Carousel, exports2.Collapse = Collapse, exports2.Dropdown = Dropdown, exports2.Modal = Modal, exports2.Popover = Popover, exports2.Scrollspy = ScrollSpy, exports2.Tab = Tab, exports2.Toast = Toast, exports2.Tooltip = Tooltip, exports2.Util = Util, Object.defineProperty(exports2, "__esModule", {
        value: !0
    })
});
//# sourceMappingURL=/cdn/shop/t/72/assets/bootstrap.js.map?v=76495176635350054551672849157